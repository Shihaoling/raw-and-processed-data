# 第一阶段约束审计（SVNS 解）与 COPT 验证工具

约束编号统一采用 R1 PDF 的公式编号：式 (2)–(43)，共 42 条。源码标签 C1–C45 只作为对照，见 `model_rows.C_LABEL`。

## 1. 文件说明

| 文件 | 作用 |
|---|---|
| `milp_data.py` | 由算例 JSON 构造模型的集合与参数。节点编号与 SVNS/RTAR 一致：0 为起点，1..C 为作业点，其后为覆盖点，最后为终点。时间窗统一为 [0,50]；DD=15，TD=200，LTD=RTD=0.1，M=300。 |
| `model_rows.py` | 逐条生成式 (2)–(43) 的线性行，并给出 max 项和乘积项的精确线性化。SVNS 审计和 COPT 建模使用**同一套行定义**。`PROFILES` 定义三种模型：`paper`、`corrected`、`reduced`。 |
| `svns_point.py` | 把 SVNS 路径映射为 MILP 的全部变量取值。时间由已验证的 `rtar_core.rtar.evaluate` 计算，该函数复现了 SVNS 的 `get_total_time`。 |
| `run_svns_audit.py` | 对 30 个主实验解和 75 个机队规模实验解逐条评估约束，并输出 `outputs/`、`copt_ready/` 中的结果。 |
| `selftest.py` | 在 3 个小算例上核对两件事：稀疏统计结果与全量逐行计算一致；SVNS warm start 在三种模型下满足全部行，包括线性化辅助行。 |
| `copt_model.py` | 用 COPT 建模并求解。支持 `--profile`、`--drop`、`--warm-start`、`--write-only`（只导出 .mps）。求解后会解码路线，用 SVNS 计时器重新计时并做物理审计，同时检查参考模型中哪些约束被违反。 |
| `run_copt_experiments.py` | 批量运行三种模型和逐条删约束实验，结果写入 `outputs/copt_experiments_*.csv`。 |
| `toy_instances.py` | 生成两个能在 COPT 免许可证规模（2000 行/列）内求解的玩具算例，用来验证建模代码。 |
| `copt_ready/instances/*.json` | 30 个算例的模型数据（集合、参数）。 |
| `copt_ready/warm_start/*.json` | 30 个 SVNS 解对应的完整变量值，可作为 MIP start 或解的对照。 |

## 2. 统计口径

- `rows_total`：按论文定义域写出时，该式包含的行数。
- `active`：该行的逻辑条件成立，即 big‑M 项为 0；或者该行涉及实际使用的弧或访问的节点。
- `tight`：在 active 行中取等号，也就是这条约束实际卡住了 SVNS 方案。这是“被限制次数”。
- `violated`：SVNS 解违反该行（取 M=300）的次数。

需要注意以下几点：

1. **tight 不等于必要。**冗余约束也可能取等号，例如式 (8)–(11) 和 (17) 都会在某些行取等号。判断能否删除，应以理论证明和 COPT 删约束实验为准。
2. 式 (4)–(7)、(14)、(15)、(24) 只涉及 u、w、p 等序号变量。这些变量的取值不唯一，所以它们的 tight 次数只反映本脚本选择的一种表示，不能直接说明约束是否必要。
3. 式 (30) 中含有“二元变量 × 连续变量”的乘积，本脚本按精确线性化拆成 30a 和 30b 两行。
4. 行数很大的式 (18)、(37) 只逐行计算 active 行；其余行的数量由公式统计，并已核对 M 足以覆盖时间范围。

## 3. 复现

```bash
python3 selftest.py            # 一致性测试
python3 run_svns_audit.py      # 约 1 分钟，生成 outputs/ 与 copt_ready/
```

## 4. COPT 验证（需要 coptpy 和正式许可证）

```bash
pip install coptpy
python3 copt_model.py --case C_3_4 --profile corrected --warm-start --time-limit 3600
python3 copt_model.py --case C_3_4 --profile reduced   --warm-start --time-limit 3600
python3 copt_model.py --case C_3_4 --profile corrected --drop 26 --warm-start
python3 run_copt_experiments.py --cases C_3_4 R_3_4 RC_3_4 --warm-start --time-limit 3600
python3 copt_model.py --case C_3_4 --profile corrected --write-only   # 只导出 .mps
```

### 三种模型的区别

- `paper`：完全按照 PDF 印刷版本建模。
- `corrected`：在 `paper` 基础上加入三处修正，原 Gurobi notebook 已经包含这三处修正：
  1. 增加 Σx₀ᵢ=1；
  2. 式 (18) 的定义域改为 N₁×N₂；
  3. 式 (30) 也作用于起点 l=0。
- `reduced`：在 `corrected` 基础上进行精简：
  - 删除式 (7)、(14)、(17)、(26)；
  - 用 Σ起飞弧≤1 替代式 (8)–(11) 和线性化式 (47)–(49)；
  - 把式 (12)(13) 扩展到点目标，并删除式 (21)(22)。

### 求解结果的判读

- `delta_vs_corrected = 0` 且 `physical_ok = True`：在这个算例上，删除该约束是安全的。
- 如果只违反 (7)、(14)、(26) 这类序号或等待约束，而 `physical_ok = True`，说明违反是无害的：物理方案和目标值都没有变化。
- 已知的 Gurobi 目标值（原投稿，未重算）：C-4-3 为 7.48，R-4-3 为 7.47，RC-4-3 为 7.895。COPT 求解 `corrected` 模型时，最优值应与这些数值一致或接近。

小算例 *_3_4 的模型规模约为 6.9k 列、2.4–2.6 万行（按线性化后统计）。主要行数来自 (18)、(19) 的辅助行、(37) 和 (23)。因此，减少论文中的约束条数，对求解器规模影响不大。

## 5. 小算例 COPT 实验（`run_copt_small.py`）

```bash
export COPT_LICENSE_DIR=~/copt          # 许可证 license.dat / license.key 所在目录
python3 run_copt_small.py --cases C_3_4 --profiles reduced --no-warm-start --time-limit 300
python3 run_copt_small.py --cases C_3_4 --profiles corrected --time-limit 300
```

- `outputs/copt_small_runs_*.csv`：目标值、下界、gap、可执行性检查，以及解违反了修正模型的哪些约束。
- `outputs/copt_small_binding_*.csv`：修正模型 COPT 解的逐式生效/取等次数。
  - `raw_*`：直接用 COPT 返回的变量值统计。不影响目标的时间变量可以在松弛范围内任取，辅助变量 q 也可以无意义地取 1，所以 (37) 等式的 raw 次数偏大。
  - `canon_*`：把 COPT 路线用 SVNS 计时器重新计时（按最早时刻）后再统计，口径与 SVNS 审计一致，**以此为准**。
- 已有结果（C‑4‑3，每次 5 分钟）：
  - 精简模型冷启动找到 7.4799，可执行，只违反已删除的 (14)。下界 7.208，gap 3.6%。
  - 修正模型最优解为 7.4799。下界 7.071，gap 5.5%。
- C‑4‑3 两个模型各跑 40 分钟。两者同时运行，各用 5 线程，并都以 SVNS 解作初始解：

  | 模型 | 最好解 | 下界 | gap | 节点数 | gap≤5% 用时 |
  |---|---|---|---|---|---|
  | 精简模型 | 7.4799 | 7.1840 | 3.96% | 867,508 | 210 s |
  | 修正模型 | 7.4799 | 7.1843 | 3.95% | 396,813 | 728 s |

  两个模型最终给出同一条备选路线，目标值也相同，都可以执行，且都不违反修正模型。两者都没有证明最优，下界大约从 1200 s 开始停在 7.184。

### 实时进度可视化

```bash
python3 run_copt_small.py --cases C_3_4 --profiles reduced   --time-limit 2400 --threads 5 --log-dir copt_logs --tag _40min &
python3 run_copt_small.py --cases C_3_4 --profiles corrected --time-limit 2400 --threads 5 --log-dir copt_logs --tag _40min &
python3 progress_dashboard.py --logs copt_logs/C_3_4_reduced_40min.log copt_logs/C_3_4_corrected_40min.log \
    --names reduced corrected --time-limit 2400 --port 8765    # 浏览器打开 http://127.0.0.1:8765
```

## 6. R-4-3 / RC-4-3 的 30 分钟运行与留档（第二轮返修）

- 运行脚本：`run_r_rc_30min.sh`。先跑 R-4-3，再跑 RC-4-3；每个算例的精简模型和修正模型同时运行，各用 5 线程，限时 1800 s，以 SVNS 解热启动。
- 运行记录：`copt_logs/run_r_rc_30min_manifest.txt`，含开始和结束时间。
- 求解日志：`copt_logs/{R,RC}_3_4_{reduced,corrected}_30min.log`。
- 结果文件：
  - `outputs/copt_small_runs_*_30min.csv`：汇总表。
  - `outputs/copt_small_stdout_*_30min.txt`：标准输出。
  - `copt_runs/*_30min.json`：完整解。
- RC-4-3 复核：两个模型都以精简模型 30 分钟的最好解（7.9140）热启动，再跑 30 分钟。
  - 热启动文件：`copt_ready/warm_start/RC_3_4_from_reduced30.json`。
  - 日志：`copt_logs/RC_3_4_*_30min_rerun.log`。
- C-4-3 不重跑，直接用 40 分钟日志中 1800 s 时的状态。
- 回复信用图和汇总：`make_letter_figures.py`，输出 `figures/letter_fig2_convergence_30min.png` 和 `outputs/letter_30min_summary.json`。
- 实时面板：`progress_dashboard.py` 支持 `--title` 和 `--fig-prefix`。面板截图保存在 `figures/dashboard_*.png`。
- 论文路线核对：`check_paper_routes.py`。论文路线表中 R/RC 的路线是 SVNS 解，不是 Gurobi 解，所以复算值分别为 8.634 和 8.124。
- 论文修改：`apply_constraint_revision.py`。
  - 同时修改 marked 和 unmarked 两个版本，原文件备份为 `main.tex.before_constraint_reduction`。
  - marked 版本中的修改为黑色加粗。
