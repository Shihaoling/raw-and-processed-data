"""Figures and summary numbers for the response letter (30-minute COPT runs on C-4-3, R-4-3, RC-4-3).

C-4-3 uses the 40-minute logs truncated at 1800 s (no re-run); R-4-3 and RC-4-3 use the 30-minute runs.
Run:  python3 make_letter_figures.py   -> figures/letter_*.png, outputs/letter_30min_summary.json
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from progress_dashboard import ROW, num  # noqa: E402

HERE = Path(__file__).resolve().parent
FIG, OUT, LOGS = HERE / "figures", HERE / "outputs", HERE / "copt_logs"
LIMIT = 1800.0
RED, BLUE, GREY = "#c0392b", "#2e6fb7", "#7f8c8d"
GUROBI = {"C-4-3": 7.48, "R-4-3": 7.47, "RC-4-3": 7.895}
CASES = {
    "C-4-3": {"reduced": LOGS / "C_3_4_reduced_40min.log", "corrected": LOGS / "C_3_4_corrected_40min.log"},
    "R-4-3": {"reduced": LOGS / "R_3_4_reduced_30min.log", "corrected": LOGS / "R_3_4_corrected_30min.log"},
    "RC-4-3": {"reduced": LOGS / "RC_3_4_reduced_30min.log", "corrected": LOGS / "RC_3_4_corrected_30min.log"},
}
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "savefig.dpi": 300})


def points(path: Path):
    pts = []
    if not path.exists():
        return pts
    for line in path.read_text(errors="ignore").splitlines():
        m = ROW.match(line)
        if m:
            _, nodes, _, _, _, b, s, g, t = m.groups()
            if float(t) <= LIMIT + 1e-6:
                pts.append(dict(t=float(t), bound=num(b), sol=num(s), gap=num(g), nodes=int(nodes)))
    return pts


def model_size(path: Path):
    txt = path.read_text(errors="ignore") if path.exists() else ""
    for line in txt.splitlines():
        if "rows," in line and "columns" in line and "non-zero" in line:
            a = line.replace(",", " ").split()
            return dict(rows=int(a[0]), cols=int(a[2]), nnz=int(a[5]))
    return {}


RERUN = {"RC-4-3 rerun": {"reduced": LOGS / "RC_3_4_reduced_30min_rerun.log",
                          "corrected": LOGS / "RC_3_4_corrected_30min_rerun.log"}}


def summary():
    res = {}
    for case, logs in {**CASES, **RERUN}.items():
        res[case] = {}
        for prof, path in logs.items():
            pts = points(path)
            if not pts:
                continue
            last = pts[-1]
            first = lambda g: next((p["t"] for p in pts if p["gap"] is not None and p["gap"] <= g), None)  # noqa
            best_sol = min(p["sol"] for p in pts if p["sol"] is not None)
            t_best = next(p["t"] for p in pts if p["sol"] is not None and abs(p["sol"] - best_sol) < 1e-6)
            res[case][prof] = dict(incumbent=best_sol, bound=last["bound"], gap=last["gap"], last_t=last["t"],
                                   nodes=last["nodes"], t_gap10=first(10), t_gap5=first(5), t_best=t_best,
                                   gurobi=GUROBI[case.split()[0]], **model_size(path))
    return res


def fig_convergence(res):
    fig, ax = plt.subplots(2, 3, figsize=(7.4, 4.4), sharex=True)
    for k, case in enumerate(CASES):
        for prof, c, name in (("reduced", RED, "Reduced"), ("corrected", BLUE, "Full (corrected)")):
            pts = points(CASES[case][prof])
            if not pts:
                continue
            t = [p["t"] for p in pts]
            ax[0, k].step(t, [p["sol"] for p in pts], where="post", color=c, lw=1.5, label=f"{name}: incumbent")
            ax[0, k].step(t, [p["bound"] for p in pts], where="post", color=c, lw=1.2, ls="--",
                          label=f"{name}: lower bound")
            ax[1, k].step(t, [p["gap"] for p in pts], where="post", color=c, lw=1.5, label=name)
        ax[0, k].axhline(GUROBI[case], color=GREY, lw=0.8, ls=":")
        ax[0, k].text(LIMIT, GUROBI[case] + 0.1, f"Gurobi (paper) {GUROBI[case]}", ha="right", fontsize=6.5,
                      color=GREY)
        ax[0, k].set_ylim(2.5, 9.5)
        ax[0, k].set_title(case, fontsize=10)
        ax[1, k].axhline(5, color=GREY, lw=0.8, ls=":")
        ax[1, k].set_ylim(0, 70)
        ax[1, k].set_xlim(0, LIMIT)
        ax[1, k].set_xlabel("Time (s)")
    ax[0, 0].set_ylabel("Objective")
    ax[1, 0].set_ylabel("Gap (%)")
    h, l = ax[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=4, fontsize=7, frameon=False)
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    fig.savefig(FIG / "letter_fig2_convergence_30min.png")
    plt.close(fig)


def fig_incumbent():
    fig, ax = plt.subplots(1, 3, figsize=(7.4, 2.5), sharey=False)
    for k, case in enumerate(CASES):
        for prof, c, name in (("corrected", BLUE, "Full model"), ("reduced", RED, "Revised model")):
            pts = [p for p in points(CASES[case][prof]) if p["sol"] is not None]
            if not pts:
                continue
            t = [p["t"] for p in pts] + [LIMIT]
            v = [p["sol"] for p in pts] + [pts[-1]["sol"]]
            ax[k].step(t, v, where="post", color=c, lw=1.6, ls="-" if prof == "reduced" else "--", label=name)
        g = GUROBI[case]
        ax[k].axhline(g, color=GREY, lw=0.9, ls=":", label="Gurobi value in the paper")
        lo = g - 0.15
        ax[k].set_ylim(lo, max(g + 1.3, 8.8))
        ax[k].set_xlim(0, LIMIT)
        ax[k].set_title(case, fontsize=10)
        ax[k].set_xlabel("Time (s)")
    ax[0].set_ylabel("Best objective found")
    h, l = ax[0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=3, fontsize=7.5, frameon=False)
    fig.tight_layout(rect=(0, 0, 1, 0.9))
    fig.savefig(FIG / "letter_fig2b_incumbent_30min.png")
    plt.close(fig)


def main():
    FIG.mkdir(exist_ok=True)
    res = summary()
    fig_incumbent()
    (OUT / "letter_30min_summary.json").write_text(json.dumps(res, indent=1), encoding="utf-8")
    fig_convergence(res)
    for case, d in res.items():
        for prof, r in d.items():
            print(case, prof, {k: r[k] for k in ("incumbent", "bound", "gap", "last_t", "t_gap5", "t_best", "nodes")})


if __name__ == "__main__":
    main()
