"""Model data (sets and parameters) of the first-stage MILP, eqs. (1)-(43) of the R1 PDF.

Node numbering is identical to SVNS / rtar_core: 0 = origin, 1..C = operational
nodes N_p, then the coverage nodes of targets 0,1,2,... in instance order, and
finally the destination |N|.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np

HERE = Path(__file__).resolve().parent
CURATED = HERE.parent / "inputs"
INSTANCES = CURATED / "00_instances"

# Generated-instance protocol of the manuscript (Sec. 6, curated README).
DEFAULTS = dict(truck_speed=20.0, drone_speed=30.0, LTD=0.1, RTD=0.1, DD=15.0, TD=200.0,
                tw=(0.0, 50.0), M=300.0)


@dataclass
class MilpData:
    case: str
    coords: np.ndarray
    Np: List[int]
    dest: int
    S: List[int]
    Ns: Dict[int, List[int]]
    S_node: set
    pairs: Dict[int, List[Tuple[int, int]]]
    D: List[int]
    nu: int
    tk: np.ndarray
    td: np.ndarray
    service: Dict[int, float]
    TK: Dict[int, Tuple[float, float]]
    TW: Dict[int, Tuple[float, float]]
    DD: float
    TD: float
    LTD: float
    RTD: float
    M: float
    target_of: Dict[int, int] = field(default_factory=dict)

    @property
    def origin(self) -> int:
        return 0

    @property
    def C(self) -> int:
        return len(self.Np)

    @property
    def N1(self) -> List[int]:
        return [0] + self.Np

    @property
    def N2(self) -> List[int]:
        return self.Np + [self.dest]

    @property
    def N3(self) -> List[int]:
        return [0] + self.Np + [self.dest]

    def arcs(self, s: int) -> List[Tuple[int, int]]:
        """Drone arcs of target s: N1->Ns (launch), Ns->Ns (internal), Ns->N2 (retrieval).

        Self-loops and direct N1->N2 arcs are omitted: (15) forces y_ii = 0 and direct
        launch-to-retrieval arcs appear in no paper constraint except with a positive
        cost in (42), so they can be fixed to zero without loss.
        """
        ns = self.Ns[s]
        out = [(a, j) for a in self.N1 for j in ns]
        out += [(i, j) for i in ns for j in ns if i != j]
        out += [(i, b) for i in ns for b in self.N2]
        return out

    def to_json(self) -> dict:
        return {
            "case": self.case,
            "node_numbering": "0=origin, 1..C=operational nodes N_p, coverage nodes, |N|=destination",
            "coords": self.coords.tolist(),
            "N_p": self.Np, "dest": self.dest,
            "S": self.S, "N_s": {str(s): v for s, v in self.Ns.items()},
            "S_node": sorted(self.S_node),
            "pairs_eq16": {str(s): v for s, v in self.pairs.items()},
            "D": self.D, "nu_bar": self.nu,
            "speeds": {"truck": DEFAULTS["truck_speed"], "drone": DEFAULTS["drone_speed"]},
            "travel_time_rule": "Euclidean distance / speed (truck 20, drone 30)",
            "service_time": {str(k): v for k, v in self.service.items() if v},
            "TK": {str(k): v for k, v in self.TK.items()},
            "TW_target": {str(k): v for k, v in self.TW.items()},
            "DD": self.DD, "TD": self.TD, "LTD": self.LTD, "RTD": self.RTD, "M": self.M,
        }


def _pairs(ns: List[int]) -> List[Tuple[int, int]]:
    # Gurobi notebook: pairs (N_s[i-2], N_s[i-1]) for i = 2, 4, ... i.e. sweep-line endpoints.
    return [(ns[k], ns[k + 1]) for k in range(0, len(ns) - 1, 2)]


def build(case: str, drones: List[int], instance_path: Path | None = None, **overrides) -> MilpData:
    p = dict(DEFAULTS)
    p.update(overrides)
    area = case.split("_")[1]
    path = instance_path or INSTANCES / area / f"instance_{case}.json"
    inst = json.loads(Path(path).read_text(encoding="utf-8"))
    coords = np.vstack((np.array([0.0, 0.0]), np.asarray(inst["total_stop_nodes"], dtype=float)))
    Np = list(range(1, len(coords)))
    Ns, target_of, S_node = {}, {}, set()
    for key in sorted(inst["coverage_points"], key=int):
        s = int(key)
        start = len(coords)
        coords = np.vstack((coords, np.asarray(inst["coverage_points"][key], dtype=float)))
        Ns[s] = list(range(start, len(coords)))
        for n in Ns[s]:
            target_of[n] = s
        if inst["area_type"][key] == "point":
            S_node.add(s)
    coords = np.vstack((coords, np.array([100.0, 100.0])))
    dest = len(coords) - 1
    dist = np.linalg.norm(coords[:, None, :] - coords[None, :, :], axis=2)
    S = sorted(Ns)
    lo, hi = p["tw"]
    return MilpData(
        case=case, coords=coords, Np=Np, dest=dest, S=S, Ns=Ns, S_node=S_node,
        pairs={s: _pairs(Ns[s]) for s in S if s not in S_node},
        D=list(drones), nu=len(drones),
        tk=dist / p["truck_speed"], td=dist / p["drone_speed"],
        service={n: 0.0 for n in range(len(coords))},
        TK={j: (lo, hi) for j in Np + [dest]}, TW={s: (lo, hi) for s in S},
        DD=p["DD"], TD=p["TD"], LTD=p["LTD"], RTD=p["RTD"], M=p["M"], target_of=target_of,
    )
