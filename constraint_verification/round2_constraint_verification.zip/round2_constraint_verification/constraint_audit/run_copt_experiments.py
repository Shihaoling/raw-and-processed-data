"""Batch COPT experiments: full / corrected / reduced models and single-constraint drops.

Run (licence-free COPT handles the toy instances; the *_3_4 instances need a licence):
    python3 run_copt_experiments.py                       # TOY_1D TOY_2D
    python3 run_copt_experiments.py --cases C_3_4 R_3_4 RC_3_4 --time-limit 3600 --warm-start

Output: outputs/copt_experiments_<cases>.csv  (one line per case x configuration)
  objective        COPT objective of the solved model
  delta_vs_corrected  objective minus that of the corrected (full, valid) model
  physical_ok      decoded plan re-timed by the SVNS evaluator is executable and passes the audit
  evaluator_completion  completion time of the decoded plan under the SVNS timing rules
  violated_reference    corrected-model equations violated by the COPT solution
A dropped constraint is "safe" on an instance when delta_vs_corrected = 0 and physical_ok
holds; it is "harmlessly violated" when only order/auxiliary rows such as (7), (14), (26)
are violated while the physical plan is unchanged.
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

from copt_model import solve

HERE = Path(__file__).resolve().parent

CONFIGS = [
    ("paper model as printed", "paper", []),
    ("corrected model (reference)", "corrected", []),
    ("reduced model (proposal)", "reduced", []),
    ("corrected - (2)", "corrected", ["2"]),
    ("corrected - (7)", "corrected", ["7"]),
    ("corrected - (8)-(11)", "corrected", ["8", "9", "10", "11"]),
    ("corrected - (14)", "corrected", ["14"]),
    ("corrected - (17)", "corrected", ["17"]),
    ("corrected - (26)", "corrected", ["26"]),
    ("corrected - (21)(22) [no unification: negative control]", "corrected", ["21", "22"]),
    ("corrected - (16)", "corrected", ["16"]),
    ("corrected - (23)", "corrected", ["23"]),
    ("corrected - (37)", "corrected", ["37"]),
    ("corrected - (38)-(41)", "corrected", ["38", "39", "40", "41"]),
    ("corrected - (42)", "corrected", ["42"]),
    ("corrected - (43)", "corrected", ["43"]),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases", nargs="*", default=["TOY_1D", "TOY_2D"])
    ap.add_argument("--time-limit", type=float, default=600)
    ap.add_argument("--warm-start", action="store_true")
    args = ap.parse_args()
    import coptpy

    env = coptpy.Envr()
    out = []
    for case in args.cases:
        ref = None
        for label, profile, drop in CONFIGS:
            r = solve(case, profile, drop, time_limit=args.time_limit, warm_start=args.warm_start, env=env, log=False)
            obj = r.get("objective")
            if profile == "corrected" and not drop:
                ref = obj
            pc = r.get("physical_check", {})
            ok = pc.get("evaluator_completion") is not None and not pc.get("evaluator_reason") and not pc.get("audit_problems")
            viol = r.get("reference_violations", {})
            out.append(dict(case=case, configuration=label, profile=profile, dropped=" ".join(drop),
                            rows=r["rows"], cols=r["cols"], status=r.get("status"),
                            objective="" if obj is None else round(obj, 6),
                            gap="" if obj is None else r.get("gap"),
                            runtime_s=round(r.get("runtime_s", 0), 3),
                            delta_vs_corrected="" if obj is None or ref is None else round(obj - ref, 6),
                            physical_ok=ok,
                            evaluator_completion="" if pc.get("evaluator_completion") is None else round(pc["evaluator_completion"], 6),
                            physical_issue=(pc.get("evaluator_reason") or "; ".join(pc.get("audit_problems", [])[:2]) or ""),
                            violated_reference=" ".join(f"({e}):{v['violated_rows']}" for e, v in sorted(viol.items()))))
            print(f"{case:7s} {label:55s} obj={out[-1]['objective']!s:>10s} d={out[-1]['delta_vs_corrected']!s:>10s} "
                  f"phys={ok!s:5s} viol={out[-1]['violated_reference']}", flush=True)
    path = HERE / "outputs" / f"copt_experiments_{'_'.join(args.cases)}.csv"
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=list(out[0]))
        w.writeheader()
        w.writerows(out)
    print("written", path)


if __name__ == "__main__":
    main()
