"""Map an SVNS plan to a point (values of every MILP variable) of the first-stage model.

Times come from the validated schedule evaluator ``rtar_core.rtar.evaluate``, which
reproduces SVNS ``get_total_time``.  The mapping also records structural features
that the MILP indexing cannot represent (index collisions) and features that
matter for individual constraints (closed sorties, depot-ended sorties, hovering).
"""

from __future__ import annotations

import sys
from collections import Counter
from typing import Dict, List, Tuple

from milp_data import CURATED, MilpData

sys.path.insert(0, str(CURATED / "08_scripts"))
from rtar_core import rtar  # noqa: E402


def build_point(data: MilpData, truck_route: List[int], drone_route: Dict) -> Tuple[Dict, dict, list]:
    params = rtar.Params(drone_speed=30.0, truck_speed=20.0, launch_time=data.LTD, retrieval_time=data.RTD,
                         endurance=data.DD, truck_endurance=data.TD)
    raw = {int(d): {int(k): list(map(int, r)) for k, r in s.items()} for d, s in drone_route.items()}
    plan = rtar.plan_from_result(data.coords, truck_route, raw, data.target_of, params,
                                 inspection={n: data.service[n] for n in range(len(data.coords))})
    sched = rtar.evaluate(plan)
    reason = rtar.check_constraints(plan, sched)

    P: Dict = {}
    collisions: List[str] = []

    def put(key, value):
        if key in P and abs(P[key] - value) > 1e-9:
            collisions.append(f"{key}: {P[key]:.6f} vs {value:.6f}")
        P[key] = value

    truck = list(map(int, truck_route))
    # truck arcs, order u, precedence p
    for a, b in zip(truck, truck[1:]):
        put(("x", a, b), 1.0)
    visited = [n for n in truck if n != data.dest]
    unvisited = [n for n in data.Np if n not in truck]
    order = visited + unvisited
    u = {n: float(k) for k, n in enumerate(order)}
    u[data.dest] = float(data.C + 1)
    for n, val in u.items():
        put(("u", n), val)
    for i in data.N3:
        for j in data.N3:
            if i != j and u[i] < u[j]:
                put(("p", i, j), 1.0)
    for n in truck:
        put(("tA", n), sched.truck_arrival[n])
        put(("tL", n), sched.truck_leave[n])

    sorties = []
    for d, routes in plan.drones.items():
        per_target = Counter()
        for si, route in enumerate(routes):
            cov = route[1:-1]
            s = data.target_of[cov[0]]
            per_target[s] += 1
            a, b = route[0], route[-1]
            for i, j in zip(route, route[1:]):
                put(("y", s, d, i, j), 1.0)
            for pos, n in enumerate(cov, start=1):
                put(("z", s, d, n, a, b), 1.0)
                if s not in data.S_node:
                    put(("w", s, d, n), float(pos))
                put(("dA", d, n), sched.node_time[(d, si)][pos])
                put(("dL", d, n), sched.node_leave[(d, si)][pos])
            put(("dL", d, a), sched.launch[(d, si)])
            put(("dA", d, b), sched.retrieval[(d, si)])
            put(("q", d, a, b), 1.0)
            put(("v", a, b), 1.0)
            put(("mx", s, d), 1.0)
            if len(cov) > 1 and s not in data.S_node:
                put(("delta", s, d), 1.0)
            for i, j in zip(cov, cov[1:]):
                put(("h", s, d, i, j, a, b), 1.0)
            arrive_b = sched.node_time[(d, si)][-1]
            hover = max(0.0, sched.truck_arrival[b] - arrive_b)
            flight = sched.flight_time[(d, si)]
            sorties.append(dict(drone=d, sortie=si, target=s, point_target=s in data.S_node, launch=a, retrieval=b,
                                n_nodes=len(cov), closed=a == b, from_origin=a == 0, to_destination=b == data.dest,
                                flight_plus_service=flight, hover_wait_at_retrieval=hover,
                                flight_plus_hover=flight + hover, DD=data.DD))
        for s, k in per_target.items():
            if k > 1:
                collisions.append(f"drone {d} has {k} sorties on target {s}")
    struct = dict(
        completion=sched.completion,
        evaluator_feasible=reason is None,
        evaluator_reason=reason or "",
        n_sorties=len(sorties),
        closed_sorties=sum(x["closed"] for x in sorties),
        sorties_from_origin=sum(x["from_origin"] for x in sorties),
        sorties_to_destination=sum(x["to_destination"] for x in sorties),
        sorties_with_hover=sum(x["hover_wait_at_retrieval"] > 1e-9 for x in sorties),
        max_hover=max((x["hover_wait_at_retrieval"] for x in sorties), default=0.0),
        max_flight_ratio=max((x["flight_plus_service"] / data.DD for x in sorties), default=0.0),
        max_flight_plus_hover_ratio=max((x["flight_plus_hover"] / data.DD for x in sorties), default=0.0),
        index_collisions=len(collisions),
        collision_examples="; ".join(collisions[:3]),
        horizon=max(v for k, v in P.items() if k[0] in ("tA", "tL", "dA", "dL")),
    )
    return P, struct, sorties
