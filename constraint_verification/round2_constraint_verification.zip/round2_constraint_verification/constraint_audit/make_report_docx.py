"""Build the English Word report on the constraint reduction and its COPT verification.

Run:  python3 make_report_figures.py && python3 make_report_docx.py
Output: ../Constraint_Reduction_and_COPT_Verification.docx
Text markup: **bold**, $inline LaTeX$ (rendered as native Word equations via omml.py).
"""

from __future__ import annotations

import csv
import json
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_TAB_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

from omml import add_equation

HERE = Path(__file__).resolve().parent
FIG, OUT = HERE / "figures", HERE / "outputs"
DOCX = HERE.parent / "reports" / "Constraint_Reduction_and_COPT_Verification_regenerated.docx"

doc = Document()
_fig_n = [0]
_tab_n = [0]


# --------------------------------------------------------------------------- helpers
def setup():
    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    st.font.size = Pt(11)
    st.paragraph_format.space_after = Pt(4)
    st.paragraph_format.line_spacing = 1.12
    for s in ("Heading 1", "Heading 2", "Title"):
        doc.styles[s].font.name = "Times New Roman"
        doc.styles[s].element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
        doc.styles[s].font.color.rgb = RGBColor(0x1F, 0x3A, 0x5F)
    doc.styles["Title"].font.size = Pt(20)
    sec = doc.sections[0]
    sec.left_margin = sec.right_margin = Inches(1.0)
    sec.top_margin = sec.bottom_margin = Inches(0.9)


def _rich(p, text, italic=False, size=None):
    """$...$ -> inline native equation; **...** -> bold (bold state carries across equations)."""
    bold = False
    for k, seg in enumerate(text.split("$")):
        if k % 2 == 1:
            if seg:
                add_equation(p, seg, size_pt=size)
            continue
        for m, part in enumerate(seg.split("**")):
            if m > 0:
                bold = not bold
            if not part:
                continue
            r = p.add_run(part)
            r.bold = bold
            r.italic = italic
            if size:
                r.font.size = Pt(size)


def para(text="", italic=False, size=None, align=None):
    p = doc.add_paragraph()
    _rich(p, text, italic=italic, size=size)
    if align is not None:
        p.alignment = align
    return p


def bullet(text):
    p = doc.add_paragraph(style="List Bullet")
    _rich(p, text)
    return p


def equation(latex, tag=None):
    """Display equation (native Word math), centred, tag right-aligned."""
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.space_before, pf.space_after = Pt(3), Pt(3)
    pf.tab_stops.add_tab_stop(Inches(3.25), WD_TAB_ALIGNMENT.CENTER)
    pf.tab_stops.add_tab_stop(Inches(6.5), WD_TAB_ALIGNMENT.RIGHT)
    p.add_run("\t")
    add_equation(p, latex)
    if tag:
        p.add_run("\t" + tag)
    return p


def figure(path, caption, width=6.3):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_with_next = True
    p.add_run().add_picture(str(path), width=Inches(width))
    _fig_n[0] += 1
    c = doc.add_paragraph()
    c.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = c.add_run(f"Figure {_fig_n[0]}. ")
    r.bold = True
    r.font.size = Pt(9.5)
    _rich(c, caption, size=9.5)


def shade(cell, hex_color):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color)
    tcPr.append(shd)


def table(header, rows, caption, widths=None, size=8.5, highlight=None):
    _tab_n[0] += 1
    c = doc.add_paragraph()
    c.paragraph_format.keep_with_next = True
    r = c.add_run(f"Table {_tab_n[0]}. ")
    r.bold = True
    r.font.size = Pt(9.5)
    _rich(c, caption, size=9.5)
    t = doc.add_table(rows=1, cols=len(header))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    for i, h in enumerate(header):
        cell = t.rows[0].cells[i]
        cell.text = ""
        _rich(cell.paragraphs[0], f"**{h}**", size=size)
        shade(cell, "DCE6F1")
    for k, row in enumerate(rows):
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            _rich(cells[i].paragraphs[0], str(v), size=size)
            fill = highlight(k, row) if highlight else None
            if fill:
                shade(cells[i], fill)
    if widths:
        for i, w in enumerate(widths):
            t.columns[i].width = Inches(w)
        for row in t.rows:
            for i, w in enumerate(widths):
                row.cells[i].width = Inches(w)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def box(lines, fill="EAF2E3"):
    t = doc.add_table(rows=1, cols=1)
    t.style = "Table Grid"
    cell = t.rows[0].cells[0]
    shade(cell, fill)
    cell.text = ""
    for k, line in enumerate(lines):
        p = cell.paragraphs[0] if k == 0 else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(3)
        _rich(p, line, size=10)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


# --------------------------------------------------------------------------- data
def load_csv(path):
    return list(csv.DictReader(open(path, encoding="utf-8-sig")))


svns = {r["eq"]: r for r in load_csv(OUT / "summary_main_corrected_model.csv")}
toy = load_csv(OUT / "copt_experiments_TOY_1D_TOY_2D.csv")
runs = json.loads((OUT / "c43_run_stats.json").read_text(encoding="utf-8"))
r40 = {p: json.loads((HERE / "copt_runs" / f"C_3_4_{p}_40min.json").read_text(encoding="utf-8"))
       for p in ("reduced", "corrected")}
bind = {r["eq"]: r for r in load_csv(OUT / "copt_small_binding_C_3_4_corrected_40min.csv")}


def sv(eq):
    r = svns[f"({eq})"]
    return f"{int(r['active']):,} / {int(r['tight']):,}"


def cb(eq):
    r = bind[f"({eq})"]
    return f"{r['canon_active']} / {r['canon_tight']}"


# --------------------------------------------------------------------------- title and summary
setup()
doc.add_paragraph("Simplifying the First-Stage MILP: Reduced Formulation, Justification, and COPT Verification",
                  style="Title")
para("Manuscript: Drone Failure-Aware Truck-Drone Collaborative Routing for Multi-Type Coverage Tasks "
     "(second revision). Equation numbers refer to the R1 PDF: objective (1) and constraints (2)-(43) of the "
     "first-stage model; (47)-(49) are the linearisation constraints of Section 4.3.", italic=True, size=9.5)

doc.add_heading("1. Summary", level=1)
box([
    "**Result.** The 42 first-stage constraints (2)-(43) can be reduced to **28 numbered constraints** without "
    "changing the set of executable plans or the optimal value:",
    "•  **9 constraints are removed**: (7), (8), (10), (11), (14), (17), (21), (22), (26);",
    "•  **(9) is replaced** by an unconditional bound (9'), which also removes the auxiliary variable "
    "$\\delta_s^d$ and its linearisation (47)-(49);",
    "•  **(12)-(13) are extended** to point targets, which makes (21)-(22) redundant;",
    "•  **5 pairs are written as two-sided constraints**: (5)+(6), (31)+(32), (33)+(34), (38)+(39), (40)+(41).",
    "**Three corrections are needed independently of the reduction**: (2) becomes "
    "$\\sum_{i\\in N_2}x_{0i}=1$, and the domains of (18) and (30) are extended to the depots. Without them the "
    "printed model accepts plans that the truck cannot execute.",
    "**Evidence.** (i) All 105 stored SVNS plans satisfy every constraint. (ii) On two test instances solved "
    "to proven optimality, the reduced and full models have identical optima, whereas removing "
    "(16), (23) or (37) produces unexecutable plans. (iii) With 30-minute COPT runs, both models reach the Gurobi "
    "values of R1 on C-4-3 (7.4799) and R-4-3 (7.4748). On RC-4-3 both reach 7.9140, 0.24% above the Gurobi "
    "value 7.895, with lower bounds below 7.895. Every returned plan is executable, and the full model accepts "
    "the reduced model's plans. Solve times vary between runs; overall the two models are comparable in speed.",
])

# --------------------------------------------------------------------------- 2. corrections
doc.add_heading("2. Corrections to the printed model (required before reduction)", level=1)
para("The model as printed in R1 contains three domain errors. The original Gurobi implementation already "
     "contained the corrected forms, so the reported Gurobi values are not affected, but the text of the "
     "paper must be corrected. All results below use the corrected model as the reference.")

doc.add_heading("2.1 Depot constraint (2)", level=2)
equation(r"\sum_{i\in N_2}x_{0i}=\sum_{i\in N_1}x_{i|N|}", "(2) printed")
equation(r"\sum_{i\in N_2}x_{0i}=1", "(2') corrected")
para("**Reason.** The printed constraint only equates outflow from the origin with inflow to the destination. "
     "It is satisfied both by a truck that never leaves (all $x_{ij}=0$) and by several departures. Constraint "
     "(2') fixes exactly one departure. Summing flow conservation (3) over $N_p$ then gives exactly one arrival "
     "at the destination, so the printed (2) is implied and can be dropped.")

doc.add_heading("2.2 Node-sortie link (18): domain extended to the depots", level=2)
equation(r"z_{jab}^{sd}+z_{iab}^{sd}\geq y_{ai}^{sd}+y_{jb}^{sd}-M(2-y_{ai}^{sd}-y_{jb}^{sd})", "(18')")
equation(r"\forall s\in S,\ d\in D,\ a\in N_1,\ b\in N_2,\ i,j\in N_s\qquad"
         r"(\mathrm{printed}:\ a,b\in N_p)")
para("**Reason.** The printed domain $a,b\\in N_p$ omits every sortie that starts at the origin or ends at the "
     "destination. For such sorties $z_{iab}^{sd}$ can be assigned to a wrong launch-retrieval pair, and the "
     "coordination constraint (23), which requires the truck to visit $a$ and $b$, is bypassed. In the 30 SVNS "
     "plans, 186 of 401 sorties start at the origin or end at the destination. On instance TOY_1D the printed "
     "model returns 7.378 instead of the true optimum 7.908, with a drone retrieved at a node that the truck "
     "never visits.")

doc.add_heading("2.3 Drone launch time (30): domain extended to the origin", level=2)
equation(r"\hat{t}_{l}^{d}\geq (1-R_l^d)(\check{t}_l+LTD)+R_l^d(\check{t}_l^{d}+LTD)-M(1-L_l^d),"
         r"\quad \forall l\in N_1,\ d\in D", "(30')")
equation(r"L_l^d=\sum_{s\in S}\sum_{j\in N_s}y_{lj}^{sd},\qquad R_l^d=\sum_{s\in S}\sum_{i\in N_s}y_{il}^{sd},"
         r"\qquad R_0^d=0")
para("**Reason.** The printed domain is $l\\in N_p$, so a drone launched at the origin has no launch-time "
     "constraint at all. The 30 SVNS plans contain 80 such launches. The products $R_l^d\\check{t}_l$ and "
     "$R_l^d\\check{t}_l^d$ are linearised exactly, as two big-M rows for the cases $R_l^d=0$ and $R_l^d=1$.")

# --------------------------------------------------------------------------- 3. reductions
doc.add_heading("3. Proposed simplifications", level=1)
para("Table 1 lists every change. In the reason column, 'implied' means that every solution of the reduced "
     "model satisfies the removed constraint, or can be turned into one that does without changing the "
     "routes or the objective. Sections 3.1-3.7 give the formulas and the arguments.")
table(["Original", "Action", "Replacement", "Reason (one line)"],
      [["(7)", "remove", "-", "implied by (5)-(6) for every precedence variable used in (37)"],
       ["(8), (10), (11)", "remove", "-", "implied by flow conservation (13), MTZ (15) and (9')"],
       ["(9)", "replace", "(9'): $\\sum_{a\\in N_1}\\sum_{j\\in N_s}y_{aj}^{sd}\\leq 1$",
        "same meaning once (16) holds; removes $\\delta_s^d$ and (47)-(49)"],
       ["(14)", "remove", "domain $w_i^{sd}\\in\\mathbb{Z}_+$", "MTZ (15) needs no bounds on $w$"],
       ["(17)", "remove", "-", "$\\sum_{d}(\\mathrm{binary})\\leq |D|\\leq\\overline{\\nu}$ always"],
       ["(21), (22)", "remove", "(12'), (13') with $s\\in S$", "(21)-(22) are (12)-(13) for $|N_s|=1$"],
       ["(26)", "remove", "-", "waiting before arrival can be moved to the previous departure"],
       ["(5)+(6), (31)+(32), (33)+(34), (38)+(39), (40)+(41)", "merge", "two-sided rows",
        "identical feasible set, fewer equation numbers"],
       ["(2), (18), (30)", "correct", "(2'), (18'), (30')", "domain errors, see Section 2"]],
      "Overview of the reduction (equation numbers of the R1 PDF).", widths=[1.4, 0.6, 1.9, 2.6])

doc.add_heading("3.1 Remove (7): precedence symmetry is implied by (5)-(6)", level=2)
equation(r"u_i-u_j\geq 1-(C+2)p_{ij},\quad \forall i\in N_1,\ j\in N_2,\ i\neq j", "(5)")
equation(r"u_i-u_j\leq -1+(C+2)(1-p_{ij}),\quad \forall i\in N_1,\ j\in N_2,\ i\neq j", "(6)")
equation(r"p_{ij}+p_{ji}=1,\quad \forall i,j\in N_3,\ i\neq j", "(7) removed")
para("**Reason.** For binary $p_{ij}$, (5)-(6) state that $p_{ij}=1\\Rightarrow u_i<u_j$ and "
     "$p_{ij}=0\\Rightarrow u_i>u_j$. If both $(i,j)$ and $(j,i)$ belong to $N_1\\times N_2$, then $p_{ij}=1$ "
     "forces $u_i<u_j$, which rules out $p_{ji}=1$; likewise $p_{ij}=0$ forces $p_{ji}=1$. Hence "
     "$p_{ij}+p_{ji}=1$ already holds. The only precedence variables not fixed by (5)-(6) are $p_{a0}$. They "
     "appear only in rows of (37) whose second sortie is launched at the origin. With (7) these rows are "
     "switched off ($p_{a0}=1-p_{0a}=0$) in every executable plan, because the origin precedes every visited "
     "node. Without (7) the solver can also switch them off, so nothing changes. Removing (7) deletes "
     "$|N_3|(|N_3|-1)$ equality rows (56 rows on C-4-3).")

doc.add_heading("3.2 Replace (8)-(11) by one bound (9'); drop δ and (47)-(49)", level=2)
equation(r"1-M(1-\delta_s^d)\leq\sum_{i\in N_1}\sum_{j\in N_s}y_{ij}^{sd}\leq 1+M(1-\delta_s^d)",
         "(8),(9)")
equation(r"1-M(1-\delta_s^d)\leq\sum_{i\in N_s}\sum_{j\in N_2}y_{ij}^{sd}\leq 1+M(1-\delta_s^d)",
         "(10),(11)")
equation(r"\sum_{a\in N_1}\sum_{j\in N_s}y_{aj}^{sd}\leq 1,\quad \forall s\in S\backslash S_{node},\ d\in D",
         "(9') new")
para("**Reason.** Fix $s\\in S\\backslash S_{node}$ and $d\\in D$. Let $A^{sd}$ be the number of launch arcs "
     "($N_1\\rightarrow N_s$) and $B^{sd}$ the number of retrieval arcs ($N_s\\rightarrow N_2$) of drone $d$ "
     "for target $s$.")
bullet("**$A^{sd}=B^{sd}$ always.** Summing flow conservation (13) over all $p\\in N_s$ cancels every internal "
       "arc. Hence (10) ⇔ (8) and (11) ⇔ (9).")
bullet("**(8) is implied.** If drone $d$ uses an internal arc of target $s$ ($\\delta_s^d=1$), the internal arcs "
       "form paths because (15) excludes cycles. The first node of such a path is entered from $N_1$, so "
       "$A^{sd}\\geq 1$.")
bullet("**(9) becomes unconditional.** Constraint (16) requires every sweep pair $(i,i+1)$ of an area or line "
       "target to be flown consecutively, and every coverage node of such a target belongs to a sweep pair. "
       "So any drone that serves $s$ uses an internal arc, i.e. $\\delta_s^d=1$, and the gated bound (9) is "
       "equivalent to (9'). When $d$ does not serve $s$, (9') holds trivially because $A^{sd}=0$.")
para("With (9') no constraint uses $\\delta_s^d$ any more, so these variables and the linearisation "
     "(47)-(49) are removed as well. (9') still guarantees that each drone serves each target in at most one "
     "sortie, as stated in R1.")

doc.add_heading("3.3 Remove (14): the MTZ constraint (15) does not need bounds", level=2)
equation(r"1\leq w_i^{sd}\leq |N_s|", "(14) removed")
equation(r"w_i^{sd}-w_j^{sd}+|N_s|y_{ij}^{sd}\leq |N_s|-1", "(15) kept")
para("**Reason.** Subtour elimination comes from (15) alone: along any cycle of used arcs, (15) gives "
     "$w_j^{sd}\\geq w_i^{sd}+1$ for every arc, which is impossible. Conversely, for any feasible sortie, "
     "setting $w_i^{sd}$ equal to the visit position $1,2,\\ldots,|N_s|$ satisfies both (14) and (15), so (14) "
     "never removes a valid route. It is enough to declare $w_i^{sd}\\in\\mathbb{Z}_+$ in the variable "
     "definitions. On the C-4-3 solution of the reduced model, (14) is violated in some rows, but only because "
     "$w$ lies outside $[1,|N_s|]$. The routes and the objective are unchanged.")

doc.add_heading("3.4 Remove (17): capacity can never bind", level=2)
equation(r"\sum_{d\in D}\max_{i,j}\{y_{ij}^{sd}\}\leq\overline{\nu},\quad \forall s\in S", "(17) removed")
para("**Reason.** The left-hand side is a sum of $|D|$ binary terms, so it never exceeds $|D|$. $D$ is the set "
     "of drones carried by the truck, so $|D|\\leq\\overline{\\nu}$ (in all instances $|D|=\\overline{\\nu}$). "
     "The constraint therefore never binds, and its max-linearisation rows are removed as well. If a future "
     "variant allowed $|D|>\\overline{\\nu}$, (17) would have to be kept.")

doc.add_heading("3.5 Remove (21)-(22) by extending (12)-(13) to point targets", level=2)
equation(r"\sum_{d\in D}\sum_{i\in N_s\cup N_1,i\neq j}y_{ij}^{sd}=1,\quad \forall s\in S,\ j\in N_s", "(12')")
equation(r"\sum_{i\in N_s\cup N_1,i\neq p}y_{ip}^{sd}=\sum_{j\in N_s\cup N_2,j\neq p}y_{pj}^{sd},\quad "
         r"\forall s\in S,\ d\in D,\ p\in N_s", "(13')")
para("**Reason.** For a point target, $N_s=\\{j\\}$ contains one node, so $(N_s\\cup N_1)\\backslash\\{j\\}=N_1$ "
     "and $(N_s\\cup N_2)\\backslash\\{j\\}=N_2$. Then (12') and (13') are literally (21) and (22). Changing "
     "the domain from $s\\in S\\backslash S_{node}$ to $s\\in S$ therefore removes two constraints without "
     "changing the model. **Caution:** deleting (21)-(22) without extending (12)-(13) is wrong. On TOY_1D it "
     "gives a 5.5% lower, unexecutable plan (Figure 3).")

doc.add_heading("3.6 Remove (26): truck waiting can be moved to the previous departure", level=2)
equation(r"\check{t}_j\geq\hat{t}_i+t_{ij}-M(1-x_{ij}),\quad \forall i\in N_1,\ j\in N_2", "(25) kept")
equation(r"\check{t}_j\leq\hat{t}_i+t_{ij}+M(1-x_{ij}),\quad \forall i\in N_1,\ j\in N_2", "(26) removed")
para("**Reason.** Constraint (25) already says that the truck cannot reach node $j$ before it leaves node $i$ "
     "and travels to $j$. Constraint (26) additionally forbids arriving later. A later arrival only means that the "
     "truck waits on the way, and the same waiting can be spent at node $i$ before departure. The routes and the "
     "completion time stay the same, so removing (26) never changes the optimal value.")

doc.add_heading("3.7 Merge one-sided pairs into two-sided constraints", level=2)
equation(r"1-(C+2)p_{ij}\leq u_i-u_j\leq C+1-(C+2)p_{ij}", "(5') = (5)+(6)")
equation(r"|\hat{t}_j^{d}-\check{t}_j^{d}-t_j^s|\leq M\left(1-\sum_{i\in N_s\cup N_1}y_{ij}^{sd}\right)",
         "(31') = (31)+(32)")
equation(r"|\check{t}_j^{d}-\hat{t}_i^{d}-t_{ij}^{d}|\leq M(1-y_{ij}^{sd})", "(33') = (33)+(34)")
equation(r"TK_j^{min}-M\left(1-\sum_{i\in N_1}x_{ij}\right)\leq\check{t}_j\leq TK_j^{max}+M\left(1-"
         r"\sum_{i\in N_1}x_{ij}\right)", "(38') = (38)+(39)")
equation(r"TD_s^{min}-M\left(1-\sum_{i}y_{ij}^{sd}\right)\leq\check{t}_j^{d}\leq TD_s^{max}+M\left(1-"
         r"\sum_{i}y_{ij}^{sd}\right)", "(40') = (40)+(41)")
para("These are notational merges: the domains are unchanged and the feasible set is identical. They cut five "
     "equation numbers.")

doc.add_heading("3.8 Constraints that must be kept", level=2)
bullet("**(16), (23), (37)** look like candidates, because (37) is never tight in the SVNS plans. However, "
       "removing any of them lets COPT return a lower objective with an unexecutable plan (Figure 3). "
       "Without (16) a sweep line is not flown consecutively, without (23) launches and retrievals happen "
       "at nodes the truck does not visit, and without (37) one drone flies two sorties at the same time.")
bullet("**(38)-(43)** never bind on the benchmark, because the time windows are $[0,50]$, $DD=15$ and "
       "$TD=200$. They define the problem class, though, and must be kept. We recommend stating in the paper "
       "that they are not binding on the reported instances.")

doc.add_heading("3.9 Resulting reduced model", level=2)
table(["Block", "Constraints in the reduced model", "Count"],
      [["Depot", "(2')", "1"],
       ["Truck routing and precedence", "(3), (4), (5')", "3"],
       ["Drone routing", "(9'), (12'), (13'), (15), (16), (18'), (19), (20)", "8"],
       ["Truck-drone coordination", "(23), (24)", "2"],
       ["Truck timing", "(25), (27), (28), (29)", "4"],
       ["Drone timing", "(30'), (31'), (33'), (35), (36), (37)", "6"],
       ["Time windows", "(38'), (40')", "2"],
       ["Route and sortie duration", "(42), (43)", "2"],
       ["**Total**", "", "**28** (R1: 42)"]],
      "Constraint list of the reduced first-stage model (primes mark corrected, replaced or merged constraints).",
      widths=[1.9, 3.6, 1.0])
figure(FIG / "fig1_model_size.png",
       "(a) Number of numbered first-stage constraints. (b) Size of the solver model for C-4-3 after "
       "linearisation. The reduction mainly simplifies the paper; the solver model shrinks by only 2-3% "
       "because most rows come from (18), (19), (23) and (37), which are kept.")

# --------------------------------------------------------------------------- 4. verification
doc.add_heading("4. Computational verification", level=1)
para("**Set-up.** The corrected and reduced models are built from one row generator that also evaluates "
     "solutions, so the verified constraints are exactly the solved ones. Solver: COPT 8.0.7 (academic "
     "licence) on an Apple M5 (10 cores). Every COPT solution is decoded into routes and re-timed with the "
     "SVNS schedule evaluator. It is then checked for physical executability (launch and retrieval only at "
     "truck-visited nodes, sweep pairs flown consecutively, endurance) and against every row of the "
     "corrected model.")

doc.add_heading("4.1 Check 1: the 105 SVNS plans satisfy all constraints", level=2)
para("All 30 main-experiment plans and 75 fleet-size plans were mapped to MILP variable values and evaluated "
     "row by row. **No row of (2)-(43) is violated, in either the printed or the corrected model.** Figure 2 "
     "shows how often each constraint is active (its logical condition is switched on) and tight (it holds "
     "with equality). Removed constraints can be tight, e.g. (7), (8)-(11) and (26). Being tight does not make "
     "them necessary, since other constraints impose the same values. This is why the reduction relies on the "
     "proofs in Section 3 and the solver experiments below, not on tightness counts.")
figure(FIG / "fig6_svns_binding_counts.png",
       "Active and tight rows of each constraint over the 30 SVNS plans (corrected model, log scale). "
       "Colours show the proposed treatment.")

doc.add_heading("4.2 Check 2: optimality preserved on instances solved to proven optimality", level=2)
para("Two small instances, TOY_1D (1 drone; area, line and point targets) and TOY_2D (2 drones), were "
     "solved to proven optimality (gap 0) under 16 configurations. Results are in Table 3 and Figure 3.")
cfg_short = {"paper model as printed": "Printed model (no corrections)",
             "corrected model (reference)": "Corrected model (reference)",
             "reduced model (proposal)": "**Reduced model (proposal)**",
             "corrected - (21)(22) [no unification: negative control]": "Corrected − (21)(22), (12)(13) not extended"}
rows = []
for cfg in dict.fromkeys(r["configuration"] for r in toy):
    a = next(r for r in toy if r["case"] == "TOY_1D" and r["configuration"] == cfg)
    b = next(r for r in toy if r["case"] == "TOY_2D" and r["configuration"] == cfg)

    def f(r):
        return f"{float(r['objective']):.4f}" + ("" if r["physical_ok"] == "True" else " ✗")

    if cfg.startswith("paper"):
        verdict = "invalid (needs corrections)"
    elif cfg.startswith("corrected model"):
        verdict = "reference"
    elif cfg.startswith("reduced"):
        verdict = "**valid**"
    elif "negative control" in cfg:
        verdict = "only together with (12')(13')"
    elif a["physical_ok"] != "True" or b["physical_ok"] != "True":
        verdict = "must be kept"
    elif a["dropped"] == "2":
        verdict = "replaced by (2')"
    elif a["dropped"].split()[0] in ("38", "42", "43"):
        verdict = "not binding here; keep (problem definition)"
    else:
        verdict = "removable"
    rows.append([cfg_short.get(cfg, cfg.replace("corrected - ", "Corrected − ")), a["rows"], f(a), b["rows"], f(b),
                 verdict])
table(["Configuration", "Rows 1D", "Optimum TOY_1D", "Rows 2D", "Optimum TOY_2D", "Conclusion"], rows,
      "Proven optimal objective values (✗ = decoded plan not executable).",
      widths=[2.35, 0.55, 1.0, 0.55, 1.0, 1.05],
      highlight=lambda k, r: "FDECEA" if "✗" in str(r[2]) + str(r[4]) else ("EAF2E3" if "Reduced" in r[0] else None))
figure(FIG / "fig2_toy_verification.png",
       "Deviation of the proven optimum from the corrected model. The reduced model and every removed "
       "constraint keep the optimum (green dots). Missing corrections, or removing (16), (23) or (37), give "
       "lower but unexecutable plans (red).")

doc.add_heading("4.3 Check 3: the three small instances of the paper, 30-minute COPT runs", level=2)
para("C-4-3, R-4-3 and RC-4-3 each have 6 operational nodes, 2 drones, one area target (8 coverage nodes in 4 "
     "sweep pairs), one line target and one point target. For each instance, the reduced and the full (corrected) "
     "models were solved in parallel for 1800 s (5 threads each), starting from the SVNS plan. For C-4-3 the "
     "40-minute logs are evaluated at 1800 s.")
L = json.loads((OUT / "letter_30min_summary.json").read_text(encoding="utf-8"))
lrows = []
for case in ("C-4-3", "R-4-3", "RC-4-3"):
    for prof, name in (("corrected", "Full"), ("reduced", "**Reduced**")):
        r = L[case][prof]
        t5 = "-" if r["t_gap5"] is None else f"{r['t_gap5']:.0f} s"
        lrows.append([case, name, f"{r['incumbent']:.4f}", f"{r['bound']:.4f}", f"{r['gap']:.2f}%", t5,
                      f"{r['gurobi']}"])
table(["Instance", "Model", "Best objective", "Lower bound", "Gap", "Gap ≤ 5% at", "Gurobi (R1)"], lrows,
      "Results after 1800 s (same machine, same settings).", widths=[0.8, 0.8, 1.0, 1.0, 0.7, 0.9, 0.9],
      highlight=lambda k, r: "EAF2E3" if "Reduced" in r[1] else None)
para("**Feasibility and optimal value.** On C-4-3 and R-4-3 both models reach the Gurobi value reported in R1. "
     "On RC-4-3 the first 30-minute runs end at 7.9140 (reduced) and 7.9578 (full); a second 30-minute run of both "
     "models started from the 7.9140 plan ends at 7.9140 for both, 0.24% above the Gurobi value 7.895, while all "
     "lower bounds stay below 7.895. Every returned plan is executable when re-timed by the SVNS evaluator, and the "
     "full model accepts the reduced model's plan as a feasible start. The plans of the reduced model violate at most rows of removed constraints such as (7) or "
     "(14), and only in ways that do not affect routes or times (Sections 3.1 and 3.3). In an additional 300 s "
     "run on C-4-3 **without** a start solution, the reduced model found 7.4799 on its own.")
para("**Optimality.** No run closed the gap within 30 minutes. The lower bounds of the two models are of the "
     "same size on every instance (equal on C-4-3, higher for the reduced model on R-4-3 and for the full model "
     "on RC-4-3), so the reduction does not systematically weaken the relaxation.")
figure(FIG / "letter_fig2_convergence_30min.png",
       "30-minute runs on the three small instances: incumbent (solid), lower bound (dashed) and gap.")
figure(FIG / "fig5_c43_reduced_solution_routes.png",
       "Plan returned by the reduced model for C-4-3 (identical to the corrected model's plan), objective 7.4799.",
       width=6.0)

doc.add_heading("4.4 Efficiency: what can and cannot be claimed", level=2)
para("Branch-and-bound running times vary from run to run. Table 5 and Figure 6 report all six COPT runs on "
     "C-4-3, including the shorter runs made earlier (longer runs are evaluated at 1800 s).")
trows = []
for r in runs:
    t5 = "-" if r["t_gap5"] is None else f"{r['t_gap5']:.0f} s"
    trows.append([r["label"], f"{r['bound_300']:.3f} ({r['gap_300']:.1f}%)", t5,
                  f"{r['gap_end']:.2f}% at {r['last_t']:.0f} s"])
table(["Run", "Bound (gap) at 300 s", "Gap ≤ 5% reached", "Last logged gap"], trows,
      "All C-4-3 COPT runs (incumbent 7.4799 in every run). Run A's log stops at 652 s because of output "
      "buffering.", widths=[2.5, 1.5, 1.2, 1.3],
      highlight=lambda k, r: "EAF2E3" if r[0].startswith("Reduced") else "E8EEF7")
para("In 3 of 4 runs, the reduced model reached a gap of 5% or less within 351 s. The full model did so "
     "only after 728 s, in 1 of 2 runs. The reduced model also processed about 2.2 times more nodes in the "
     "same time. This suggests faster bound improvement, but run B (reduced, still 33.9% after 300 s) shows "
     "that individual runs differ a lot. **We therefore present the reduction as a simplification that "
     "keeps the optimum and does not slow the solver, not as a proven speed-up.**")
figure(FIG / "fig4_c43_all_runs_gap.png",
       "Gap over the first 900 s for all C-4-3 runs (red: reduced; blue: corrected/full).")

doc.add_heading("4.5 Constraint activity in the C-4-3 COPT plan (corrected model)", level=2)
para("Table 6 gives, for the constraints affected by the reduction, the active/tight counts in the C-4-3 "
     "COPT plan (re-timed to earliest times, same convention as for the SVNS plans). The counts agree with "
     "the SVNS statistics.")
arows = [["(7)", cb("7"), sv("7"), "removed: implied by (5)-(6)"],
         ["(8), (9), (10), (11)", f"{cb('8')} each", f"{sv('8')} each", "(9) → (9'); others removed"],
         ["(14)", cb("14"), sv("14"), "removed: bounds not needed by MTZ"],
         ["(17)", cb("17"), sv("17"), "removed: never binding ($|D|\\leq\\overline{\\nu}$)"],
         ["(21); (22)", f"{cb('21')}; {cb('22')}", f"{sv('21')}; {sv('22')}", "removed: merged into (12')(13')"],
         ["(26)", cb("26"), sv("26"), "removed: waiting shifted to departure"],
         ["(16)", cb("16"), sv("16"), "kept (essential)"],
         ["(23)", cb("23"), sv("23"), "kept (essential)"],
         ["(37)", cb("37"), sv("37"), "kept (essential, though never tight)"],
         ["(38); (40)", f"{cb('38')}; {cb('40')}", f"{sv('38')}; {sv('40')}", "kept, merged; not binding here"],
         ["(42); (43)", f"{cb('42')}; {cb('43')}", f"{sv('42')}; {sv('43')}", "kept; not binding here"]]
table(["Constraint", "C-4-3 COPT plan (active / tight)", "30 SVNS plans (active / tight)", "Treatment"], arows,
      "Activity of the affected constraints.", widths=[1.3, 1.6, 1.6, 2.0])

# --------------------------------------------------------------------------- 5. conclusion
doc.add_heading("5. Conclusion", level=1)
bullet("Correct (2), (18) and (30) as in Section 2. These are genuine errors in the printed model; the "
       "original Gurobi implementation already contained the corrected forms.")
bullet("Replace the first-stage model by the 28-constraint formulation of Table 2. Remove $\\delta_s^d$ and "
       "(47)-(49), and state $w_i^{sd}\\in\\mathbb{Z}_+$ in the variable list.")
bullet("Constraints (38)-(43) are not binding on the reported instances (time windows $[0,50]$), but they are kept because they define the problem class.")

doc.add_heading("Appendix A. Live progress dashboard (snapshots)", level=1)
para("Snapshots of the live dashboard used to monitor the runs. The chart labels are in Chinese because the "
     "dashboard was built for internal monitoring.")
figure(FIG / "dashboard_bound_incumbent.png", "Dashboard, C-4-3: incumbent (solid) and lower bound (dashed).")
figure(FIG / "dashboard_gap.png", "Dashboard, C-4-3: gap (%).")
for name, cap in (("dashboard_R_RC_bound_incumbent.png", "Dashboard, R-4-3 and RC-4-3: incumbent and lower bound."),
                  ("dashboard_R_RC_gap.png", "Dashboard, R-4-3 and RC-4-3: gap (%)."),
                  ("dashboard_RC_rerun_bound_incumbent.png", "Dashboard, RC-4-3 second run from the 7.9140 plan: "
                                                             "incumbent and lower bound."),
                  ("dashboard_RC_rerun_gap.png", "Dashboard, RC-4-3 second run: gap (%).")):
    if (FIG / name).exists():
        figure(FIG / name, cap)

doc.add_heading("Appendix B. Reproducibility", level=1)
para("All scripts and data are in the folder constraint_audit/ of the repository: model_rows.py (row generator for (2)-(43) and "
     "the three model variants), copt_model.py and run_copt_small.py (COPT runs with post-solve checks), "
     "run_copt_experiments.py (toy instances), run_svns_audit.py (SVNS audit), progress_dashboard.py (live "
     "dashboard), make_report_figures.py, make_report_docx.py and omml.py (this report). Logs are in "
     "copt_logs/ and outputs/, full solutions in copt_runs/.", size=9.5)

doc.save(DOCX)
print("written", DOCX)
