"""Build and solve the first-stage MILP with COPT, using exactly the rows audited on SVNS.

Examples (run from this folder, COPT licence required for non-trivial sizes):
    python3 copt_model.py --case C_3_4 --profile corrected --time-limit 600 --warm-start
    python3 copt_model.py --case C_3_4 --profile reduced
    python3 copt_model.py --case C_3_4 --profile corrected --drop 26 37
    python3 copt_model.py --case C_3_4 --profile corrected --write-only   # only write the .mps model

Profiles (see model_rows.PROFILES):
    paper      equations (2)-(43) exactly as printed in the R1 PDF
    corrected  paper + sum_i x_0i = 1, eq. (18) on N1 x N2, eq. (30) also at the origin
    reduced    corrected without (7),(8),(10),(11),(14),(17),(21),(22),(26); (9) -> sum launch <= 1

After solving, the script (i) decodes the truck route and sorties, (ii) re-times them
with the SVNS schedule evaluator and runs the independent physical audit, and
(iii) evaluates every row of a reference profile (default: corrected) on the COPT
solution, so that the effect of a dropped constraint is visible directly.
Results are written to ./copt_runs/<case>_<profile>[_drop...].json
"""

from __future__ import annotations

import argparse
import json
import time
from collections import defaultdict
from pathlib import Path

from milp_data import build
from model_rows import PROFILES, Ctx, evaluate_row, generate
from svns_point import rtar

HERE = Path(__file__).resolve().parent
RUNS = HERE / "copt_runs"
BINARY = {"x", "y", "z", "p", "delta", "mx", "h", "v", "q"}
SMALL = {"C_3_4", "R_3_4", "RC_3_4"}


def var_name(key) -> str:
    return f"{key[0]}[{','.join(map(str, key[1:]))}]"


def parse_name(name: str):
    head, rest = name.split("[", 1)
    parts = rest[:-1].split(",") if rest[:-1] else []
    return (head,) + tuple(int(p) if p.lstrip("-").isdigit() else p for p in parts)


def collect_rows(data, profile, drop):
    ctx = Ctx(data, None, sparse=False, **PROFILES[profile])
    return ctx, list(generate(ctx, drop))


def build_model(env, data, rows, objective_var):
    from coptpy import COPT, LinExpr

    m = env.createModel(f"{data.case}")
    keys = {objective_var}
    for r in rows:
        keys.update(v for v, _ in r.terms)
        if r.gate:
            keys.update(v for v, _ in r.gate)
    var = {}
    for k in sorted(keys, key=str):
        name = var_name(k)
        if k[0] in BINARY:
            var[k] = m.addVar(vtype=COPT.BINARY, name=name)
        elif k[0] == "u":
            var[k] = m.addVar(lb=0, ub=data.C + 1, vtype=COPT.INTEGER, name=name)
        elif k[0] == "w":
            var[k] = m.addVar(lb=0, ub=COPT.INFINITY, vtype=COPT.INTEGER, name=name)
        else:
            var[k] = m.addVar(lb=0, ub=COPT.INFINITY, vtype=COPT.CONTINUOUS, name=name)

    def expr(terms):
        e = LinExpr()
        for v, c in terms:
            e.addTerm(var[v], c)
        return e

    for n, r in enumerate(rows):
        e = expr(r.terms)
        tag = f"e{r.eq}_{n}"
        if r.Mval is not None and r.gate is not None:
            g = expr(r.gate)
            if r.lo > -COPT.INFINITY:
                m.addConstr(e + r.Mval * g >= r.lo - r.Mval * r.gconst, name=tag + "_lo")
            if r.hi < COPT.INFINITY:
                m.addConstr(e - r.Mval * g <= r.hi + r.Mval * r.gconst, name=tag + "_hi")
        elif r.lo == r.hi:
            m.addConstr(e == r.lo, name=tag)
        else:
            if r.lo > -COPT.INFINITY:
                m.addConstr(e >= r.lo, name=tag + "_lo")
            if r.hi < COPT.INFINITY:
                m.addConstr(e <= r.hi, name=tag + "_hi")
    m.setObjective(var[objective_var], COPT.MINIMIZE)
    return m, var


def load_warm_start(case, name=None):
    path = HERE / "copt_ready" / "warm_start" / f"{name or case}.json"
    rec = json.loads(path.read_text(encoding="utf-8"))
    return {parse_name(k): v for k, v in rec["values"].items()}


def decode(data, val):
    truck, node, seen = [0], 0, {0}
    while node != data.dest:
        nxt = [j for j in data.N2 if j != node and val.get(("x", node, j), 0) > 0.5]
        if len(nxt) != 1 or nxt[0] in seen:
            break
        node = nxt[0]
        truck.append(node)
        seen.add(node)
    drones = defaultdict(dict)
    for d in data.D:
        k = 0
        for s in data.S:
            ns = set(data.Ns[s])
            for a in data.N1:
                for j in data.Ns[s]:
                    if val.get(("y", s, d, a, j), 0) <= 0.5:
                        continue
                    route, cur = [a, j], j
                    while cur in ns and len(route) <= len(ns) + 2:
                        nxt = [b for b in data.Ns[s] + data.N2 if b != cur and val.get(("y", s, d, cur, b), 0) > 0.5]
                        if not nxt:
                            break
                        cur = nxt[0]
                        route.append(cur)
                    k += 1
                    drones[d][k] = route
    return truck, {d: r for d, r in drones.items()}


def complete_aux(data, val):
    """Recompute linearisation auxiliaries from y and z so that a reference profile can be
    evaluated even when the solved model did not contain them."""
    out = dict(val)
    for k in [k for k in out if k[0] in ("delta", "mx", "h", "v", "q")]:
        del out[k]
    for k, v in val.items():
        if v < 0.5:
            continue
        if k[0] == "y":
            _, s, d, i, j = k
            out[("mx", s, d)] = 1.0
            if i in data.Ns[s] and j in data.Ns[s]:
                out[("delta", s, d)] = 1.0
        elif k[0] == "z":
            _, s, d, i, a, b = k
            out[("v", a, b)] = 1.0
            out[("q", d, a, b)] = 1.0
    for s in data.S:
        for d in data.D:
            for i in data.Ns[s]:
                for j in data.Ns[s]:
                    if i != j and val.get(("y", s, d, i, j), 0) > 0.5:
                        for a in data.N1:
                            for b in data.N2:
                                if a != b and val.get(("z", s, d, i, a, b), 0) > 0.5 and val.get(("z", s, d, j, a, b), 0) > 0.5:
                                    out[("h", s, d, i, j, a, b)] = 1.0
    return out


def check_reference(data, val, reference):
    ctx = Ctx(data, val, sparse=False, **PROFILES[reference])
    viol = defaultdict(lambda: [0, 0.0])
    for row in generate(ctx):
        _, _, v, _, _ = evaluate_row(row, ctx.val, data.M)
        if v > 1e-5:
            viol[row.eq][0] += 1
            viol[row.eq][1] = max(viol[row.eq][1], v)
    return {eq: {"violated_rows": n, "max_violation": mv} for eq, (n, mv) in viol.items()}


def physical_check(data, truck, drones):
    params = rtar.Params(drone_speed=30.0, truck_speed=20.0, launch_time=data.LTD, retrieval_time=data.RTD,
                         endurance=data.DD, truck_endurance=data.TD)
    off_route = sorted({n for routes in drones.values() for r in routes.values() for n in (r[0], r[-1])
                        if n not in truck})
    if off_route:
        return {"evaluator_completion": None, "audit_problems": [],
                "evaluator_reason": f"drone launch/retrieval at node(s) {off_route} that the truck never visits"}
    try:
        plan = rtar.plan_from_result(data.coords, truck, drones, data.target_of, params,
                                     inspection={n: data.service[n] for n in range(len(data.coords))})
        sched = rtar.evaluate(plan)
        reason = rtar.check_constraints(plan, sched)
        from rtar_core.audit import audit
        problems = audit(plan, sched)
        adjacent = {frozenset(e) for routes in drones.values() for r in routes.values() for e in zip(r, r[1:])}
        problems += [f"sweep pair {p} of target {s} not flown consecutively (eq. 16 geometry)"
                     for s, prs in data.pairs.items() for p in prs if frozenset(p) not in adjacent]
        return {"evaluator_completion": sched.completion, "evaluator_reason": reason, "audit_problems": problems}
    except Exception as exc:  # decoded plan not executable
        return {"evaluator_completion": None, "evaluator_reason": f"{type(exc).__name__}: {exc}", "audit_problems": []}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--case", default="C_3_4")
    ap.add_argument("--drones", type=int, nargs="*", help="drone ids (default: 2 for *_3_4, else 5)")
    ap.add_argument("--profile", default="corrected", choices=list(PROFILES))
    ap.add_argument("--drop", nargs="*", default=[], help="PDF equation numbers to drop, e.g. 26 37")
    ap.add_argument("--reference", default="corrected", choices=list(PROFILES))
    ap.add_argument("--M", type=float, default=None)
    ap.add_argument("--time-limit", type=float, default=600)
    ap.add_argument("--threads", type=int, default=0)
    ap.add_argument("--warm-start", action="store_true", help="load the SVNS solution as MIP start")
    ap.add_argument("--write-only", action="store_true", help="write the .mps model and stop")
    args = ap.parse_args()
    result = solve(args.case, args.profile, args.drop, drones=args.drones, reference=args.reference, M=args.M,
                   time_limit=args.time_limit, threads=args.threads, warm_start=args.warm_start,
                   write_only=args.write_only)
    print(json.dumps({k: v for k, v in result.items() if k != "values_nonzero"}, indent=1, default=str))


def load_data(case, drones=None, M=None):
    overrides = {"M": M} if M else {}
    toy = HERE / "copt_ready" / "toy" / f"instance_{case}.json"
    if toy.exists():
        from toy_instances import TOYS
        return build(case, drones or TOYS[case]["drones"], instance_path=toy, **overrides)
    return build(case, drones or ([1, 2] if case in SMALL else [1, 2, 3, 4, 5]), **overrides)


def solve(case, profile="corrected", drop=(), drones=None, reference="corrected", M=None, time_limit=600,
          threads=0, warm_start=False, write_only=False, env=None, log=True, log_file=None, tag_suffix="",
          warm_name=None):
    import coptpy

    drop = [str(e) for e in drop]
    data = load_data(case, drones, M)
    _, rows = collect_rows(data, profile, drop)
    env = env or coptpy.Envr()
    model, var = build_model(env, data, rows, ("tL", data.dest))
    if not log:
        model.setParam("Logging", 0)
    if log_file:
        model.setLogFile(str(log_file))
    tag = f"{case}_{profile}" + (f"_drop{'-'.join(drop)}" if drop else "") + tag_suffix
    RUNS.mkdir(exist_ok=True)
    result = {"case": case, "profile": profile, "drop": drop, "M": data.M, "drones": data.D,
              "rows": model.getAttr("Rows"), "cols": model.getAttr("Cols")}
    if write_only:
        model.write(str(RUNS / f"{tag}.mps"))
        result["mps"] = str(RUNS / f"{tag}.mps")
        return result
    model.setParam("TimeLimit", time_limit)
    if threads:
        model.setParam("Threads", threads)
    if warm_start:
        ws = load_warm_start(case, warm_name)
        keys = list(var)
        model.setMipStart([var[k] for k in keys], [ws.get(k, 1.0 if k[0] == "w" else 0.0) for k in keys])
        model.loadMipStart()
    t0 = time.time()
    model.solve()
    result.update(status=model.status, runtime_s=time.time() - t0)
    if model.hasmipsol:
        val = {k: v.x for k, v in var.items()}
        result.update(objective=model.objval, best_bound=model.getAttr("BestBnd"), gap=model.getAttr("BestGap"))
        truck, drones_route = decode(data, val)
        result.update(truck_route=truck,
                      drone_route={str(d): {str(k): r for k, r in s.items()} for d, s in drones_route.items()})
        result["physical_check"] = physical_check(data, truck, drones_route)
        result["reference_profile"] = reference
        result["reference_violations"] = check_reference(data, complete_aux(data, val), reference)
        result["values_nonzero"] = {var_name(k): v for k, v in val.items() if abs(v) > 1e-9}
    (RUNS / f"{tag}.json").write_text(json.dumps(result, indent=1, default=str), encoding="utf-8")
    return result


if __name__ == "__main__":
    main()
