#!/bin/sh
# R-4-3 then RC-4-3; each: reduced and corrected models in parallel, 5 threads each, 1800 s, SVNS warm start.
cd "$(dirname "$0")"
# Configure COPT_LICENSE_DIR separately using your own installation if required.
PY="${PYTHON:-python3}"
mkdir -p copt_logs outputs
for CASE in R_3_4 RC_3_4; do
  echo "$(date '+%F %T') start $CASE" >> copt_logs/run_r_rc_30min_manifest.txt
  for PROF in reduced corrected; do
    "$PY" run_copt_small.py --cases $CASE --profiles $PROF --time-limit 1800 --threads 5 --log-dir copt_logs --tag _30min \
      > outputs/copt_small_stdout_${CASE}_${PROF}_30min.txt 2>&1 &
  done
  wait
  echo "$(date '+%F %T') done $CASE" >> copt_logs/run_r_rc_30min_manifest.txt
done
echo "$(date '+%F %T') all done" >> copt_logs/run_r_rc_30min_manifest.txt
