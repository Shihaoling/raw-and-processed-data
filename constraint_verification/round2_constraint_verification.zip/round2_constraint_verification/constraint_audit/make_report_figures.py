"""Figures for the constraint-reduction report (English labels).

Run:  python3 make_report_figures.py      -> figures/fig*.png
"""

from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from progress_dashboard import ROW, num  # noqa: E402

HERE = Path(__file__).resolve().parent
FIG = HERE / "figures"
OUT = HERE / "outputs"
RED, BLUE, GREY, GREEN = "#c0392b", "#2e6fb7", "#7f8c8d", "#2e8b57"
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "savefig.dpi": 300})

# C-4-3 runs: (label, model, log file, segment index)
RUNS = [
    ("Reduced A: SVNS start, 10 thr", "reduced", OUT / "copt_small_log_3600s_aborted.txt", 0),
    ("Reduced B: SVNS start, 10 thr", "reduced", OUT / "copt_small_log_C_reduced_warm.txt", 0),
    ("Reduced C: no start, 10 thr", "reduced", OUT / "copt_small_log_C_reduced_cold.txt", 0),
    ("Reduced D: SVNS start, 5 thr", "reduced", HERE / "copt_logs" / "C_3_4_reduced_40min.log", 0),
    ("Corrected E: SVNS start, 10 thr", "corrected", OUT / "copt_small_log_C_corrected.txt", 0),
    ("Corrected F: SVNS start, 5 thr", "corrected", HERE / "copt_logs" / "C_3_4_corrected_40min.log", 0),
]


def log_points(path: Path, seg: int = 0):
    parts = path.read_text(errors="ignore").split("Model fingerprint")[1:]
    pts = []
    for line in parts[seg].splitlines():
        m = ROW.match(line)
        if m:
            _, nodes, _, _, _, b, s, g, t = m.groups()
            pts.append(dict(t=float(t), bound=num(b), sol=num(s), gap=num(g), nodes=int(nodes)))
    return pts


def run_stats():
    rows = []
    for label, model, path, seg in RUNS:
        pts = [p for p in log_points(path, seg) if p["t"] <= 1800.0]
        at = lambda T: [p for p in pts if p["t"] <= T][-1]  # noqa: E731
        first = lambda g: next((p["t"] for p in pts if p["gap"] is not None and p["gap"] <= g), None)  # noqa: E731
        rows.append(dict(label=label, model=model, last_t=pts[-1]["t"], incumbent=pts[-1]["sol"],
                         bound_300=at(300)["bound"], gap_300=at(300)["gap"], bound_end=pts[-1]["bound"],
                         gap_end=pts[-1]["gap"], t_gap10=first(10), t_gap5=first(5), points=pts))
    return rows


def fig_model_size():
    fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.6), gridspec_kw=dict(width_ratios=[1, 1.25]))
    labs, vals = ["Printed\n(R1)", "After\nremovals", "After\nmerging"], [42, 33, 28]
    b = ax[0].bar(labs, vals, color=[GREY, BLUE, RED], width=0.6)
    ax[0].bar_label(b, padding=2)
    ax[0].set_ylabel("Numbered constraints")
    ax[0].set_ylim(0, 48)
    ax[0].set_title("(a) Constraints in the paper", loc="left")
    cats = ["Rows", "Columns", "Non-zeros", "Rows after\npresolve"]
    corr = [25639, 6862, 93229, 23079]
    red = [24941, 6845, 91306, 22941]
    x = range(len(cats))
    ax[1].bar([i - 0.2 for i in x], [100] * 4, 0.4, color=BLUE, label="Corrected (full)")
    rb = ax[1].bar([i + 0.2 for i in x], [100 * r / c for r, c in zip(red, corr)], 0.4, color=RED, label="Reduced")
    ax[1].bar_label(rb, labels=[f"{100 * r / c:.1f}%" for r, c in zip(red, corr)], padding=2, fontsize=8)
    ax[1].set_xticks(list(x), cats)
    ax[1].set_ylim(80, 108)
    ax[1].set_ylabel("Size relative to corrected model (%)")
    ax[1].set_title("(b) Solver model size, C-4-3", loc="left")
    ax[1].legend(frameon=False, loc="upper center", fontsize=8, ncol=2, bbox_to_anchor=(0.5, 1.02))
    fig.tight_layout()
    fig.savefig(FIG / "fig1_model_size.png")
    plt.close(fig)


def fig_toy():
    rows = list(csv.DictReader(open(OUT / "copt_experiments_TOY_1D_TOY_2D.csv", encoding="utf-8-sig")))
    short = {"paper model as printed": "Printed model (no corrections)",
             "corrected model (reference)": "Corrected model (reference)",
             "reduced model (proposal)": "REDUCED MODEL (proposal)",
             "corrected - (21)(22) [no unification: negative control]": "Corrected - (21)(22), (12)(13) not extended"}
    from matplotlib.patches import Patch
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 4.2), sharey=True)
    for ax, case in zip(axes, ["TOY_1D", "TOY_2D"]):
        rs = [r for r in rows if r["case"] == case]
        ref = float(next(r["objective"] for r in rs if r["profile"] == "corrected" and not r["dropped"]))
        labels = [short.get(r["configuration"], r["configuration"].replace("corrected - ", "Corrected - "))
                  for r in rs]
        dev = [100 * (float(r["objective"]) - ref) / ref for r in rs]
        ok = [r["physical_ok"] == "True" for r in rs]
        y = list(range(len(rs)))[::-1]
        ax.barh(y, dev, color=[GREEN if o else RED for o in ok], height=0.6)
        ax.scatter([0 for o in ok if o], [yy for yy, o in zip(y, ok) if o], color=GREEN, s=22, zorder=3)
        for yy, d, o in zip(y, dev, ok):
            ax.text(0.4, yy, f"{d:+.2f}%" + ("" if o else " (not executable)"), va="center", ha="left", fontsize=7,
                    color="k" if o else RED)
        ax.axvline(0, color="k", lw=0.8)
        ax.set_yticks(y, labels, fontsize=7.5)
        ax.set_xlim(-11, 9)
        ax.set_xlabel("Optimal objective vs. corrected (%)", fontsize=8)
        ax.set_title(case, loc="left", fontsize=9)
    fig.legend(handles=[Patch(color=GREEN, label="Executable plan (dot = same optimum)"),
                        Patch(color=RED, label="Plan not executable")],
               frameon=False, loc="upper right", fontsize=8, ncol=2)
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig.savefig(FIG / "fig2_toy_verification.png")
    plt.close(fig)


def fig_convergence(stats):
    d = {r["label"][0:9]: r for r in stats}
    red, cor = stats[3], stats[5]
    fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.8))
    for r, c, name in ((red, RED, "Reduced"), (cor, BLUE, "Corrected")):
        t = [p["t"] for p in r["points"]]
        ax[0].step(t, [p["sol"] for p in r["points"]], where="post", color=c, lw=1.6, label=f"{name}: incumbent")
        ax[0].step(t, [p["bound"] for p in r["points"]], where="post", color=c, lw=1.4, ls="--",
                   label=f"{name}: lower bound")
        ax[1].step(t, [p["gap"] for p in r["points"]], where="post", color=c, lw=1.6, label=name)
    ax[0].axhline(7.48, color=GREY, lw=0.8, ls=":")
    ax[0].text(2380, 7.52, "Gurobi (R1): 7.48", ha="right", fontsize=7, color=GREY)
    ax[0].set_ylim(2.5, 8)
    ax[0].set_xlabel("Time (s)")
    ax[0].set_ylabel("Objective (completion time)")
    ax[0].set_title("(a) Incumbent and lower bound", loc="left")
    ax[0].legend(frameon=False, fontsize=7, loc="lower right")
    for g in (5,):
        ax[1].axhline(g, color=GREY, lw=0.8, ls=":")
    ax[1].annotate(f"5% at {red['t_gap5']:.0f} s", (red["t_gap5"], 5), (250, 22), color=RED, fontsize=7,
                   arrowprops=dict(arrowstyle="->", color=RED, lw=0.8))
    ax[1].annotate(f"5% at {cor['t_gap5']:.0f} s", (cor["t_gap5"], 5), (1000, 14), color=BLUE,
                   fontsize=7, arrowprops=dict(arrowstyle="->", color=BLUE, lw=0.8))
    ax[1].set_xlabel("Time (s)")
    ax[1].set_ylabel("Relative gap (%)")
    ax[1].set_ylim(0, 65)
    ax[1].set_title("(b) Gap", loc="left")
    ax[1].legend(frameon=False, fontsize=7)
    fig.tight_layout()
    fig.savefig(FIG / "fig3_c43_convergence_40min.png")
    plt.close(fig)


def fig_all_runs(stats):
    fig, ax = plt.subplots(figsize=(7.2, 2.9))
    styles = [(RED, "-"), (RED, "--"), (RED, ":"), (RED, "-."), (BLUE, "--"), (BLUE, "-")]
    for r, (c, ls) in zip(stats, styles):
        pts = [p for p in r["points"] if p["gap"] is not None and p["t"] <= 900]
        ax.step([p["t"] for p in pts], [p["gap"] for p in pts], where="post", color=c, ls=ls, lw=1.4, label=r["label"])
    ax.axvline(300, color=GREY, lw=0.8, ls=":")
    ax.axhline(5, color=GREY, lw=0.8, ls=":")
    ax.set_xlim(0, 900)
    ax.set_ylim(0, 65)
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Relative gap (%)")
    ax.legend(frameon=False, fontsize=7, ncol=2)
    fig.tight_layout()
    fig.savefig(FIG / "fig4_c43_all_runs_gap.png")
    plt.close(fig)


def fig_routes():
    from copt_model import load_data

    data = load_data("C_3_4")
    sol = json.loads((HERE / "copt_runs" / "C_3_4_reduced_40min.json").read_text(encoding="utf-8"))
    xy = data.coords
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.3), gridspec_kw=dict(width_ratios=[1, 1.35]))
    dcol = {"1": "#d35400", "2": "#8e44ad"}
    for k, ax in enumerate(axes):
        tr = sol["truck_route"]
        ax.plot([xy[n][0] for n in tr], [xy[n][1] for n in tr], color="k", lw=2.2, zorder=1, label="Truck")
        for d, srt in sol["drone_route"].items():
            for i, (_, r) in enumerate(sorted(srt.items())):
                ax.plot([xy[n][0] for n in r], [xy[n][1] for n in r], color=dcol[d], lw=1.1, ls="--", zorder=2,
                        label=f"Drone {d}" if i == 0 else None)
        ax.scatter(*xy[data.Np].T, marker="s", s=28, c="white", edgecolors="k", zorder=3, label="Operational node")
        for s, ns in data.Ns.items():
            kind = "point" if s in data.S_node else ("area" if len(ns) > 2 else "line")
            m = {"point": "*", "area": "o", "line": "^"}[kind]
            ax.scatter(*xy[ns].T, marker=m, s=40 if kind == "point" else 18, c=GREEN, zorder=4,
                       label=f"{kind.capitalize()} target")
        for n in [0, data.dest]:
            ax.scatter(*xy[n], marker="D", s=40, c="k", zorder=4)
        if k == 0:
            ax.set_title("(a) Whole network", loc="left")
            ax.text(*(xy[0] + [3, -1]), "Origin 0", fontsize=7)
            ax.text(*(xy[data.dest] + [-30, -5]), f"Destination {data.dest}", fontsize=7)
        else:
            for n in data.Np:
                ax.text(xy[n][0] + 0.7, xy[n][1] + 0.7, str(n), fontsize=7)
            ax.set_xlim(50, 80)
            ax.set_ylim(28, 56)
            ax.set_title("(b) Zoom on the service region", loc="left")
            h, l = ax.get_legend_handles_labels()
            uniq = dict(zip(l, h))
            ax.legend(uniq.values(), uniq.keys(), fontsize=6.5, frameon=False, loc="upper left", bbox_to_anchor=(1, 1))
        ax.set_aspect("equal")
        ax.tick_params(labelsize=7)
    fig.tight_layout()
    fig.savefig(FIG / "fig5_c43_reduced_solution_routes.png")
    plt.close(fig)


def fig_svns_binding():
    rows = list(csv.DictReader(open(OUT / "summary_main_corrected_model.csv", encoding="utf-8-sig")))
    rows = [r for r in rows if r["eq"].startswith("(")]
    removed = {"(7)", "(8)", "(10)", "(11)", "(14)", "(17)", "(21)", "(22)", "(26)"}
    merged = {"(5)", "(6)", "(31)", "(32)", "(33)", "(34)", "(38)", "(39)", "(40)", "(41)"}
    fig, ax = plt.subplots(figsize=(7.2, 3.0))
    x = list(range(len(rows)))
    act = [int(r["active"]) for r in rows]
    tig = [int(r["tight"]) for r in rows]
    col = [RED if r["eq"] in removed else ("#e67e22" if r["eq"] in merged or r["eq"] == "(9)" else BLUE) for r in rows]
    ax.bar(x, act, color="#d6dbdf", width=0.8, label="Active (condition switched on)")
    ax.bar(x, [max(t, 0.6) if t else 0 for t in tig], color=col, width=0.5)
    ax.set_yscale("log")
    ax.set_xticks(x, [r["eq"] for r in rows], rotation=90, fontsize=7)
    ax.set_ylabel("Count over 30 SVNS solutions")
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(color="#d6dbdf", label="Active rows"), Patch(color=BLUE, label="Tight rows - kept"),
                       Patch(color="#e67e22", label="Tight rows - merged / replaced"),
                       Patch(color=RED, label="Tight rows - removed")], fontsize=7, frameon=False, ncol=4,
              loc="upper center", bbox_to_anchor=(0.5, 1.13))
    fig.tight_layout()
    fig.savefig(FIG / "fig6_svns_binding_counts.png")
    plt.close(fig)


def main():
    FIG.mkdir(exist_ok=True)
    stats = run_stats()
    fig_model_size()
    fig_toy()
    fig_convergence(stats)
    fig_all_runs(stats)
    fig_routes()
    fig_svns_binding()
    (OUT / "c43_run_stats.json").write_text(json.dumps([{k: v for k, v in r.items() if k != "points"} for r in stats],
                                                       indent=1), encoding="utf-8")
    print("figures written to", FIG)


if __name__ == "__main__":
    main()
