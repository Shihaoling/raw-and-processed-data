"""Evaluate every first-stage constraint (PDF eqs. 2-43) on the stored SVNS solutions.

Run from this folder:  python3 run_svns_audit.py [--skip-fleet]

For each solution and each equation the script reports
  rows_total   number of rows of the equation as printed in the paper
  active       rows whose logical condition is switched on (big-M term = 0, or the
               row concerns a used arc / visited node)
  tight        active rows that hold with equality, i.e. the row actually limits
               the SVNS schedule ("被限制/取等" count)
  violated     rows that the SVNS solution violates (with M = data.M)
  max_needed_M largest big-M value that an inactive row needs at this solution
Outputs go to ./outputs, COPT inputs (model data + warm starts) to ./copt_ready.
"""

from __future__ import annotations

import argparse
import csv
import json
import time
from collections import defaultdict
from pathlib import Path

from milp_data import CURATED, build
from model_rows import (BLOCK_OF, C_LABEL, PAPER_EQS, PROFILES, PROPOSAL, SPARSE_COUNTS, Ctx, evaluate_row,
                        generate)
from svns_point import build_point

HERE = Path(__file__).resolve().parent
OUT = HERE / "outputs"
COPT = HERE / "copt_ready"
MAIN = CURATED / "01_main_svns_results"
FLEET = CURATED / "04_parameter_sensitivity" / "fleet_size_runs"
SMALL = {"C_3_4", "R_3_4", "RC_3_4"}


def var_name(key) -> str:
    return f"{key[0]}[{','.join(map(str, key[1:]))}]"


def main_cases():
    for f in sorted(MAIN.glob("*/result_*.json")):
        case = f.stem.replace("result_", "")
        drones = [1, 2] if case in SMALL else [1, 2, 3, 4, 5]
        yield "main", case, case, drones, json.loads(f.read_text(encoding="utf-8"))


def fleet_cases():
    for f in sorted(FLEET.glob("V*/*.json")):
        rec = json.loads(f.read_text(encoding="utf-8"))
        yield "fleet", f"{rec['case']}_{f.parent.name}_r{rec['repeat']}", rec["case"], rec["protocol"]["drones"], rec


def audit_point(data, point, profile):
    ctx = Ctx(data, point, sparse=True, **PROFILES[profile])
    stats = defaultdict(lambda: dict(rows=0, active=0, tight=0, violated=0, max_violation=0.0,
                                     max_needed_M=0.0, min_active_gap=None, kind=""))
    val = ctx.val
    for row in generate(ctx):
        st = stats[row.eq]
        active, tight, viol, needed, gap = evaluate_row(row, val, data.M)
        st["rows"] += 1
        st["kind"] = st["kind"] or row.kind
        st["active"] += active
        st["tight"] += tight
        if viol > 1e-6:
            st["violated"] += 1
            st["max_violation"] = max(st["max_violation"], viol)
        st["max_needed_M"] = max(st["max_needed_M"], needed)
        if active and row.kind != "eq":
            st["min_active_gap"] = gap if st["min_active_gap"] is None else min(st["min_active_gap"], gap)
    dropped = set(ctx.opt.get("drop", ()))
    for eq, counter in SPARSE_COUNTS.items():
        if eq not in dropped:
            st = stats[eq]  # created even when no row of the equation is active
            st["rows"] = counter(ctx)
            st["kind"] = st["kind"] or "ineq"
    return stats


def write_csv(path: Path, rows, fields=None):
    rows = list(rows)
    if not rows:
        return
    fields = fields or list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def summarise(per_instance, dataset, profile):
    agg = defaultdict(lambda: dict(rows_total=0, active=0, tight=0, violated=0, max_violation=0.0,
                                   instances=0, instances_tight=0, min_active_gap=None, kind=""))
    for r in per_instance:
        if r["dataset"] != dataset or r["profile"] != profile:
            continue
        a = agg[r["eq"]]
        a["kind"] = r["kind"]
        a["instances"] += 1
        a["rows_total"] += r["rows_total"]
        a["active"] += r["active"]
        a["tight"] += r["tight"]
        a["violated"] += r["violated"]
        a["max_violation"] = max(a["max_violation"], r["max_violation"])
        a["instances_tight"] += r["tight"] > 0
        g = r["min_active_gap"]
        if g != "":
            a["min_active_gap"] = g if a["min_active_gap"] is None else min(a["min_active_gap"], g)
    order = {e: k for k, e in enumerate(PAPER_EQS)}
    out = []
    for eq in sorted(agg, key=lambda e: (order.get(e, 99), e)):
        a = agg[eq]
        out.append(dict(eq=f"({eq})" if eq in order else eq, C_label=C_LABEL.get(eq, ""),
                        block=BLOCK_OF.get(eq, "extra/variant"), kind=a["kind"],
                        rows_total=a["rows_total"], active=a["active"], tight=a["tight"],
                        tight_share_of_active=round(a["tight"] / a["active"], 4) if a["active"] else "",
                        instances=a["instances"], instances_with_tight=a["instances_tight"],
                        violated=a["violated"], max_violation=round(a["max_violation"], 9),
                        min_slack_active_ineq="" if a["min_active_gap"] is None else round(a["min_active_gap"], 6),
                        proposal=PROPOSAL.get(eq, "keep")))
    return out


def by_block(eq_rows):
    agg = defaultdict(lambda: dict(rows_total=0, active=0, tight=0, violated=0, eqs=[]))
    for r in eq_rows:
        if r["block"] == "extra/variant":
            continue
        a = agg[r["block"]]
        for k in ("rows_total", "active", "tight", "violated"):
            a[k] += r[k]
        a["eqs"].append(r["eq"])
    return [dict(block=b, equations=" ".join(a["eqs"]), rows_total=a["rows_total"], active=a["active"],
                 tight=a["tight"], violated=a["violated"]) for b, a in sorted(agg.items())]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-fleet", action="store_true")
    args = ap.parse_args()
    OUT.mkdir(exist_ok=True)
    (COPT / "instances").mkdir(parents=True, exist_ok=True)
    (COPT / "warm_start").mkdir(parents=True, exist_ok=True)

    per_instance, structure, sorties_out = [], [], []
    sources = list(main_cases()) + ([] if args.skip_fleet else list(fleet_cases()))
    for dataset, name, case, drones, rec in sources:
        t0 = time.time()
        data = build(case, drones)
        point, struct, sorties = build_point(data, rec["truck_route"], rec["drone_route"])
        struct.update(dataset=dataset, name=name, case=case, drones=len(drones),
                      stored_objective=rec.get("global_optimal_time"), M=data.M,
                      M_covers_horizon=data.M >= struct["horizon"] + float(data.td.max()))
        structure.append(struct)
        for s in sorties:
            s.update(dataset=dataset, name=name)
            sorties_out.append(s)
        profiles = ["paper", "corrected"] if dataset == "main" else ["paper"]
        for profile in profiles:
            for eq, st in audit_point(data, point, profile).items():
                per_instance.append(dict(dataset=dataset, name=name, case=case, profile=profile, eq=eq,
                                         C_label=C_LABEL.get(eq, ""), kind=st["kind"], rows_total=st["rows"],
                                         active=st["active"], tight=st["tight"], violated=st["violated"],
                                         max_violation=st["max_violation"], max_needed_M=st["max_needed_M"],
                                         min_active_gap="" if st["min_active_gap"] is None else st["min_active_gap"]))
        if dataset == "main":
            (COPT / "instances" / f"{case}.json").write_text(json.dumps(data.to_json()), encoding="utf-8")
            warm = {"case": case, "source": "SVNS stored nominal plan (curated 01_main_svns_results)",
                    "objective_tL_dest": struct["completion"],
                    "truck_route": rec["truck_route"], "drone_route": rec["drone_route"],
                    "values": {var_name(k): v for k, v in sorted(point.items(), key=lambda kv: str(kv[0]))}}
            (COPT / "warm_start" / f"{case}.json").write_text(json.dumps(warm), encoding="utf-8")
        print(f"{dataset:5s} {name:22s} done in {time.time() - t0:5.1f}s  objective={struct['completion']:.4f}",
              flush=True)

    write_csv(OUT / "stats_by_instance_and_equation.csv", per_instance)
    write_csv(OUT / "structure_by_instance.csv", structure,
              ["dataset", "name", "case", "drones", "stored_objective", "completion", "evaluator_feasible",
               "evaluator_reason", "n_sorties", "closed_sorties", "sorties_from_origin", "sorties_to_destination",
               "sorties_with_hover", "max_hover", "max_flight_ratio", "max_flight_plus_hover_ratio",
               "index_collisions", "collision_examples", "horizon", "M", "M_covers_horizon"])
    write_csv(OUT / "sorties.csv", sorties_out)
    for dataset, profile, fname in [("main", "paper", "summary_main_paper_model.csv"),
                                    ("main", "corrected", "summary_main_corrected_model.csv"),
                                    ("fleet", "paper", "summary_fleet_paper_model.csv")]:
        rows = summarise(per_instance, dataset, profile)
        write_csv(OUT / fname, rows)
        if profile == "paper":
            write_csv(OUT / fname.replace("summary_", "blocks_"), by_block(rows))


if __name__ == "__main__":
    main()
