"""Consistency tests: sparse audit == full-row evaluation, and SVNS warm starts are
feasible for the linearised rows (incl. auxiliary rows) of every profile.

Run:  python3 selftest.py
"""

from __future__ import annotations

import json
import unittest
from collections import defaultdict

from milp_data import CURATED, build
from model_rows import PROFILES, Ctx, evaluate_row, generate
from run_svns_audit import audit_point
from svns_point import build_point

CASES = ["C_3_4", "R_3_4", "RC_3_4"]


def load(case):
    rec = json.loads((CURATED / "01_main_svns_results" / "3" / f"result_{case}.json").read_text())
    data = build(case, [1, 2])
    point, struct, _ = build_point(data, rec["truck_route"], rec["drone_route"])
    return data, point, struct


def full_stats(data, point, profile):
    ctx = Ctx(data, point, sparse=False, **PROFILES[profile])
    st = defaultdict(lambda: [0, 0, 0, 0])
    aux_viol = []
    for row in generate(ctx):
        active, tight, viol, _, _ = evaluate_row(row, ctx.val, data.M)
        if row.aux:
            if viol > 1e-6:
                aux_viol.append((row.eq, row.idx, viol))
            continue
        s = st[row.eq]
        s[0] += 1
        s[1] += active
        s[2] += tight
        s[3] += viol > 1e-6
    return st, aux_viol


class SparseEqualsFull(unittest.TestCase):
    def test_profiles(self):
        for case in CASES:
            data, point, struct = load(case)
            self.assertTrue(struct["evaluator_feasible"])
            for profile in PROFILES:
                full, aux_viol = full_stats(data, point, profile)
                self.assertEqual(aux_viol, [], f"{case}/{profile}: warm start violates auxiliary rows")
                sparse = audit_point(data, point, profile)
                self.assertEqual(set(full), set(sparse), f"{case}/{profile}")
                for eq, (rows, act, tig, vio) in full.items():
                    s = sparse[eq]
                    self.assertEqual((rows, act, tig, vio), (s["rows"], s["active"], s["tight"], s["violated"]),
                                     f"{case}/{profile} eq {eq}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
