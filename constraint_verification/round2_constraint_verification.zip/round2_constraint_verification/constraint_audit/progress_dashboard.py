"""Live dashboard for running COPT jobs: parses COPT log files and plots bound/incumbent/gap.

    python3 progress_dashboard.py --logs copt_logs/C_3_4_reduced_40min.log copt_logs/C_3_4_corrected_40min.log \
        --time-limit 2400 --port 8765
Then open http://127.0.0.1:8765
"""

from __future__ import annotations

import argparse
import json
import re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROW = re.compile(r"^\s*([H*]?)\s*(\d+)\s+(\d+)\s+(\S+)\s+(\d+)\s+(\S+)\s+(\S+)\s+(\S+)\s+([\d.]+)s\s*$")


def num(s):
    try:
        v = float(s.rstrip("%"))
    except ValueError:
        return None
    return v if v == v and abs(v) != float("inf") else None


def parse(path: Path):
    pts, final = [], {}
    if not path.exists():
        return dict(points=pts, final=final, started=False)
    for line in path.read_text(errors="ignore").splitlines():
        m = ROW.match(line)
        if m:
            heur, nodes, _, _, _, bnd, sol, gap, t = m.groups()
            pts.append(dict(t=float(t), bound=num(bnd), sol=num(sol), gap=num(gap), nodes=int(nodes), heur=bool(heur)))
            continue
        for key, lab in (("Best solution", "best_solution"), ("Best bound", "best_bound"), ("Best gap", "best_gap"),
                         ("Solve time", "solve_time"), ("Solution status", "status"), ("MIP status", "mip_status")):
            if line.startswith(key):
                final[lab] = line.split(":", 1)[1].strip()
    return dict(points=pts, final=final, started=True)


PAGE = r"""<!doctype html><html><head><meta charset="utf-8"><title>COPT 求解进度</title>
<style>body{font-family:-apple-system,Helvetica,sans-serif;margin:20px;background:#fafafa}
.card{background:#fff;border-radius:8px;padding:14px 18px;margin-bottom:16px;box-shadow:0 1px 3px #0002}
.bar{height:14px;background:#eee;border-radius:7px;overflow:hidden}.fill{height:100%;background:#4a90d9}
table{border-collapse:collapse}td,th{padding:3px 12px;text-align:right}th{color:#666;font-weight:normal}
canvas{width:100%;height:auto}.done{color:#2a8a2a;font-weight:bold}</style></head><body>
<h2>__TITLE__</h2><div id="cards"></div>
<div class="card"><b>目标值上下界随时间变化</b>（实线 = 当前最好解，虚线 = 下界）<canvas id="c1" width="1200" height="280"></canvas></div>
<div class="card"><b>Gap (%) 随时间变化</b><canvas id="c2" width="1200" height="280"></canvas></div>
<p style="color:#888">每 5 秒自动刷新。<span id="ts"></span>
<button id="save" onclick="saveFigs()">保存两张图为 PNG</button> <span id="saved"></span></p>
<script>
const COLORS=["#d9534f","#4a90d9","#e67e22","#16a085"];
function draw(cv,series,key,key2,ylab){const c=cv.getContext("2d"),W=cv.width,H=cv.height,L=60,B=30;
 c.clearRect(0,0,W,H);let xs=[],ys=[];
 series.forEach(s=>s.points.forEach(p=>{xs.push(p.t);[key,key2].forEach(k=>{if(k&&p[k]!=null&&isFinite(p[k]))ys.push(p[k])})}));
 if(!xs.length)return;let x1=Math.max(...xs,10),y0=Math.min(...ys),y1=Math.max(...ys);
 if(key==="gap"){y0=0;y1=Math.min(y1,100)}else{y0=Math.max(0,y0);}
 if(y1-y0<1e-9)y1=y0+1;const X=t=>L+(W-L-10)*t/x1,Y=v=>H-B-(H-B-10)*(Math.min(v,y1)-y0)/(y1-y0);
 c.strokeStyle="#ccc";c.fillStyle="#666";c.font="12px sans-serif";
 for(let i=0;i<=5;i++){const v=y0+(y1-y0)*i/5,y=Y(v);c.beginPath();c.moveTo(L,y);c.lineTo(W-10,y);c.stroke();c.fillText(v.toFixed(key==="gap"?1:3),5,y+4)}
 for(let i=0;i<=6;i++){const t=x1*i/6;c.fillText(Math.round(t)+"s",X(t)-10,H-10)}
 series.forEach((s,k)=>{[[key,[]],[key2,[6,4]]].forEach(([kk,dash])=>{if(!kk)return;c.setLineDash(dash);c.strokeStyle=COLORS[k];c.lineWidth=2;c.beginPath();let f=true;
  s.points.forEach(p=>{const v=p[kk];if(v==null||!isFinite(v))return;const x=X(p.t),y=Y(v);f?c.moveTo(x,y):c.lineTo(x,y);f=false});c.stroke()});c.setLineDash([]);
  c.fillStyle=COLORS[k];c.fillText("■ "+s.name,L+10+k*230,15)});}
async function tick(){const r=await fetch("/data");const d=await r.json();let h="";
 d.series.forEach((s,k)=>{const p=s.points[s.points.length-1]||{},f=s.final,t=f.solve_time?parseFloat(f.solve_time):(p.t||0);
  const pct=Math.min(100,100*t/d.limit),done=!!f.best_gap;
  h+=`<div class="card"><b style="color:${COLORS[k]}">${s.name}</b> ${done?'<span class="done">已结束：'+(f.status||"")+'</span>':(s.started?"运行中":"未开始")}
  <div class="bar"><div class="fill" style="width:${pct}%"></div></div><small>${t.toFixed(0)} / ${d.limit} s</small>
  <table><tr><th>当前最好解</th><th>下界</th><th>Gap</th><th>已搜索节点</th></tr>
  <tr><td>${done?f.best_solution:(p.sol??"-")}</td><td>${done?f.best_bound:(p.bound??"-")}</td><td>${done?f.best_gap:(p.gap!=null?p.gap.toFixed(2)+"%":"-")}</td><td>${p.nodes??"-"}</td></tr></table></div>`});
 document.getElementById("cards").innerHTML=h;draw(document.getElementById("c1"),d.series,"sol","bound");
 draw(document.getElementById("c2"),d.series,"gap",null);document.getElementById("ts").textContent="更新于 "+new Date().toLocaleTimeString();}
async function saveFigs(){let msg=[];for(const [id,n] of [["c1","__PREFIX__bound_incumbent.png"],["c2","__PREFIX__gap.png"]]){
 const cv=document.getElementById(id),t=document.createElement("canvas");t.width=cv.width;t.height=cv.height;
 const g=t.getContext("2d");g.fillStyle="#fff";g.fillRect(0,0,t.width,t.height);g.drawImage(cv,0,0);
 const r=await fetch("/save?name="+n,{method:"POST",body:t.toDataURL("image/png")});msg.push(await r.text())}
 document.getElementById("saved").textContent=msg.join("; ")}
tick();setInterval(tick,5000);
</script></body></html>"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--logs", nargs="+", required=True)
    ap.add_argument("--names", nargs="*")
    ap.add_argument("--time-limit", type=float, default=2400)
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--fig-prefix", default="dashboard_")
    ap.add_argument("--title", default="COPT 求解进度：C-4-3（精简模型 vs 修正模型）")
    ap.add_argument("--save-dir", default=str(Path(__file__).resolve().parent / "figures"))
    args = ap.parse_args()
    logs = [Path(p) for p in args.logs]
    names = args.names or [p.stem for p in logs]

    class H(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path.startswith("/data"):
                body = json.dumps(dict(limit=args.time_limit,
                                       series=[dict(name=n, **parse(p)) for n, p in zip(names, logs)])).encode()
                ctype = "application/json"
            else:
                body, ctype = PAGE.replace("__TITLE__", args.title).replace("__PREFIX__", args.fig_prefix).encode(), "text/html; charset=utf-8"
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_POST(self):
            import base64
            from urllib.parse import parse_qs, urlparse
            name = Path(parse_qs(urlparse(self.path).query).get("name", ["figure.png"])[0]).name
            data = self.rfile.read(int(self.headers["Content-Length"])).decode()
            out = Path(args.save_dir) / name
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(base64.b64decode(data.split(",", 1)[1]))
            body = f"saved {out.name}".encode()
            self.send_response(200)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *a):
            pass

    ThreadingHTTPServer(("127.0.0.1", args.port), H).serve_forever()


if __name__ == "__main__":
    main()
