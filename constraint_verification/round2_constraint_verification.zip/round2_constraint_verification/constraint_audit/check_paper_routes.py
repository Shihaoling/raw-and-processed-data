"""Check the routes reported in the paper (Gurobi, Table 'routes of the small instances') against the
full (corrected) and reduced models: re-time them with the SVNS evaluator and evaluate every row.

Run: python3 check_paper_routes.py  -> outputs/paper_routes_check.json
"""

from __future__ import annotations

import json
from pathlib import Path

from copt_model import load_data
from run_svns_audit import audit_point
from svns_point import build_point

HERE = Path(__file__).resolve().parent
PAPER = {  # routes without failure, as printed in the manuscript
    "C_3_4": ([0, 4, 18], {1: {1: [0, 9, 10, 12, 11, 13, 14, 8, 7, 4], 2: [4, 17, 16, 18]}, 2: {1: [4, 15, 18]}}),
    "R_3_4": ([0, 6, 18], {1: {1: [0, 17, 16, 14, 15, 13, 12, 10, 11, 6], 2: [6, 7, 18]}, 2: {1: [0, 9, 8, 18]}}),
    "RC_3_4": ([0, 4, 18], {1: {1: [0, 9, 8, 4], 2: [4, 11, 10, 12, 13, 15, 14, 16, 17, 18]}, 2: {1: [4, 7, 18]}}),
}
GUROBI = {"C_3_4": 7.48, "R_3_4": 7.47, "RC_3_4": 7.895}


def main():
    out = {}
    for case, (truck, drones) in PAPER.items():
        data = load_data(case)
        point, struct, _ = build_point(data, truck, drones)
        res = dict(gurobi_reported=GUROBI[case], evaluator_completion=struct["completion"],
                   evaluator_feasible=struct["evaluator_feasible"])
        for prof in ("corrected", "reduced"):
            st = audit_point(data, point, prof)
            res[f"violated_rows_{prof}"] = {eq: s["violated"] for eq, s in st.items() if s["violated"]}
        out[case] = res
        print(case, res)
    (HERE / "outputs" / "paper_routes_check.json").write_text(json.dumps(out, indent=1), encoding="utf-8")


if __name__ == "__main__":
    main()
