"""Solver-neutral rows of the first-stage MILP, numbered as in the R1 PDF (eqs. 2-43).

Every row is ``lo <= sum(coef * var) <= hi``.  A big-M row additionally carries a
*gate* expression g (g = 0 when the logical condition holds); the stated row is

    lo - Mval * g <= expr <= hi + Mval * g.

Rows without big-M may still carry a *report gate* (``Mval is None``) that only
marks whether the row belongs to the used part of the solution (e.g. a visited
node).  A row is "active" when its gate value is <= 0 and "tight" when it is
active and its expression meets one of its bounds.

The same generator is used to (i) evaluate SVNS solutions (`run_svns_audit.py`)
and (ii) build the COPT model (`copt_model.py`), so the audited constraints and
the solved constraints are literally the same objects.

Variable keys
-------------
('x',i,j) truck arc          ('y',s,d,i,j) drone arc     ('z',s,d,i,a,b) node-sortie link
('p',i,j) precedence          ('u',i) truck order          ('w',s,d,i) drone order
('tA',i) truck arrival ť_i    ('tL',i) truck departure t̂_i (t̂_|N| = objective)
('dA',d,i) drone arrival ť_i^d (retrieval completion at N2)   ('dL',d,i) drone departure t̂_i^d
Linearisation auxiliaries (not paper constraints, tagged aux=True):
('delta',s,d) eqs. (47)-(49);  ('mx',s,d) max in (17);  ('h',s,d,i,j,a,b) max in (19);
('v',a,b) max in (24);  ('q',d,a,b) max in (37).
"""

from __future__ import annotations

import math
from typing import Callable, Dict, Iterable, Iterator, List, Optional, Sequence, Tuple

INF = math.inf

PAPER_EQS = [str(k) for k in range(2, 44)]
C_LABEL = dict(zip(PAPER_EQS, [f"C{k}" for k in list(range(1, 30)) + [32, 33, 34, 35, 37, 38, 39, 40, 41, 42, 43, 44, 45]]))
BLOCKS = [
    ("B1 Depot", range(2, 3)),
    ("B2 Truck routing & precedence", range(3, 8)),
    ("B3 Drone routing", range(8, 23)),
    ("B4 Truck-drone coordination", range(23, 25)),
    ("B5 Truck timing", range(25, 30)),
    ("B6 Drone timing", range(30, 38)),
    ("B7 Time windows", range(38, 42)),
    ("B8 Route/sortie duration", range(42, 44)),
]
BLOCK_OF = {str(e): name for name, rng in BLOCKS for e in rng}

# Theory-based treatment proposed in the analysis (PDF numbering).
PROPOSAL = {
    "2": "keep, rewrite as sum x_0i = 1 (current form allows several departures)",
    "5": "merge with (6)", "6": "merge with (5)",
    "7": "delete (implied by 5-6; p_a0 only relaxes 37)",
    "8": "delete (implied by 13+15) -> one row sum launch <= 1",
    "9": "replace by sum launch <= 1", "10": "delete (implied by 13+15)", "11": "delete (implied by 13+15)",
    "14": "delete / move to variable domain (MTZ needs no bounds)",
    "17": "delete (sum of binaries <= |D| <= nu)",
    "18": "keep, extend domain to N1 x N2",
    "21": "delete (special case of 12 for |N_s|=1)", "22": "delete (special case of 13)",
    "26": "delete (waiting can be shifted to departure)",
    "30": "keep, extend to l = 0 and linearise product",
    "31": "merge with (32)", "32": "merge with (31)", "33": "merge with (34)", "34": "merge with (33)",
    "38": "merge with (39)", "39": "merge with (38)", "40": "merge with (41)", "41": "merge with (40)",
}

PROFILES = {
    # exactly the R1 paper (domains as printed)
    "paper": dict(fix_depot=False, z_link_depots=False, origin_launch=False, unify_points=False,
                  launch_le1=False, drop=()),
    # paper + three corrections found in the analysis (the Gurobi notebook already had all three)
    "corrected": dict(fix_depot=True, z_link_depots=True, origin_launch=True, unify_points=False,
                      launch_le1=False, drop=()),
    # corrected + theory-based reductions (42 -> 33 paper rows before two-sided merging)
    "reduced": dict(fix_depot=True, z_link_depots=True, origin_launch=True, unify_points=True,
                    launch_le1=True, drop=("7", "14", "17", "26")),
}


class Row:
    __slots__ = ("eq", "idx", "terms", "lo", "hi", "gate", "gconst", "Mval", "aux")

    def __init__(self, eq, idx, terms, lo=-INF, hi=INF, gate=None, gconst=0.0, Mval=None, aux=False):
        self.eq, self.idx, self.terms, self.lo, self.hi = eq, idx, terms, lo, hi
        self.gate, self.gconst, self.Mval, self.aux = gate, gconst, Mval, aux

    @property
    def kind(self) -> str:
        if self.lo == self.hi:
            return "eq"
        if self.lo > -INF and self.hi < INF:
            return "range"
        return "ineq"


class Ctx:
    """Index sets and cached term lists.  With ``sparse=True`` (evaluation only) term
    lists are pruned to variables that are nonzero in ``point``; the row values are
    unchanged because zero terms contribute nothing."""

    def __init__(self, data, point: Optional[Dict] = None, sparse: bool = False, **opts):
        self.data, self.point, self.sparse = data, point or {}, sparse
        prof = dict(PROFILES["paper"])
        prof.update(opts)
        self.opt = prof
        self._cache: Dict = {}
        self.M = data.M
        self.arcs = {s: data.arcs(s) for s in data.S}

    def val(self, var) -> float:
        return self.point.get(var, 1.0 if var[0] == "w" else 0.0)

    def _terms(self, key, builder: Callable[[], List]):
        if key not in self._cache:
            terms = builder()
            if self.sparse:
                terms = [(v, c) for v, c in terms if self.val(v) != 0]
            self._cache[key] = terms
        return self._cache[key]

    # ---- reusable sums ------------------------------------------------------ #
    def x_out(self, a):
        return self._terms(("xo", a), lambda: [(("x", a, j), 1.0) for j in self.data.N2 if j != a])

    def x_in(self, b):
        return self._terms(("xi", b), lambda: [(("x", i, b), 1.0) for i in self.data.N1 if i != b])

    def L(self, l, d):  # launches of drone d at node l (sum over targets)
        D = self.data
        return self._terms(("L", l, d), lambda: [(("y", s, d, l, j), 1.0) for s in D.S for j in D.Ns[s]])

    def R(self, r, d):  # retrievals of drone d at node r
        D = self.data
        return self._terms(("R", r, d), lambda: [(("y", s, d, i, r), 1.0) for s in D.S for i in D.Ns[s]])

    def In(self, s, d, j):
        D = self.data
        return self._terms(("In", s, d, j), lambda: [(("y", s, d, i, j), 1.0) for i in D.Ns[s] + D.N1 if i != j])

    def Out(self, s, d, p):
        D = self.data
        return self._terms(("Out", s, d, p), lambda: [(("y", s, d, p, j), 1.0) for j in D.Ns[s] + D.N2 if j != p])

    def launch_arcs(self, s, d):
        D = self.data
        return self._terms(("LA", s, d), lambda: [(("y", s, d, a, j), 1.0) for a in D.N1 for j in D.Ns[s]])

    def retr_arcs(self, s, d):
        D = self.data
        return self._terms(("RA", s, d), lambda: [(("y", s, d, i, b), 1.0) for i in D.Ns[s] for b in D.N2])

    def internal(self, s, d):
        D = self.data
        return self._terms(("IA", s, d), lambda: [(("y", s, d, i, j), 1.0) for i in D.Ns[s] for j in D.Ns[s] if i != j])

    def zsum(self, s, i, d=None):
        D = self.data
        ds = D.D if d is None else [d]
        return self._terms(("Z", s, i, d), lambda: [(("z", s, dd, i, a, b), 1.0) for dd in ds for a in D.N1 for b in D.N2])


def neg(terms):
    return [(v, -c) for v, c in terms]


def one_minus(terms):
    """gate 1 - sum(terms)"""
    return neg(terms), 1.0


# --------------------------------------------------------------------------- #
# Row generators, one per equation number
# --------------------------------------------------------------------------- #

def eq2(c: Ctx):
    D = c.data
    yield Row("2", (), c.x_out(0) + neg(c.x_in(D.dest)), 0.0, 0.0)
    if c.opt["fix_depot"]:
        yield Row("2fix", (), c.x_out(0), 1.0, 1.0)


def eq3(c):
    for j in c.data.Np:
        yield Row("3", (j,), c.x_in(j) + neg(c.x_out(j)), 0.0, 0.0, gate=one_minus(c.x_in(j))[0], gconst=1.0)


def eq4(c):
    D = c.data
    K = D.C + 2
    for i in D.N1:
        for j in D.N2:
            if i != j:
                yield Row("4", (i, j), [(("u", i), 1.0), (("u", j), -1.0)], hi=-1.0,
                          gate=[(("x", i, j), -1.0)], gconst=1.0, Mval=K)


def eq5_6(c):
    D = c.data
    K = D.C + 2
    for i in D.N1:
        for j in D.N2:
            if i != j:
                e = [(("u", i), 1.0), (("u", j), -1.0)]
                yield Row("5", (i, j), e, lo=1.0, gate=[(("p", i, j), 1.0)], Mval=K)
                yield Row("6", (i, j), e, hi=-1.0, gate=[(("p", i, j), -1.0)], gconst=1.0, Mval=K)


def eq7(c):
    N3 = c.data.N3
    for i in N3:
        for j in N3:
            if i != j:
                yield Row("7", (i, j), [(("p", i, j), 1.0), (("p", j, i), 1.0)], 1.0, 1.0)


def eq8_11(c):
    D, M = c.data, c.M
    for s in D.S:
        if s in D.S_node:
            continue
        for d in D.D:
            if c.opt["launch_le1"]:
                yield Row("L1", (s, d), c.launch_arcs(s, d), hi=1.0)
                continue
            g = [(("delta", s, d), -1.0)]
            yield Row("8", (s, d), c.launch_arcs(s, d), lo=1.0, gate=g, gconst=1.0, Mval=M)
            yield Row("9", (s, d), c.launch_arcs(s, d), hi=1.0, gate=g, gconst=1.0, Mval=M)
            yield Row("10", (s, d), c.retr_arcs(s, d), lo=1.0, gate=g, gconst=1.0, Mval=M)
            yield Row("11", (s, d), c.retr_arcs(s, d), hi=1.0, gate=g, gconst=1.0, Mval=M)
            if not c.sparse:  # (47)-(48): delta = max of internal arcs
                for v, _ in c.internal(s, d):
                    yield Row("47", (s, d) + v[3:], [(("delta", s, d), 1.0), (v, -1.0)], lo=0.0, aux=True)
                yield Row("48", (s, d), [(("delta", s, d), 1.0)] + neg(c.internal(s, d)), hi=0.0, aux=True)


def _covered(c, s):
    return c.opt["unify_points"] or s not in c.data.S_node


def eq12_13(c):
    D = c.data
    for s in D.S:
        if not _covered(c, s):
            continue
        for j in D.Ns[s]:
            terms = [t for d in D.D for t in c.In(s, d, j)]
            yield Row("12", (s, j), terms, 1.0, 1.0)
        for d in D.D:
            for p in D.Ns[s]:
                yield Row("13", (s, d, p), c.In(s, d, p) + neg(c.Out(s, d, p)), 0.0, 0.0,
                          gate=neg(c.In(s, d, p)), gconst=1.0)


def eq14(c):
    D = c.data
    for s in D.S:
        if s in D.S_node:
            continue
        for d in D.D:
            for i in D.Ns[s]:
                yield Row("14", (s, d, i), [(("w", s, d, i), 1.0)], 1.0, float(len(D.Ns[s])),
                          gate=neg(c.In(s, d, i)), gconst=1.0)


def eq15(c):
    D = c.data
    for s in D.S:
        if s in D.S_node:
            continue
        n = len(D.Ns[s])
        for d in D.D:
            for i in D.Ns[s]:
                for j in D.Ns[s]:
                    if i != j:
                        yield Row("15", (s, d, i, j), [(("w", s, d, i), 1.0), (("w", s, d, j), -1.0)], hi=-1.0,
                                  gate=[(("y", s, d, i, j), -1.0)], gconst=1.0, Mval=float(n))


def eq16(c):
    D = c.data
    for s, prs in D.pairs.items():
        for i, j in prs:
            terms = [(("y", s, d, i, j), 1.0) for d in D.D] + [(("y", s, d, j, i), 1.0) for d in D.D]
            if c.sparse:
                terms = [(v, k) for v, k in terms if c.val(v)]
            yield Row("16", (s, i, j), terms, 1.0, 1.0)


def eq17(c):
    D = c.data
    for s in D.S:
        yield Row("17", (s,), [(("mx", s, d), 1.0) for d in D.D], hi=float(D.nu))
        if not c.sparse:
            for d in D.D:
                for (i, j) in c.arcs[s]:
                    yield Row("17aux", (s, d, i, j), [(("mx", s, d), 1.0), (("y", s, d, i, j), -1.0)], lo=0.0, aux=True)


def eq18(c):
    D, M = c.data, c.M
    A = D.N1 if c.opt["z_link_depots"] else D.Np
    B = D.N2 if c.opt["z_link_depots"] else D.Np
    for s in D.S:
        ns = D.Ns[s]
        for d in D.D:
            if c.sparse:  # only rows with y_ai = y_jb = 1 can be active; the rest hold for any M >= 1
                la = [(a, i) for a in A for i in ns if c.val(("y", s, d, a, i))]
                ra = [(j, b) for j in ns for b in B if c.val(("y", s, d, j, b))]
                combos = [(a, b, i, j) for a, i in la for j, b in ra]
            else:
                combos = [(a, b, i, j) for a in A for b in B for i in ns for j in ns]
            for a, b, i, j in combos:
                ya, yb = ("y", s, d, a, i), ("y", s, d, j, b)
                zj, zi = ("z", s, d, j, a, b), ("z", s, d, i, a, b)
                terms = [(zj, 1.0), (zi, 1.0)] if i != j else [(zi, 2.0)]
                yield Row("18", (s, d, a, b, i, j), terms + [(ya, -1.0), (yb, -1.0)], lo=0.0,
                          gate=[(ya, -1.0), (yb, -1.0)], gconst=2.0, Mval=M)


def count18(c) -> int:
    D = c.data
    A = D.N1 if c.opt["z_link_depots"] else D.Np
    B = D.N2 if c.opt["z_link_depots"] else D.Np
    return sum(len(D.Ns[s]) ** 2 for s in D.S) * len(D.D) * len(A) * len(B)


def eq19(c):
    D = c.data
    ab = [(a, b) for a in D.N1 for b in D.N2 if a != b]
    for s in D.S:
        if s in D.S_node:
            continue
        for d in D.D:
            for i in D.Ns[s]:
                for j in D.Ns[s]:
                    if i == j:
                        continue
                    y = ("y", s, d, i, j)
                    hs = [("h", s, d, i, j, a, b) for a, b in ab]
                    if c.sparse:
                        hs = [h for h in hs if c.val(h)] if c.val(y) else []
                    yield Row("19", (s, d, i, j), [(h, 1.0) for h in hs] + [(y, -1.0)], lo=0.0,
                              gate=[(y, -1.0)], gconst=1.0)
                    if not c.sparse:
                        for h in hs:
                            a, b = h[5], h[6]
                            yield Row("19aux", h[1:], [(h, 1.0), (("z", s, d, i, a, b), -1.0)], hi=0.0, aux=True)
                            yield Row("19aux", h[1:] + ("j",), [(h, 1.0), (("z", s, d, j, a, b), -1.0)], hi=0.0, aux=True)


def eq20(c):
    D = c.data
    for s in D.S:
        for i in D.Ns[s]:
            yield Row("20", (s, i), c.zsum(s, i), 1.0, 1.0)


def eq21_22(c):
    D = c.data
    if c.opt["unify_points"]:
        return
    for s in sorted(D.S_node):
        for j in D.Ns[s]:
            terms = [(("y", s, d, i, j), 1.0) for d in D.D for i in D.N1]
            if c.sparse:
                terms = [(v, k) for v, k in terms if c.val(v)]
            yield Row("21", (s, j), terms, 1.0, 1.0)
        for d in D.D:
            for p in D.Ns[s]:
                inn = [(("y", s, d, i, p), 1.0) for i in D.N1]
                out = [(("y", s, d, p, j), 1.0) for j in D.N2]
                if c.sparse:
                    inn = [(v, k) for v, k in inn if c.val(v)]
                    out = [(v, k) for v, k in out if c.val(v)]
                yield Row("22", (s, d, p), inn + neg(out), 0.0, 0.0, gate=neg(inn), gconst=1.0)


def eq23(c):
    D = c.data
    for s in D.S:
        for i in D.Ns[s]:
            for a in D.N1:
                for b in D.N2:
                    z = [(("z", s, d, i, a, b), 2.0) for d in D.D]
                    if c.sparse:
                        z = [(v, k) for v, k in z if c.val(v)]
                    yield Row("23", (s, i, a, b), z + neg(c.x_out(a)) + neg(c.x_in(b)), hi=0.0,
                              gate=[(v, -k / 2) for v, k in z], gconst=1.0)


def eq24(c):
    D = c.data
    K = D.dest + 2
    for a in D.N1:
        for b in D.N2:
            yield Row("24", (a, b), [(("u", b), 1.0), (("u", a), -1.0)], lo=1.0,
                      gate=[(("v", a, b), -1.0)], gconst=1.0, Mval=float(K))
    if not c.sparse:
        for s in D.S:
            for d in D.D:
                for i in D.Ns[s]:
                    for a in D.N1:
                        for b in D.N2:
                            yield Row("24aux", (s, d, i, a, b), [(("v", a, b), 1.0), (("z", s, d, i, a, b), -1.0)],
                                      lo=0.0, aux=True)


def eq25_27(c):
    D, M = c.data, c.M
    for i in D.N1:
        for j in D.N2:
            if i == j:
                continue
            e = [(("tA", j), 1.0), (("tL", i), -1.0)]
            g = [(("x", i, j), -1.0)]
            t = float(D.tk[i, j])
            yield Row("25", (i, j), e, lo=t, gate=g, gconst=1.0, Mval=M)
            yield Row("26", (i, j), e, hi=t, gate=g, gconst=1.0, Mval=M)
    for i in D.N2:
        yield Row("27", (i,), [(("tA", i), 1.0), (("tL", i), -1.0)], hi=0.0, gate=neg(c.x_in(i)), gconst=1.0)


def eq28_29(c):
    D, M = c.data, c.M
    for l in D.N1:
        for d in D.D:
            yield Row("28", (l, d), [(("tL", l), 1.0), (("dL", d, l), -1.0)], lo=0.0,
                      gate=neg(c.L(l, d)), gconst=1.0, Mval=M)
    for r in D.N2:
        for d in D.D:
            yield Row("29", (r, d), [(("tL", r), 1.0), (("dA", d, r), -1.0)], lo=0.0,
                      gate=neg(c.R(r, d)), gconst=1.0, Mval=M)


def eq30(c):
    """(30) linearised exactly for binary L,R:
    30a: t̂_l^d >= ť_l + LTD   - M[(1-L) + R]
    30b: t̂_l^d >= ť_l^d + LTD - M[(1-L) + (1-R)]"""
    D, M = c.data, c.M
    nodes = D.N1 if c.opt["origin_launch"] else D.Np
    for l in nodes:
        for d in D.D:
            Lt, Rt = c.L(l, d), (c.R(l, d) if l != 0 else [])
            yield Row("30", (l, d, "a"), [(("dL", d, l), 1.0), (("tA", l), -1.0)], lo=D.LTD,
                      gate=neg(Lt) + Rt, gconst=1.0, Mval=M)
            if l != 0:
                yield Row("30", (l, d, "b"), [(("dL", d, l), 1.0), (("dA", d, l), -1.0)], lo=D.LTD,
                          gate=neg(Lt) + neg(Rt), gconst=2.0, Mval=M)


def eq31_34(c):
    D, M = c.data, c.M
    for s in D.S:
        for d in D.D:
            for j in D.Ns[s]:
                e = [(("dL", d, j), 1.0), (("dA", d, j), -1.0)]
                g = neg(c.In(s, d, j))
                ts = D.service[j]
                yield Row("31", (s, d, j), e, lo=ts, gate=g, gconst=1.0, Mval=M)
                yield Row("32", (s, d, j), e, hi=ts, gate=g, gconst=1.0, Mval=M)
            for i in D.Ns[s] + D.N1:
                for j in D.Ns[s]:
                    if i == j:
                        continue
                    e = [(("dA", d, j), 1.0), (("dL", d, i), -1.0)]
                    g = [(("y", s, d, i, j), -1.0)]
                    t = float(D.td[i, j])
                    yield Row("33", (s, d, i, j), e, lo=t, gate=g, gconst=1.0, Mval=M)
                    yield Row("34", (s, d, i, j), e, hi=t, gate=g, gconst=1.0, Mval=M)


def eq35_36(c):
    D, M = c.data, c.M
    for d in D.D:
        for b in D.N2:
            yield Row("35", (d, b), [(("dA", d, b), 1.0), (("tA", b), -1.0)], lo=D.RTD,
                      gate=neg(c.R(b, d)), gconst=1.0, Mval=M)
    for s in D.S:
        for d in D.D:
            for i in D.Ns[s]:
                for b in D.N2:
                    yield Row("36", (s, d, i, b), [(("dA", d, b), 1.0), (("dL", d, i), -1.0)],
                              lo=float(D.td[i, b]) + D.RTD, gate=[(("y", s, d, i, b), -1.0)], gconst=1.0, Mval=M)


def eq37(c):
    D, M = c.data, c.M
    for d in D.D:
        if c.sparse:  # active iff q_ab = q_kl = p_ak = 1; all other rows hold whenever M >= time horizon
            used = [(a, b) for a in D.N1 for b in D.N2 if c.val(("q", d, a, b))]
            combos = [(a, b, k, l) for a, b in used for k, l in used if k != a]
        else:
            combos = [(a, b, k, l) for a in D.N1 for b in D.N2 for k in D.N1 for l in D.N2 if k != a]
        for a, b, k, l in combos:
            yield Row("37", (d, a, b, k, l), [(("dL", d, k), 1.0), (("dA", d, b), -1.0)], lo=0.0,
                      gate=[(("q", d, a, b), -1.0), (("q", d, k, l), -1.0), (("p", a, k), -1.0)], gconst=3.0, Mval=M)
    if not c.sparse:
        for s in D.S:
            for d in D.D:
                for i in D.Ns[s]:
                    for a in D.N1:
                        for b in D.N2:
                            yield Row("37aux", (s, d, i, a, b), [(("q", d, a, b), 1.0), (("z", s, d, i, a, b), -1.0)],
                                      lo=0.0, aux=True)


def count37(c) -> int:
    D = c.data
    n1, n2 = len(D.N1), len(D.N2)
    return len(D.D) * n1 * n2 * (n1 - 1) * n2


def eq38_41(c):
    D, M = c.data, c.M
    for j in D.N2:
        lo, hi = D.TK[j]
        g = neg(c.x_in(j))
        yield Row("38", (j,), [(("tA", j), 1.0)], lo=lo, gate=g, gconst=1.0, Mval=M)
        yield Row("39", (j,), [(("tA", j), 1.0)], hi=hi, gate=g, gconst=1.0, Mval=M)
    for s in D.S:
        lo, hi = D.TW[s]
        for d in D.D:
            for j in D.Ns[s]:
                g = neg(c.In(s, d, j))
                yield Row("40", (s, d, j), [(("dA", d, j), 1.0)], lo=lo, gate=g, gconst=1.0, Mval=M)
                yield Row("41", (s, d, j), [(("dA", d, j), 1.0)], hi=hi, gate=g, gconst=1.0, Mval=M)


def eq42_43(c):
    D = c.data
    for s in D.S:
        for d in D.D:
            terms = []
            for (i, j) in c.arcs[s]:
                v = ("y", s, d, i, j)
                if c.sparse and not c.val(v):
                    continue
                coef = float(D.td[i, j]) + (D.service[j] if j in D.Ns[s] else 0.0)
                terms.append((v, coef))
            yield Row("42", (s, d), terms, hi=D.DD, gate=neg(c.launch_arcs(s, d)), gconst=1.0)
    terms = []
    for i in D.N1:
        for j in D.N2:
            if i != j and (not c.sparse or c.val(("x", i, j))):
                terms.append((("x", i, j), float(D.tk[i, j])))
    yield Row("43", (), terms, hi=D.TD)


GENERATORS = [eq2, eq3, eq4, eq5_6, eq7, eq8_11, eq12_13, eq14, eq15, eq16, eq17, eq18, eq19, eq20, eq21_22,
              eq23, eq24, eq25_27, eq28_29, eq30, eq31_34, eq35_36, eq37, eq38_41, eq42_43]

SPARSE_COUNTS = {"18": count18, "37": count37}


def parent_eq(eq: str) -> str:
    """Equation that owns a row (aux / variant rows map to the paper equation they serve)."""
    return {"47": "8", "48": "8", "L1": "9", "17aux": "17", "19aux": "19",
            "24aux": "24", "37aux": "37"}.get(eq, eq)


def generate(ctx: Ctx, drop: Iterable[str] = ()) -> Iterator[Row]:
    dropped = set(map(str, drop)) | set(ctx.opt.get("drop", ()))
    for gen in GENERATORS:
        for row in gen(ctx):
            if row.eq in dropped:
                continue
            p = parent_eq(row.eq)
            if p != row.eq and p in dropped:
                # delta (47)-(48) stays while any of (8)-(11) remains
                if row.eq not in ("47", "48") or {"8", "9", "10", "11"} <= dropped:
                    continue
            yield row


# --------------------------------------------------------------------------- #
# Evaluation
# --------------------------------------------------------------------------- #

def lin(terms, val) -> float:
    return sum(c * val(v) for v, c in terms)


def evaluate_row(row: Row, val, M_default: float, tol: float = 1e-6):
    """Return (active, tight, violation, needed_M, slack) for a row at a point."""
    expr = lin(row.terms, val)
    g = (lin(row.gate, val) + row.gconst) if row.gate is not None else 0.0
    active = row.gate is None or g <= tol
    relax = 0.0
    if row.Mval is not None and g > tol:
        relax = (M_default if row.Mval == "M" else row.Mval) * g
    viol = max(0.0, row.lo - relax - expr if row.lo > -INF else 0.0, expr - row.hi - relax if row.hi < INF else 0.0)
    base_gap = min(expr - row.lo if row.lo > -INF else INF, row.hi - expr if row.hi < INF else INF)
    tight = active and abs(base_gap) <= tol
    needed = 0.0
    if row.Mval is not None and g > tol:
        need = max(row.lo - expr if row.lo > -INF else 0.0, expr - row.hi if row.hi < INF else 0.0)
        needed = max(0.0, need / g)
    return active, tight, viol, needed, base_gap
