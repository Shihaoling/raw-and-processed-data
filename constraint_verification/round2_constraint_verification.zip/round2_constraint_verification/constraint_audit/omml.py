"""Minimal LaTeX -> native Word equation (OMML) converter via latex2mathml.

Supports what the report needs: sub/superscripts, accents (hat, check, overline), sums with limits,
max with a subscript, fences, spaces. Usage: add_equation(paragraph, r"\\sum_{i\\in N_1} x_{0i}=1").
"""

from __future__ import annotations

import xml.etree.ElementTree as ET

from docx.oxml import parse_xml
from latex2mathml.converter import convert

MML = "{http://www.w3.org/1998/Math/MathML}"
MNS = "http://schemas.openxmlformats.org/officeDocument/2006/math"
NARY = {"\u2211", "\u220f"}
ACCENT = {"\u02c7": "\u030c", "\u005e": "\u0302", "\u02c6": "\u0302", "\u007e": "\u0303", "\u02dc": "\u0303"}
BAR = {"\u2015", "\u00af", "\u203e", "\u0305"}


def _esc(t):
    return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


_SIZE = [None]


def _r(text, upright=False):
    # Use the mathematical set-minus glyph for a standalone LaTeX backslash.
    if text == "\\":
        text = "\u2216"
    sty = '<m:rPr><m:sty m:val="p"/></m:rPr>' if upright else ""
    wpr = (f'<w:rPr><w:rFonts w:ascii="Cambria Math" w:hAnsi="Cambria Math"/><w:sz w:val="{_SIZE[0]}"/>'
           f'<w:szCs w:val="{_SIZE[0]}"/></w:rPr>') if _SIZE[0] else ""
    return f'<m:r>{sty}{wpr}<m:t xml:space="preserve">{_esc(text)}</m:t></m:r>'


def _tag(el):
    return el.tag.replace(MML, "")


def _base_text(el):
    if _tag(el) in ("mo", "mi") and el.text:
        return el.text.strip()
    return None


def _one(children, i):
    """Convert one operand starting at children[i]; n-ary operators swallow the next operand."""
    el = children[i]
    t = _tag(el)
    if t in ("msub", "msup", "msubsup", "munder", "munderover", "mo"):
        base = el if t == "mo" else el[0]
        if _base_text(base) in NARY:
            sub = sup = ""
            if t in ("msub", "munder", "msubsup", "munderover"):
                sub = _conv(el[1])
            if t in ("msup",):
                sup = _conv(el[1])
            if t in ("msubsup", "munderover"):
                sup = _conv(el[2])
            body, j = ("", i + 1)
            if i + 1 < len(children):
                body, j = _one(children, i + 1)
            pr = (f'<m:naryPr><m:chr m:val="{base.text.strip()}"/><m:limLoc m:val="undOvr"/>'
                  + ('<m:subHide m:val="1"/>' if not sub else "") + ('<m:supHide m:val="1"/>' if not sup else "")
                  + "</m:naryPr>")
            return f"<m:nary>{pr}<m:sub>{sub}</m:sub><m:sup>{sup}</m:sup><m:e>{body}</m:e></m:nary>", j
    return _conv(el), i + 1


def _seq(children):
    out, i = [], 0
    while i < len(children):
        s, i = _one(children, i)
        out.append(s)
    return "".join(out)


def _conv(el):
    t = _tag(el)
    kids = list(el)
    if t in ("math", "mrow", "mstyle", "semantics"):
        return _seq(kids)
    if t == "mi":
        txt = el.text or ""
        return _r(txt, upright=len(txt) > 1 or el.get("mathvariant") == "normal")
    if t in ("mn", "mo", "mtext"):
        return _r(el.text or "", upright=True)
    if t == "mspace":
        return _r("\u2003", upright=True)
    if t == "msub":
        if _base_text(kids[0]) in ("max", "min"):
            return f"<m:limLow><m:e>{_conv(kids[0])}</m:e><m:lim>{_conv(kids[1])}</m:lim></m:limLow>"
        return f"<m:sSub><m:e>{_conv(kids[0])}</m:e><m:sub>{_conv(kids[1])}</m:sub></m:sSub>"
    if t == "msup":
        return f"<m:sSup><m:e>{_conv(kids[0])}</m:e><m:sup>{_conv(kids[1])}</m:sup></m:sSup>"
    if t == "msubsup":
        return (f"<m:sSubSup><m:e>{_conv(kids[0])}</m:e><m:sub>{_conv(kids[1])}</m:sub>"
                f"<m:sup>{_conv(kids[2])}</m:sup></m:sSubSup>")
    if t == "mover":
        acc = (kids[1].text or "").strip()
        if acc in BAR:
            return f'<m:bar><m:barPr><m:pos m:val="top"/></m:barPr><m:e>{_conv(kids[0])}</m:e></m:bar>'
        if acc in ACCENT:
            return f'<m:acc><m:accPr><m:chr m:val="{ACCENT[acc]}"/></m:accPr><m:e>{_conv(kids[0])}</m:e></m:acc>'
        return f"<m:limUpp><m:e>{_conv(kids[0])}</m:e><m:lim>{_conv(kids[1])}</m:lim></m:limUpp>"
    if t == "munder":
        return f"<m:limLow><m:e>{_conv(kids[0])}</m:e><m:lim>{_conv(kids[1])}</m:lim></m:limLow>"
    if t == "munderover":
        return (f"<m:limUpp><m:e><m:limLow><m:e>{_conv(kids[0])}</m:e><m:lim>{_conv(kids[1])}</m:lim></m:limLow>"
                f"</m:e><m:lim>{_conv(kids[2])}</m:lim></m:limUpp>")
    if t == "mfrac":
        return f"<m:f><m:num>{_conv(kids[0])}</m:num><m:den>{_conv(kids[1])}</m:den></m:f>"
    return _seq(kids)


WNS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"


def omath_xml(latex: str, size_pt: float | None = None) -> str:
    _SIZE[0] = int(round(size_pt * 2)) if size_pt else None
    root = ET.fromstring(convert(latex))
    body = _conv(root)
    _SIZE[0] = None
    return f'<m:oMath xmlns:m="{MNS}" xmlns:w="{WNS}">{body}</m:oMath>'


def add_equation(paragraph, latex: str, size_pt: float | None = None):
    paragraph._p.append(parse_xml(omath_xml(latex, size_pt)))
