"""Tiny instances that fit COPT's licence-free size limit (2000 rows / 2000 columns).

They are used only to verify that copt_model.py builds and solves the same rows that
the SVNS audit evaluates, and to demonstrate the effect of dropping constraints.
Writes copt_ready/instances/<case>.json-compatible instance files and a feasible
hand-made warm start (re-timed by the SVNS evaluator).

Run:  python3 toy_instances.py
"""

from __future__ import annotations

import json
from pathlib import Path

from milp_data import build
from svns_point import build_point

HERE = Path(__file__).resolve().parent
TOY = HERE / "copt_ready" / "toy"

# area target 0: two sweep lines (pairs (n0,n1), (n2,n3)); line target 1; point target 2
TOYS = {
    "TOY_1D": dict(
        drones=[1],
        instance={
            "area_type": {"0": "area", "1": "line", "2": "point"},
            "coverage_points": {"0": [[30, 26], [36, 26], [30, 30], [36, 30]],
                                "1": [[50, 44], [56, 50]],
                                "2": [[70, 74]]},
            "total_stop_nodes": [[33, 20], [50, 54], [66, 70]],
        },
        # nodes: stops 1-3, area 4-7, line 8-9, point 10, destination 11
        plan=dict(truck_route=[0, 1, 2, 3, 11],
                  drone_route={"1": {"1": [1, 4, 5, 7, 6, 2], "2": [2, 8, 9, 3], "3": [3, 10, 11]}}),
    ),
    "TOY_2D": dict(
        drones=[1, 2],
        instance={
            "area_type": {"0": "line", "1": "point"},
            "coverage_points": {"0": [[40, 36], [46, 42]], "1": [[60, 66]]},
            "total_stop_nodes": [[40, 44], [58, 60]],
        },
        # nodes: stops 1-2, line 3-4, point 5, destination 6
        plan=dict(truck_route=[0, 1, 2, 6],
                  drone_route={"1": {"1": [1, 3, 4, 2]}, "2": {"1": [2, 5, 6]}}),
    ),
}


def main():
    TOY.mkdir(parents=True, exist_ok=True)
    (HERE / "copt_ready" / "warm_start").mkdir(parents=True, exist_ok=True)
    for case, spec in TOYS.items():
        path = TOY / f"instance_{case}.json"
        path.write_text(json.dumps(spec["instance"]), encoding="utf-8")
        data = build(case, spec["drones"], instance_path=path)
        point, struct, _ = build_point(data, spec["plan"]["truck_route"], spec["plan"]["drone_route"])
        assert struct["evaluator_feasible"], struct
        warm = {"case": case, "source": "hand-made feasible plan (toy_instances.py)",
                "objective_tL_dest": struct["completion"], **spec["plan"],
                "values": {f"{k[0]}[{','.join(map(str, k[1:]))}]": v for k, v in point.items()}}
        (HERE / "copt_ready" / "warm_start" / f"{case}.json").write_text(json.dumps(warm), encoding="utf-8")
        print(case, "warm-start objective", round(struct["completion"], 4))


if __name__ == "__main__":
    main()
