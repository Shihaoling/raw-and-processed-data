"""COPT runs on the three small instances (C-4-3, R-4-3, RC-4-3 = C_3_4, R_3_4, RC_3_4).

Step 1  reduced model   (proposed simplification)
Step 2  corrected model (all 42 equations, printing errors fixed) + per-equation
        active/tight counts on the COPT optimum.

Run:  COPT_LICENSE_DIR=~/copt python3 run_copt_small.py [--time-limit 3600] [--cases ...]

Counts are reported twice:
  raw        rows of the corrected model evaluated at the solution returned by COPT.
             Continuous times that do not affect the objective may sit anywhere inside
             their slack, so these counts depend on the solver's arbitrary choice.
  canonical  the COPT routes re-timed with the SVNS evaluator (earliest-start schedule,
             same convention as the SVNS audit), so they are comparable with
             outputs/summary_main_corrected_model.csv.
Outputs: outputs/copt_small_runs.csv, outputs/copt_small_binding.csv,
         outputs/copt_small_binding_summary.csv, copt_runs/<case>_<profile>.json
"""

from __future__ import annotations

import argparse
import csv
import json
import time
from collections import defaultdict
from pathlib import Path

from copt_model import BINARY, load_data, parse_name, solve
from model_rows import BLOCK_OF, PAPER_EQS, PROFILES, PROPOSAL, Ctx, evaluate_row, generate
from run_svns_audit import audit_point
from svns_point import build_point

HERE = Path(__file__).resolve().parent
OUT = HERE / "outputs"
NAME = {"C_3_4": "C-4-3", "R_3_4": "R-4-3", "RC_3_4": "RC-4-3"}
GUROBI = {"C_3_4": 7.48, "R_3_4": 7.47, "RC_3_4": 7.895}  # original submission, not recomputed


def physical_ok(pc):
    return pc.get("evaluator_completion") is not None and not pc.get("evaluator_reason") and not pc.get("audit_problems")


def svns_obj(case):
    p = HERE / "copt_ready" / "warm_start" / f"{case}.json"
    return json.loads(p.read_text(encoding="utf-8"))["objective_tL_dest"] if p.exists() else None


def raw_counts(data, values, tol=1e-5):
    val = {}
    for name, v in values.items():
        k = parse_name(name)
        val[k] = float(round(v)) if k[0] in BINARY or k[0] in ("u", "w") else v
    ctx = Ctx(data, val, sparse=False, **PROFILES["corrected"])
    rows = list(generate(ctx))
    for row in rows:  # variables at zero are not stored in values_nonzero
        for k, _ in list(row.terms) + list(row.gate or []):
            val.setdefault(k, 0.0)
    st = defaultdict(lambda: dict(rows=0, active=0, tight=0, violated=0, kind=""))
    for row in rows:
        active, tight, viol, _, _ = evaluate_row(row, ctx.val, data.M, tol=tol)
        s = st[row.eq]
        s["rows"] += 1
        s["kind"] = s["kind"] or row.kind
        s["active"] += active
        s["tight"] += tight
        s["violated"] += viol > tol
    return st


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases", nargs="*", default=["C_3_4", "R_3_4", "RC_3_4"])
    ap.add_argument("--time-limit", type=float, default=3600)
    ap.add_argument("--profiles", nargs="*", default=["reduced", "corrected"])
    ap.add_argument("--no-warm-start", action="store_true")
    ap.add_argument("--threads", type=int, default=0)
    ap.add_argument("--log-dir", default=None, help="write the COPT log of each run to <log-dir>/<case>_<profile>.log")
    ap.add_argument("--warm-name", default=None, help="warm-start file name in copt_ready/warm_start (default: <case>)")
    ap.add_argument("--tag", default="", help="suffix for output file names, e.g. _40min")
    args = ap.parse_args()
    import coptpy

    env = coptpy.Envr()
    runs, binding = [], []
    for case in args.cases:
        data = load_data(case)
        for profile in args.profiles:
            t0 = time.time()
            log_file = Path(args.log_dir) / f"{case}_{profile}{args.tag}.log" if args.log_dir else None
            if log_file:
                log_file.parent.mkdir(parents=True, exist_ok=True)
            r = solve(case, profile, warm_start=not args.no_warm_start, time_limit=args.time_limit, env=env, log=True,
                      threads=args.threads, log_file=log_file, tag_suffix=args.tag,
                      warm_name=args.warm_name)
            pc = r.get("physical_check", {})
            runs.append(dict(case=NAME.get(case, case), profile=profile, rows=r["rows"], cols=r["cols"],
                             status=r.get("status"), objective=r.get("objective"), best_bound=r.get("best_bound"),
                             gap=r.get("gap"), runtime_s=round(r.get("runtime_s", time.time() - t0), 2),
                             svns_warm_start=svns_obj(case),
                             gurobi_reported=GUROBI.get(case), physical_ok=physical_ok(pc),
                             evaluator_completion=pc.get("evaluator_completion"),
                             physical_issue=pc.get("evaluator_reason") or "; ".join(pc.get("audit_problems", [])[:2]),
                             violated_corrected=" ".join(f"({e}):{v['violated_rows']}" for e, v in
                                                         sorted(r.get("reference_violations", {}).items())),
                             truck_route=r.get("truck_route"), drone_route=json.dumps(r.get("drone_route"))))
            print("RESULT", {k: v for k, v in runs[-1].items() if k != "drone_route"}, flush=True)
            if profile != "corrected" or "values_nonzero" not in r:
                continue
            raw = raw_counts(data, r["values_nonzero"])
            canon = {}
            if physical_ok(pc):
                point, _, _ = build_point(data, r["truck_route"], r["drone_route"])
                canon = audit_point(data, point, "corrected")
            for eq in sorted(set(raw) | set(canon), key=lambda e: (int(e) if e.isdigit() else 99, e)):
                a, c = raw.get(eq, {}), canon.get(eq, {})
                binding.append(dict(case=NAME.get(case, case), eq=f"({eq})" if eq in PAPER_EQS else eq,
                                    block=BLOCK_OF.get(eq, "aux / correction"), kind=a.get("kind") or c.get("kind", ""),
                                    rows=a.get("rows", ""), raw_active=a.get("active", ""),
                                    raw_tight=a.get("tight", ""), raw_violated=a.get("violated", ""),
                                    canon_active=c.get("active", ""), canon_tight=c.get("tight", ""),
                                    canon_violated=c.get("violated", ""), proposal=PROPOSAL.get(eq, "keep")))
    OUT.mkdir(exist_ok=True)
    tag = "_".join(args.cases) + "_" + "_".join(args.profiles) + args.tag
    write(OUT / f"copt_small_runs_{tag}.csv", runs)
    if binding:
        write(OUT / f"copt_small_binding_{tag}.csv", binding)
        agg = {}
        for b in binding:
            s = agg.setdefault(b["eq"], dict(eq=b["eq"], block=b["block"], kind=b["kind"], rows=0, raw_active=0,
                                             raw_tight=0, raw_violated=0, canon_active=0, canon_tight=0,
                                             canon_violated=0, proposal=b["proposal"]))
            for k in ("rows", "raw_active", "raw_tight", "raw_violated", "canon_active", "canon_tight", "canon_violated"):
                s[k] += b[k] if isinstance(b[k], (int, float)) else 0
        write(OUT / f"copt_small_binding_summary_{tag}.csv", agg.values())


def write(path, rows):
    rows = list(rows)
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print("written", path, flush=True)


if __name__ == "__main__":
    main()
