"""Check the archived evidence without solving or modifying any model/result."""
from pathlib import Path
import csv
import hashlib
import json
import math
import sys
ROOT = Path(__file__).resolve().parent
A = ROOT / 'constraint_audit'
checks = {}
def check(name, ok, details=None):
    checks[name] = {'passed': bool(ok), 'details': details}
def rows(name):
    with (A/'outputs'/name).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))
st = rows('stats_by_instance_and_equation.csv')
main = {r['name'] for r in st if r['dataset']=='main'}
fleet = {r['name'] for r in st if r['dataset']=='fleet'}
check('105_distinct_plans',len(main)==30 and len(fleet)==75,{'main':len(main),'fleet':len(fleet)})
check('zero_archived_constraint_violations',all(int(r['violated'])==0 for r in st),{'statistics_rows':len(st)})
structure=rows('structure_by_instance.csv')
check('all_105_plans_physically_feasible',len(structure)==105 and all(r['evaluator_feasible']=='True' and int(r['index_collisions'])==0 and r['M_covers_horizon']=='True' for r in structure))
counts = {p:len(list((ROOT/'inputs'/p).glob(pattern))) for p,pattern in [('00_instances','*/instance_*.json'),('01_main_svns_results','*/result_*.json'),('04_parameter_sensitivity/fleet_size_runs','V*/*.json')]}
check('all_geometric_inputs_and_svns_plans_included',list(counts.values())==[30,30,75],counts)
tr=rows('copt_experiments_TOY_1D_TOY_2D.csv')
for case in ('TOY_1D','TOY_2D'):
    rs={r['configuration']:r for r in tr if r['case']==case}
    ref=rs['corrected model (reference)']; red=rs['reduced model (proposal)']
    check(case+'_equal_zero_gap_executable_optima',float(ref['gap'])==float(red['gap'])==0 and abs(float(ref['objective'])-float(red['objective']))<1e-6 and ref['physical_ok']==red['physical_ok']=='True',{'corrected':ref['objective'],'reduced':red['objective']})
    safe=['corrected - (7)','corrected - (8)-(11)','corrected - (14)','corrected - (17)','corrected - (26)']
    check(case+'_reported_individual_removals',all(rs[k]['physical_ok']=='True' and abs(float(rs[k]['objective'])-float(ref['objective']))<1e-6 and float(rs[k]['gap'])==0 for k in safe))
    negative=(['corrected - (16)','corrected - (23)','corrected - (37)'] if case=='TOY_1D' else ['corrected - (23)'])
    negative.append('corrected - (21)(22) [no unification: negative control]')
    check(case+'_negative_controls',all(rs[k]['physical_ok']=='False' and float(rs[k]['objective'])<=float(ref['objective']) for k in negative),{k: {'objective':rs[k]['objective'],'physical_ok':rs[k]['physical_ok']} for k in negative})
    if case=='TOY_2D':
        check('TOY_2D_no_false_counterexample_claim',all(rs[k]['physical_ok']=='True' and abs(float(rs[k]['objective'])-float(ref['objective']))<1e-6 for k in ['corrected - (16)','corrected - (37)']))
summary=json.loads((A/'outputs/letter_30min_summary.json').read_text())
check('small_run_incumbents',abs(summary['C-4-3']['reduced']['incumbent']-7.479902)<1e-6 and abs(summary['R-4-3']['reduced']['incumbent']-7.474753)<1e-6 and abs(summary['RC-4-3']['reduced']['incumbent']-7.914022)<1e-6)
check('rc_original_vs_confirmation_distinguished',summary['RC-4-3']['corrected']['incumbent']==7.957813 and summary['RC-4-3 rerun']['corrected']['incumbent']==7.914022)
principal=[]
for case,tag in [('C_3_4','40min'),('R_3_4','30min'),('RC_3_4','30min'),('RC_3_4','30min_rerun')]:
    for profile in ('corrected','reduced'):
        p=A/'copt_runs'/f'{case}_{profile}_{tag}.json';r=json.loads(p.read_text());pc=r['physical_check']
        ok=pc.get('evaluator_completion') is not None and not pc.get('evaluator_reason') and not pc.get('audit_problems')
        principal.append((p.name,ok,r.get('gap')))
check('eight_principal_or_confirmation_solutions_executable',all(x[1] for x in principal),principal)
check('principal_small_instances_not_claimed_zero_gap',all(x[2] is not None and x[2]>0 for x in principal))
with (ROOT/'equation_crosswalk.csv').open() as f:cross=list(csv.DictReader(f))
check('all_42_R1_equations_mapped_to_28_current_numbers',len(cross)==42 and set(int(r['current_equation']) for r in cross if r['current_equation'])==set(range(2,30)))
manifest=ROOT/'MANIFEST.sha256'
if manifest.exists():
    fails=[];n=0
    for line in manifest.read_text().splitlines():
        digest,rel=line.split('  ',1);p=ROOT/rel;n+=1
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:fails.append(rel)
    check('manifest_hashes',not fails,{'files':n,'failed':fails})
else:
    check('manifest_hashes',False,'MANIFEST.sha256 missing')
print(json.dumps({'all_passed':all(x['passed'] for x in checks.values()),'checks':checks,'no_solver_run':True},indent=2))
sys.exit(0 if all(x['passed'] for x in checks.values()) else 1)
