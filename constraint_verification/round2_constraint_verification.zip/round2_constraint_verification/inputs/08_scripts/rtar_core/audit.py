"""Independent physical audit of a recovered plan and its schedule.

The audit recomputes every travel time from coordinates and speeds and checks
that the schedule is a consistent execution: monotone times, no vehicle used
before it is available, executed history unchanged, endurance respected, and
every coverage node served exactly once.  It does not reuse the evaluator's
bookkeeping beyond the reported times.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np

from .rtar import Plan, Schedule

TOL = 1e-6


def _dist(coords, a, b):
    return float(np.linalg.norm(coords[a] - coords[b]))


def audit(plan: Plan, schedule: Schedule, history: Optional[Dict] = None) -> List[str]:
    """Return a list of violations (empty when the schedule passes)."""
    P = plan.params
    problems: List[str] = []
    truck = plan.truck
    index = {n: i for i, n in enumerate(truck)}
    if len(index) != len(truck):
        problems.append("truck route repeats a node")
    # truck physics
    for k in range(1, len(truck)):
        a, b = truck[k - 1], truck[k]
        earliest = schedule.truck_leave[a] + _dist(plan.coords, a, b) / P.truck_speed
        if schedule.truck_arrival[b] < earliest - TOL:
            problems.append(f"truck arrives at {b} before it can ({schedule.truck_arrival[b]:.6f} < {earliest:.6f})")
        if schedule.truck_leave[b] < schedule.truck_arrival[b] - TOL:
            problems.append(f"truck leaves {b} before arriving")
    # drones
    served: Dict[int, Tuple[int, int]] = {}
    for d, sorties in plan.drones.items():
        timeline = []
        for si, route in enumerate(sorties):
            key = (d, si)
            times = schedule.node_time[key]
            launch = schedule.launch[key]
            retrieval = schedule.retrieval[key]
            l_node, r_node = route[0], route[-1]
            if l_node not in index or r_node not in index:
                problems.append(f"drone {d} sortie {si} not attached to truck route")
                continue
            if index[l_node] > index[r_node]:
                problems.append(f"drone {d} sortie {si} retrieved before launch stop")
            # launch only while the truck is at the launch stop
            if launch < schedule.truck_arrival[l_node] + P.launch_time - TOL or launch > schedule.truck_leave[l_node] + TOL:
                problems.append(f"drone {d} sortie {si} launches at {launch:.6f} outside truck stay at {l_node} "
                                f"[{schedule.truck_arrival[l_node]:.6f}, {schedule.truck_leave[l_node]:.6f}]")
            if abs(times[0] - launch) > TOL:
                problems.append(f"drone {d} sortie {si} first time differs from launch")
            for pos in range(1, len(route)):
                leg = _dist(plan.coords, route[pos - 1], route[pos]) / P.drone_speed
                expected = times[pos - 1] + plan.inspection.get(route[pos - 1], 0.0) + leg
                if times[pos] < expected - TOL:
                    problems.append(f"drone {d} sortie {si} reaches position {pos} too early")
                hovering = "hover" in plan.virtual_nodes.get(route[pos - 1], "")
                if times[pos] > expected + TOL and not hovering:
                    problems.append(f"drone {d} sortie {si} has an unexplained delay at position {pos}")
            flight = sum(_dist(plan.coords, route[i - 1], route[i]) / P.drone_speed for i in range(1, len(route))) \
                + sum(plan.inspection.get(n, 0.0) for n in route[1:])
            if flight > P.endurance + TOL:
                problems.append(f"drone {d} sortie {si} flight time {flight:.4f} exceeds endurance")
            # retrieval only when both truck and drone are at the retrieval stop
            if retrieval < max(times[-1], schedule.truck_arrival[r_node]) + P.retrieval_time - TOL:
                problems.append(f"drone {d} sortie {si} retrieved before truck and drone meet at {r_node}")
            if retrieval > schedule.truck_leave[r_node] + TOL:
                problems.append(f"drone {d} sortie {si} retrieved after the truck left {r_node}")
            timeline.append((launch, retrieval, si))
            for n in route[1:-1]:
                if n in plan.virtual_nodes:
                    continue
                if n not in plan.target_of:
                    problems.append(f"drone {d} sortie {si} visits non-coverage node {n}")
                elif n in served or n in plan.completed_by_failed:
                    problems.append(f"coverage node {n} served twice")
                else:
                    served[n] = key
        timeline.sort()
        for (l1, r1, s1), (l2, r2, s2) in zip(timeline, timeline[1:]):
            if l2 < r1 + P.launch_time - TOL:
                problems.append(f"drone {d} sortie {s2} launches at {l2:.6f} before sortie {s1} is retrieved at {r1:.6f}")
    missing = [n for n in plan.target_of if n not in served and n not in plan.completed_by_failed]
    if missing:
        problems.append(f"{len(missing)} coverage nodes never served")
    if schedule.completion > P.truck_endurance + TOL:
        problems.append("truck endurance exceeded")
    # executed history unchanged
    if history:
        t_f = history["time"]
        if schedule.completion < t_f - TOL:
            problems.append("completion time earlier than the failure time")
        for node, t in history["truck_arrival"].items():
            if node in schedule.truck_arrival and abs(schedule.truck_arrival[node] - t) > TOL:
                problems.append(f"executed truck arrival at {node} changed")
        for node, t in history["truck_leave"].items():
            if node in schedule.truck_leave and abs(schedule.truck_leave[node] - t) > TOL:
                problems.append(f"executed truck departure from {node} changed")
        for key, t in history["launch"].items():
            if key in schedule.launch and abs(schedule.launch[key] - t) > TOL:
                problems.append(f"executed launch {key} changed")
        for (d, si, pos), t in history["node_time"].items():
            if (d, si) in schedule.node_time and abs(schedule.node_time[(d, si)][pos] - t) > TOL:
                problems.append(f"executed node time {(d, si, pos)} changed")
        for key, t in history["retrieval"].items():
            if key in schedule.retrieval and abs(schedule.retrieval[key] - t) > TOL:
                problems.append(f"executed retrieval {key} changed")
        # nothing new happens before the event
        for node in plan.truck:
            if node not in history["truck_arrival"] and schedule.truck_arrival[node] < t_f - TOL:
                problems.append(f"new truck arrival at {node} scheduled before the failure time")
        for key, t in schedule.launch.items():
            if key not in history["launch"] and t < t_f - TOL:
                problems.append(f"new launch {key} scheduled before the failure time")
    return problems


def history_from_anchors(plan: Plan) -> Dict:
    A = plan.anchors
    return {"time": A.time, "truck_arrival": dict(A.truck_arrival), "truck_leave": dict(A.truck_leave),
            "launch": dict(A.launch), "node_time": dict(A.node_time), "retrieval": dict(A.retrieval)}
