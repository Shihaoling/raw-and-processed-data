"""Chronology-correct RTAR (real-time adaptive rescheduling) for drone failures.

The module implements Algorithm 1 of the manuscript on top of an *anchored*
schedule evaluator.  The evaluator reproduces the first-stage timing model of
``self_learning_VNS.get_total_time`` for ordinary plans and, when a plan
carries execution anchors, keeps every event that has already happened at its
recorded time.  Recovery therefore never rewrites the executed history and
never uses a drone before it has physically been retrieved.

Plan conventions
----------------
* ``coords``: ``(M, 2)`` array; virtual nodes (vehicle positions at an event)
  are appended to it.
* ``truck``: list of unique node ids visited in order.
* ``drones``: ``{drone_id: [sortie, sortie, ...]}``; each sortie is a list of
  node ids ``[launch, n_1, ..., n_k, retrieval]``.
* ``target_of``: ``{coverage node: target id}``.
* ``anchors``: recorded times of executed events (see :class:`Anchors`).
"""

from __future__ import annotations

import math
from copy import deepcopy
from dataclasses import dataclass, field
from itertools import permutations
from typing import Dict, List, Optional, Tuple

import numpy as np

EPS = 1e-9


@dataclass
class Params:
    drone_speed: float = 30.0
    truck_speed: float = 20.0
    launch_time: float = 0.1
    retrieval_time: float = 0.1
    endurance: float = 15.0
    truck_endurance: float = 200.0


@dataclass
class Anchors:
    """Times of executed events that must not change."""

    time: float = 0.0
    truck_arrival: Dict[int, float] = field(default_factory=dict)
    truck_leave: Dict[int, float] = field(default_factory=dict)
    current_stop: Optional[int] = None
    launch: Dict[Tuple[int, int], float] = field(default_factory=dict)
    node_time: Dict[Tuple[int, int, int], float] = field(default_factory=dict)
    retrieval: Dict[Tuple[int, int], float] = field(default_factory=dict)


@dataclass
class Plan:
    coords: np.ndarray
    truck: List[int]
    drones: Dict[int, List[List[int]]]
    target_of: Dict[int, int]
    inspection: Dict[int, float]
    params: Params
    anchors: Optional[Anchors] = None
    completed_by_failed: Dict[int, int] = field(default_factory=dict)
    virtual_nodes: Dict[int, str] = field(default_factory=dict)
    pending: set = field(default_factory=set)  # unfinished nodes of groups not yet reassigned

    def copy(self) -> "Plan":
        return Plan(self.coords.copy(), list(self.truck),
                    {d: [list(s) for s in ss] for d, ss in self.drones.items()},
                    self.target_of, dict(self.inspection), self.params,
                    deepcopy(self.anchors), dict(self.completed_by_failed), dict(self.virtual_nodes),
                    set(self.pending))

    def add_node(self, xy, description: str) -> int:
        node = len(self.coords)
        self.coords = np.vstack((self.coords, np.asarray(xy, dtype=float).reshape(1, 2)))
        self.inspection[node] = 0.0
        self.virtual_nodes[node] = description
        return node


class InfeasiblePlan(ValueError):
    pass


@dataclass
class Schedule:
    truck_arrival: Dict[int, float]
    truck_leave: Dict[int, float]
    launch: Dict[Tuple[int, int], float]
    node_time: Dict[Tuple[int, int], List[float]]
    node_leave: Dict[Tuple[int, int], List[float]]
    retrieval: Dict[Tuple[int, int], float]
    flight_time: Dict[Tuple[int, int], float]
    completion: float


# --------------------------------------------------------------------------- #
# Schedule evaluation
# --------------------------------------------------------------------------- #

def travel(coords, a, b, speed):
    return float(np.linalg.norm(coords[a] - coords[b])) / speed


def sortie_order(plan: Plan, drone: int) -> List[int]:
    """Chronological order of a drone's sorties; raises if they are not sequential."""
    index = {n: i for i, n in enumerate(plan.truck)}
    keyed = []
    for si, route in enumerate(plan.drones[drone]):
        if len(route) < 2:
            raise InfeasiblePlan(f"drone {drone} sortie {si} is empty")
        if route[0] not in index or route[-1] not in index:
            raise InfeasiblePlan(f"drone {drone} sortie {si} is not attached to the truck route")
        left, right = index[route[0]], index[route[-1]]
        if left > right:
            raise InfeasiblePlan(f"drone {drone} sortie {si} is retrieved before launch")
        keyed.append((left, right, si))
    keyed.sort()
    for (l1, r1, _), (l2, r2, _) in zip(keyed, keyed[1:]):
        if l2 < r1:
            raise InfeasiblePlan(f"drone {drone} has overlapping sorties")
    return [si for _, _, si in keyed]


def evaluate(plan: Plan) -> Schedule:
    """Forward schedule evaluation honouring the plan's anchors."""
    P = plan.params
    A = plan.anchors
    t_now = A.time if A else 0.0
    if len(set(plan.truck)) != len(plan.truck):
        raise InfeasiblePlan("truck route repeats a node")
    index = {n: i for i, n in enumerate(plan.truck)}
    launches: Dict[int, List[Tuple[int, int]]] = {}
    retrievals: Dict[int, List[Tuple[int, int]]] = {}
    for d in plan.drones:
        for si in sortie_order(plan, d):
            route = plan.drones[d][si]
            launches.setdefault(route[0], []).append((d, si))
            if route[-1] != route[0]:
                retrievals.setdefault(route[-1], []).append((d, si))
    for node in launches:  # a closed sortie precedes a relaunch of the same drone at that stop
        launches[node].sort(key=lambda ds: (plan.drones[ds[0]][ds[1]][-1] != node, ds))

    tr_arr, tr_leave, launch_t, node_t, node_l, retr_t, flight = {}, {}, {}, {}, {}, {}, {}
    for k, node in enumerate(plan.truck):
        if k == 0:
            arr = 0.0
        else:
            prev = plan.truck[k - 1]
            arr = tr_leave[prev] + travel(plan.coords, prev, node, P.truck_speed)
        if A and node in A.truck_arrival:
            arr = A.truck_arrival[node]
        elif A:
            arr = max(arr, t_now)
        tr_arr[node] = arr
        operations = [arr]
        retrieved_here: Dict[int, float] = {}
        for d, si in retrievals.get(node, []):
            if (d, si) not in node_t:
                raise InfeasiblePlan(f"drone {d} sortie {si} is retrieved before it is launched")
            completion = max(arr, node_t[(d, si)][-1]) + P.retrieval_time
            if A and (d, si) in A.retrieval:
                completion = A.retrieval[(d, si)]
            elif A:
                completion = max(completion, t_now)
            retr_t[(d, si)] = completion
            retrieved_here[d] = completion
            operations.append(completion)
        for d, si in launches.get(node, []):
            start = max(arr, retrieved_here.get(d, -math.inf)) + P.launch_time
            if A and (d, si) in A.launch:
                start = A.launch[(d, si)]
            elif A:
                start = max(start, t_now)
            route = plan.drones[d][si]
            arrivals = [start]
            leaves = [start + plan.inspection.get(route[0], 0.0)]
            for pos in range(1, len(route)):
                departure = max(leaves[-1], t_now) if A else leaves[-1]
                t = departure + travel(plan.coords, route[pos - 1], route[pos], P.drone_speed)
                if A and (d, si, pos) in A.node_time:
                    t = A.node_time[(d, si, pos)]
                arrivals.append(t)
                leaves.append(t + plan.inspection.get(route[pos], 0.0))
            launch_t[(d, si)] = start
            node_t[(d, si)] = arrivals
            node_l[(d, si)] = leaves
            # flight time excludes waiting at a hover point (the drone has landed at the stop)
            flight[(d, si)] = sum(travel(plan.coords, route[i - 1], route[i], P.drone_speed)
                                  for i in range(1, len(route))) + sum(plan.inspection.get(n, 0.0) for n in route[1:])
            if route[-1] == node:  # closed sortie: the truck waits and retrieves here
                completion = arrivals[-1] + P.retrieval_time
                if A and (d, si) in A.retrieval:
                    completion = A.retrieval[(d, si)]
                retr_t[(d, si)] = completion
                retrieved_here[d] = completion
                operations.append(completion)
            else:
                operations.append(start)
        leave = max(operations)
        if A and node in A.truck_leave:
            leave = A.truck_leave[node]
        elif A and node == A.current_stop:
            leave = max(leave, t_now)
        tr_leave[node] = leave
    return Schedule(tr_arr, tr_leave, launch_t, node_t, node_l, retr_t, flight, tr_leave[plan.truck[-1]])


def check_constraints(plan: Plan, schedule: Schedule) -> Optional[str]:
    """Return a violation message, or ``None`` when the plan is feasible."""
    P = plan.params
    for key, ft in schedule.flight_time.items():
        if ft > P.endurance + 1e-6:
            return f"drone {key[0]} sortie {key[1]} flight time {ft:.4f} exceeds endurance {P.endurance}"
    if schedule.completion > P.truck_endurance + 1e-6:
        return "mission exceeds the truck endurance"
    served: Dict[int, Tuple[int, int]] = {}
    for d, sorties in plan.drones.items():
        for si, route in enumerate(sorties):
            targets = set()
            for n in route[1:-1]:
                if n in plan.virtual_nodes:
                    continue
                if n not in plan.target_of:
                    return f"node {n} in drone {d} sortie {si} is not a coverage node"
                if n in served or n in plan.completed_by_failed:
                    return f"coverage node {n} is served twice"
                served[n] = (d, si)
                targets.add(plan.target_of[n])
            if len(targets) > 1:
                return f"drone {d} sortie {si} mixes targets {sorted(targets)}"
    missing = [n for n in plan.target_of
               if n not in served and n not in plan.completed_by_failed and n not in plan.pending]
    if missing:
        return f"{len(missing)} coverage nodes are not served (e.g. {missing[:5]})"
    return None


def feasible_completion(plan: Plan) -> Tuple[Optional[float], Optional[str], Optional[Schedule]]:
    try:
        schedule = evaluate(plan)
    except InfeasiblePlan as error:
        return None, str(error), None
    reason = check_constraints(plan, schedule)
    if reason:
        return None, reason, schedule
    return schedule.completion, None, schedule


# --------------------------------------------------------------------------- #
# Event-state extraction
# --------------------------------------------------------------------------- #

def interpolate(coords, a, b, t0, t1, t):
    if t1 - t0 <= EPS:
        return coords[a].copy()
    return coords[a] + (coords[b] - coords[a]) * (t - t0) / (t1 - t0)


@dataclass
class EventState:
    time: float
    truck_node: int
    truck_index: int
    truck_status: str
    truck_position: List[float]
    drone_status: Dict[int, str]
    drone_position: Dict[int, Optional[List[float]]]
    unfinished: Dict[int, List[int]]
    failed_details: Dict[int, dict]


def extract_event_state(plan: Plan, schedule: Schedule, t_f: float, failed: List[int]) -> Tuple[Plan, EventState]:
    """Return an anchored plan without the failed drones and the event state at ``t_f``."""
    new = plan.copy()
    A = Anchors(time=t_f)
    if new.anchors:
        A.truck_arrival.update(new.anchors.truck_arrival)
        A.truck_leave.update(new.anchors.truck_leave)
        A.launch.update(new.anchors.launch)
        A.node_time.update(new.anchors.node_time)
        A.retrieval.update(new.anchors.retrieval)
    # ---- truck ---------------------------------------------------------- #
    truck_status = truck_node = truck_index = None
    for k, node in enumerate(new.truck):
        arr, leave = schedule.truck_arrival[node], schedule.truck_leave[node]
        last = k == len(new.truck) - 1
        if arr <= t_f + EPS and (t_f < leave - EPS or last):
            A.truck_arrival[node] = arr
            A.current_stop = node
            truck_status, truck_node, truck_index = "at_stop", node, k
            break
        if leave <= t_f + EPS:
            A.truck_arrival[node] = arr
            A.truck_leave[node] = leave
            nxt = new.truck[k + 1]
            if t_f < schedule.truck_arrival[nxt] - EPS:
                xy = interpolate(new.coords, node, nxt, leave, schedule.truck_arrival[nxt], t_f)
                vnode = new.add_node(xy, f"truck position at t={t_f:.6f}")
                new.truck.insert(k + 1, vnode)
                A.truck_arrival[vnode] = t_f
                A.truck_leave[vnode] = t_f
                truck_status, truck_node, truck_index = "in_transit", vnode, k + 1
                break
    if truck_status is None:
        raise ValueError("truck state at the event time could not be determined")
    truck_position = [float(x) for x in new.coords[truck_node]]
    # ---- drones --------------------------------------------------------- #
    drone_status, drone_pos = {}, {}
    unfinished: Dict[int, List[int]] = {}
    failed_details = {}
    for d in list(new.drones):
        sorties = new.drones[d]
        status, pos_xy = "onboard", None
        remaining_nodes: List[int] = []
        new_sorties: List[List[int]] = []
        in_flight_sortie = None
        for si, route in enumerate(sorties):
            key = (d, si)
            launch = schedule.launch[key]
            arrivals = schedule.node_time[key]
            leaves = schedule.node_leave[key]
            retrieval = schedule.retrieval[key]
            ni = len(new_sorties)
            if retrieval <= t_f + EPS:
                A.launch[(d, ni)] = launch
                for pos in range(1, len(route)):
                    A.node_time[(d, ni, pos)] = arrivals[pos]
                A.retrieval[(d, ni)] = retrieval
                new_sorties.append(list(route))
                continue
            if launch <= t_f + EPS:
                status = "in_flight"
                in_flight_sortie = ni
                A.launch[(d, ni)] = launch
                visited_upto = 0
                for pos in range(1, len(route)):
                    if arrivals[pos] <= t_f + EPS:
                        visited_upto = pos
                        A.node_time[(d, ni, pos)] = arrivals[pos]
                route_new = list(route)
                if visited_upto == len(route) - 1:
                    status = "hovering"
                    pos_xy = new.coords[route[-1]]
                    truck_arrival = schedule.truck_arrival[route[-1]]
                    if truck_arrival > t_f + EPS:
                        # the drone waits at the retrieval stop; record the hover point so that
                        # later legs depart from it no earlier than t_f
                        vnode = new.add_node(new.coords[route[-1]], f"drone {d} hover point at t={t_f:.6f}")
                        route_new.insert(len(route) - 1, vnode)
                        del A.node_time[(d, ni, len(route) - 1)]
                        A.node_time[(d, ni, len(route) - 1)] = arrivals[-1]
                        pos_xy = new.coords[vnode]
                    else:
                        status = "being_retrieved"
                else:
                    if leaves[visited_upto] <= t_f + EPS:
                        xy = interpolate(new.coords, route[visited_upto], route[visited_upto + 1],
                                         leaves[visited_upto], arrivals[visited_upto + 1], t_f)
                    else:
                        xy = new.coords[route[visited_upto]]
                    vnode = new.add_node(xy, f"drone {d} position at t={t_f:.6f}")
                    route_new.insert(visited_upto + 1, vnode)
                    A.node_time[(d, ni, visited_upto + 1)] = t_f
                    pos_xy = new.coords[vnode]
                    remaining_nodes = list(route[visited_upto + 1:-1])
                new_sorties.append(route_new)
                continue
            remaining_nodes.extend(route[1:-1])
            new_sorties.append(list(route))
        if d in failed:
            if status != "in_flight":
                raise ValueError(f"drone {d} is not in flight at t={t_f} (status {status})")
            completed = [n for si, route in enumerate(new_sorties) for pos, n in enumerate(route)
                         if 0 < pos < len(route) - 1 and n in new.target_of and (d, si, pos) in A.node_time]
            for n in completed:
                new.completed_by_failed[n] = d
            for n in remaining_nodes:
                unfinished.setdefault(new.target_of[n], []).append(n)
            failed_details[d] = {
                "position": [float(x) for x in pos_xy],
                "completed_nodes": completed,
                "unfinished_nodes": list(remaining_nodes),
            }
            for store in (A.launch, A.node_time, A.retrieval):
                for key in [k for k in store if k[0] == d]:
                    del store[key]
            del new.drones[d]
            continue
        new.drones[d] = new_sorties
        drone_status[d] = status
        drone_pos[d] = [float(x) for x in pos_xy] if pos_xy is not None else None
    new.anchors = A
    state = EventState(t_f, truck_node, truck_index, truck_status, truck_position, drone_status, drone_pos,
                       {s: unfinished[s] for s in sorted(unfinished)}, failed_details)
    return new, state


# --------------------------------------------------------------------------- #
# Greedy route reconstruction (Algorithm 1)
# --------------------------------------------------------------------------- #

@dataclass
class Candidate:
    plan: Plan
    completion: float
    level: int
    description: dict


def _try(plan: Plan, level: int, description: dict, best: Optional[Candidate], counters: dict) -> Optional[Candidate]:
    counters["evaluated"] += 1
    completion, reason, _ = feasible_completion(plan)
    if completion is None:
        counters["infeasible"] += 1
        return best
    if best is None or completion < best.completion - 1e-9:
        return Candidate(plan, completion, level, description)
    return best


def level1_insertion(plan: Plan, schedule: Schedule, target: int, group: List[int], counters) -> Optional[Candidate]:
    """Insert the ordered group into a compatible, not yet completed sortie."""
    best = None
    t_now = plan.anchors.time
    for d, sorties in plan.drones.items():
        for si, route in enumerate(sorties):
            if schedule.retrieval[(d, si)] <= t_now + EPS:
                continue
            body = [n for n in route[1:-1] if n not in plan.virtual_nodes]
            if not body or any(plan.target_of.get(n) != target for n in body):
                continue
            first_free = 1
            for pos in range(1, len(route) - 1):
                if (d, si, pos) in plan.anchors.node_time:
                    first_free = pos + 1
            for pos in range(first_free, len(route)):
                trial = plan.copy()
                trial.drones[d][si] = route[:pos] + list(group) + route[pos:]
                best = _try(trial, 1, {"drone": d, "sortie": si, "position": pos}, best, counters)
    return best


def onboard_intervals(plan: Plan, schedule: Schedule, d: int, truck_index: int) -> List[Tuple[int, int]]:
    """Maximal future intervals [a, b] of truck-route indices during which drone ``d`` is onboard."""
    index = {n: i for i, n in enumerate(plan.truck)}
    t_now = plan.anchors.time
    onboard_from = truck_index
    future = []
    for si, route in enumerate(plan.drones[d]):
        l_idx, r_idx = index[route[0]], index[route[-1]]
        if schedule.retrieval[(d, si)] <= t_now + EPS:
            onboard_from = max(onboard_from, r_idx)
        elif schedule.launch[(d, si)] <= t_now + EPS:
            onboard_from = r_idx
        else:
            future.append((l_idx, r_idx))
    intervals = []
    for l_idx, r_idx in sorted(future):
        if onboard_from <= l_idx:
            intervals.append((onboard_from, l_idx))
        onboard_from = r_idx
    intervals.append((onboard_from, len(plan.truck) - 1))
    dest_idx = len(plan.truck) - 1
    out = []
    for a, b in intervals:
        while a < b and plan.truck[a] in plan.virtual_nodes:
            a += 1
        if plan.truck[a] in plan.virtual_nodes or plan.truck[b] in plan.virtual_nodes:
            continue
        if a >= b:  # a single stop is not an onboard interval; the destination is not a launch node
            continue
        out.append((a, b))
    return out


def level2_onboard_interval(plan: Plan, schedule: Schedule, group: List[int], truck_index: int, counters) -> Optional[Candidate]:
    best = None
    for d in plan.drones:
        for a, b in onboard_intervals(plan, schedule, d, truck_index):
            trial = plan.copy()
            trial.drones[d].append([plan.truck[a]] + list(group) + [plan.truck[b]])
            best = _try(trial, 2, {"drone": d, "launch": plan.truck[a], "retrieval": plan.truck[b]}, best, counters)
    return best


def level3_new_stop(plan: Plan, schedule: Schedule, group: List[int], operational_nodes: List[int],
                    truck_index: int, counters) -> Optional[Candidate]:
    """Insert an unused operational node before the destination and fly a sortie from it."""
    best = None
    dest = plan.truck[-1]
    dest_idx = len(plan.truck) - 1
    if truck_index >= dest_idx:
        return None
    index = {n: i for i, n in enumerate(plan.truck)}
    t_now = plan.anchors.time
    for p in operational_nodes:
        if p in index:
            continue
        for d, sorties in plan.drones.items():
            final = [si for si, r in enumerate(sorties) if r[-1] == dest]
            variants = []
            if final:
                si = final[0]
                if schedule.retrieval[(d, si)] <= t_now + EPS:
                    continue
                if (d, si, len(sorties[si]) - 1) in plan.anchors.node_time:
                    continue  # already at the destination and being retrieved
                redirected = list(sorties[si][:-1]) + [p]
                variants.append(("redirect_closed", si, redirected, [p] + list(group) + [p]))
                variants.append(("redirect_open", si, redirected, [p] + list(group) + [dest]))
            else:
                variants.append(("closed", None, None, [p] + list(group) + [p]))
                variants.append(("open", None, None, [p] + list(group) + [dest]))
            for kind, si, redirected, new_sortie in variants:
                trial = plan.copy()
                trial.truck.insert(dest_idx, p)
                if redirected is not None:
                    trial.drones[d][si] = redirected
                trial.drones[d].append(new_sortie)
                best = _try(trial, 3, {"drone": d, "new_stop": p, "variant": kind}, best, counters)
    return best


def level4_extended_stops(plan: Plan, schedule: Schedule, group: List[int],
                          operational_nodes: List[int], truck_index: int,
                          counters, max_stops: int) -> Optional[Candidate]:
    """Enumerate short ordered chains of new truck stops.

    This is a bounded extension of level 3, not a change to the event model:
    the truck still keeps every anchored stop and only unused operational stops
    are inserted before the destination.  The survivor's last future sortie is
    redirected to the first added stop and the unfinished group is launched
    from the last added stop.  It is used only by explicitly configured
    diagnostic experiments because the combinatorial search grows factorially.
    """
    if max_stops < 2:
        return None
    dest = plan.truck[-1]
    dest_idx = len(plan.truck) - 1
    if truck_index >= dest_idx:
        return None
    index = {n: i for i, n in enumerate(plan.truck)}
    unused = [p for p in operational_nodes if p not in index]
    best = None
    for d, sorties in plan.drones.items():
        final = [si for si, r in enumerate(sorties) if r[-1] == dest]
        if not final:
            continue
        si = final[0]
        if schedule.retrieval[(d, si)] <= plan.anchors.time + EPS:
            continue
        if (d, si, len(sorties[si]) - 1) in plan.anchors.node_time:
            continue
        for count in range(2, min(max_stops, len(unused)) + 1):
            for chain in permutations(unused, count):
                trial = plan.copy()
                trial.truck[dest_idx:dest_idx] = list(chain)
                trial.drones[d][si] = list(sorties[si][:-1]) + [chain[0]]
                trial.drones[d].append([chain[-1]] + list(group) + [dest])
                best = _try(
                    trial, 4,
                    {"drone": d, "new_stops": list(chain), "variant": "redirect_chain"},
                    best, counters)
    return best


def rtar(plan: Plan, schedule: Schedule, t_f: float, failed: List[int],
         operational_nodes: List[int], max_extended_stops: int = 0) -> dict:
    """One RTAR call: event-state extraction followed by greedy reconstruction."""
    anchored, state = extract_event_state(plan, schedule, t_f, failed)
    current = anchored
    current.pending = {n for group in state.unfinished.values() for n in group}
    current_schedule = evaluate(current)
    log = []
    counters = {"evaluated": 0, "infeasible": 0}
    for target, group in state.unfinished.items():
        current.pending.difference_update(group)
        best = level1_insertion(current, current_schedule, target, group, counters)
        if best is None:
            best = level2_onboard_interval(current, current_schedule, group, state.truck_index, counters)
        if best is None:
            best = level3_new_stop(current, current_schedule, group, operational_nodes, state.truck_index, counters)
        if max_extended_stops >= 2:
            extended = level4_extended_stops(
                current, current_schedule, group, operational_nodes,
                state.truck_index, counters, max_extended_stops)
            if extended is not None and (best is None or extended.completion < best.completion - EPS):
                best = extended
        if best is None:
            return {"status": "failed", "state": state, "plan": current, "schedule": current_schedule,
                    "reason": f"no feasible candidate for target {target} ({len(group)} nodes)",
                    "log": log, "counters": counters,
                    "search_config": {"max_extended_stops": max_extended_stops}}
        log.append({"target": target, "nodes": list(group), "level": best.level, **best.description,
                    "completion": best.completion})
        current = best.plan
        current_schedule = evaluate(current)
    reason = check_constraints(current, current_schedule)
    if reason:
        return {"status": "failed", "state": state, "plan": current, "schedule": current_schedule,
                "reason": reason, "log": log, "counters": counters,
                "search_config": {"max_extended_stops": max_extended_stops}}
    return {"status": "completed", "state": state, "plan": current, "schedule": current_schedule,
            "completion": current_schedule.completion, "log": log, "counters": counters,
            "search_config": {"max_extended_stops": max_extended_stops}}


# --------------------------------------------------------------------------- #
# Independent bounded deep search
# --------------------------------------------------------------------------- #

def deep_recovery_search(plan: Plan, schedule: Schedule, t_f: float, failed: List[int],
                         operational_nodes: List[int], max_new_stops: int = 4) -> dict:
    """Search chronology-safe survivor reorganizations missed by greedy RTAR."""
    from .audit import audit, history_from_anchors
    anchored, state = extract_event_state(plan, schedule, t_f, failed)
    groups = {target: list(nodes) for target, nodes in state.unfinished.items()}
    if len(failed) != 1 or len(groups) != 1 or len(anchored.drones) != 1:
        return rtar(plan, schedule, t_f, failed, operational_nodes)
    survivor = next(iter(anchored.drones))
    prefixes, future_groups = [], []
    for route in anchored.drones[survivor]:
        cut = next((i for i, n in enumerate(route) if n in anchored.virtual_nodes), None)
        if cut is not None:
            prefixes.append(list(route[:cut + 1]))
            body = [n for n in route[cut + 1:-1] if n in anchored.target_of]
        else:
            body = [n for n in route[1:-1] if n in anchored.target_of]
        if body:
            future_groups.append((anchored.target_of[body[0]], body))
    if len(prefixes) != 1:
        return rtar(plan, schedule, t_f, failed, operational_nodes)
    future_groups.append((next(iter(groups)), next(iter(groups.values()))))
    counters = {"evaluated": 0, "infeasible": 0}
    best = None
    event_index = anchored.truck.index(state.truck_node)
    # Future operational stops are also eligible for reordering or dropping;
    # only the event prefix and destination are fixed.
    suffix_ops = [n for n in operational_nodes if n not in anchored.truck[:event_index + 1]]
    for count in range(max_new_stops + 1):
        for chain in permutations(suffix_ops, count):
            truck = (anchored.truck[:event_index + 1] + list(chain)
                     + [anchored.truck[-1]])
            index = {n: i for i, n in enumerate(truck)}
            for ordering in permutations(future_groups):
                for end0 in truck[event_index + 1:]:
                    routes = [prefixes[0] + list(ordering[0][1]) + [end0]]

                    def attach(pos, current, prev):
                        nonlocal best
                        if pos == len(ordering):
                            trial = anchored.copy()
                            trial.truck = list(truck)
                            trial.drones = {survivor: [list(r) for r in current]}
                            counters["evaluated"] += 1
                            completion, _, sch = feasible_completion(trial)
                            if completion is None or audit(trial, sch, history_from_anchors(trial)):
                                counters["infeasible"] += 1
                            elif best is None or completion < best.completion - EPS:
                                best = Candidate(trial, completion, 4,
                                                  {"strategy": "deep_exhaustive",
                                                   "new_stops": list(chain)})
                            return
                        _, body = ordering[pos]
                        for li in range(index[prev], len(truck) - 1):
                            for ri in range(li + 1, len(truck)):
                                attach(pos + 1, current + [[truck[li]] + list(body) + [truck[ri]]],
                                       truck[ri])
                    attach(1, routes, end0)
    if best is None:
        return {"status": "failed", "state": state, "plan": anchored,
                "schedule": evaluate(anchored), "reason": "deep search found no feasible candidate",
                "log": [], "counters": counters,
                "search_config": {"deep_exhaustive": True, "max_new_stops": max_new_stops}}
    return {"status": "completed", "state": state, "plan": best.plan,
            "schedule": evaluate(best.plan), "completion": best.completion,
            "log": [{"target": t, "nodes": list(g), "level": 4, **best.description,
                     "completion": best.completion} for t, g in groups.items()],
            "counters": counters,
            "search_config": {"deep_exhaustive": True, "max_new_stops": max_new_stops}}


# --------------------------------------------------------------------------- #
# Conversions
# --------------------------------------------------------------------------- #

def plan_from_result(coords, truck_route, drone_route_dict, target_of, params: Params, inspection=None) -> Plan:
    """Build a plan from the historical ``{drone: {sortie_id: route}}`` format."""
    index = {n: i for i, n in enumerate(truck_route)}
    drones = {}
    for d in sorted(drone_route_dict, key=int):
        routes = [list(map(int, r)) for r in drone_route_dict[d].values()]
        routes.sort(key=lambda r: (index[r[0]], index[r[-1]]))
        drones[int(d)] = routes
    inspection = inspection or {i: 0.0 for i in range(len(coords))}
    return Plan(np.asarray(coords, dtype=float), list(map(int, truck_route)), drones, dict(target_of), dict(inspection), params)


def schedule_to_dict(plan: Plan, schedule: Schedule) -> dict:
    return {
        "truck_arrival": {str(n): schedule.truck_arrival[n] for n in plan.truck},
        "truck_leave": {str(n): schedule.truck_leave[n] for n in plan.truck},
        "sorties": [
            {"drone_id": d, "sortie_index": si, "route": [int(n) for n in route],
             "launch_time": schedule.launch[(d, si)],
             "node_arrival_times": schedule.node_time[(d, si)],
             "retrieval_complete": schedule.retrieval[(d, si)],
             "flight_time": schedule.flight_time[(d, si)]}
            for d, sorties in sorted(plan.drones.items()) for si, route in enumerate(sorties)
        ],
        "completion": schedule.completion,
    }


def plan_to_dict(plan: Plan) -> dict:
    return {
        "truck_route": [int(n) for n in plan.truck],
        "drone_route": {str(d): {str(si + 1): [int(n) for n in r] for si, r in enumerate(ss)}
                        for d, ss in sorted(plan.drones.items())},
        "virtual_nodes": {str(n): {"coords": [float(x) for x in plan.coords[n]], "meaning": m}
                          for n, m in plan.virtual_nodes.items()},
        "completed_by_failed_drones": {str(n): d for n, d in sorted(plan.completed_by_failed.items())},
    }
