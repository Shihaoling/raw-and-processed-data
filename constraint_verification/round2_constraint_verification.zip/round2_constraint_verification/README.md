# Round 2 constraint verification

This archive supports the constraint-verification response for **Failure-Aware Truck–Drone Collaborative Routing for Multi-Type Coverage Tasks**, manuscript AMMOD-D-26-02709. It preserves the historical October 2026 verification records. Preparing this archive did not run COPT or generate new optimization results.

## Contents and scope

| Path | Contents |
|---|---|
| `reports/Constraint_Reduction_and_COPT_Verification.docx` | Detailed report, with mathematical justification, constraint reductions, tables and figures; a set-difference glyph is normalized for reliable equation rendering. Its manuscript title and section references reflect the draft at the time of verification. |
| `reports/Constraint_Reduction_and_COPT_Verification.pdf` | PDF rendering of the accompanying report for direct reading. |
| `equation_crosswalk.csv` | All 42 first-stage constraint numbers in R1 mapped to the current manuscript's 28 numbered constraints (2)–(29). |
| `constraint_audit/model_rows.py` | Shared linear-row definitions for the audit and COPT models, including auxiliary linearizations. |
| `constraint_audit/outputs/` | Per-instance/per-equation statistics, aggregated tables, toy-removal experiments, small-instance summaries, stdout and run records. |
| `constraint_audit/copt_logs/` | COPT logs for the main small-instance runs and the RC confirmation runs. |
| `constraint_audit/copt_runs/` | Archived solver results, bounds/gaps, nonzero variable values, decoded routes and physical-check outcomes. |
| `constraint_audit/copt_ready/` | Model input data, the two toy instances, and warm starts. |
| `constraint_audit/figures/` | Report/response figures and historical progress plots. |
| `inputs/00_instances/` | The 30 generated geometric instances used to reconstruct the MILP data. |
| `inputs/01_main_svns_results/` | The 30 stored main-experiment SVNS plans. |
| `inputs/04_parameter_sensitivity/fleet_size_runs/` | The 75 stored fleet-size plans. |
| `inputs/08_scripts/rtar_core/` | The schedule evaluator and independent physical audit required by the verification scripts. |
| `verify_archived_results.py` | Read-only checks of archived evidence and file hashes; no solver required. |
| `MANIFEST.sha256` | Checksums for the package files, excluding the manifest itself. |

The solver implementation and row-by-row numerical audit concern the **first-stage model**. The report also explains the corresponding formulation reduction; the recovery formulation's 27 appendix constraints should not be mistaken for a separate recovery-MILP numerical experiment in this archive. The manuscript's previously reported Gurobi values are reference values and were not recomputed here.

## Numbers and historical conventions

`paper`, `corrected` and `reduced` are historical profile names. `paper` implements the R1 printed first-stage model. `corrected` adds the single-departure condition and extends the domains of R1 (18) and (30) to depot-ended/started sorties. `reduced` removes redundancies and unifies the point-target cases. The retained model has 28 numbered constraints after five pairs are written as two-sided displays. A numbered display is not a solver row; indexed constraints and linearizations expand to many rows.

All `eq`, `drop` and constraint references in the scripts, logs and original report use **R1 numbers**, not the current manuscript's numbering. `equation_crosswalk.csv` gives the current numbers. In particular, corrected R1 (2), (18), (30) correspond to current (2), (11), (20). R1 (47)–(49), the auxiliary binary-maximum linearization, are removed with the associated variable; the remaining linearization explanation is now unnumbered in Section 4.2.

Code names `C_3_4`, `R_3_4`, `RC_3_4` correspond to paper names C-4-3, R-4-3, RC-4-3: the two numeric positions are reversed. A stored field named `global_optimal_time` is an SVNS output field; its name does not certify global optimality.

`rows_total` counts indexed rows; `active` counts rows whose logical condition is active; `tight` counts active rows satisfied at equality; `violated` counts violated rows. Tightness alone does not establish necessity. The reported audit includes all 30 main and 75 fleet-size plans. The main plans also have a corrected-profile audit, which must not be counted as 30 additional distinct plans. For large row families, the script evaluates active rows and counts inactive rows analytically, with the big-M horizon check recorded. `selftest.py` checks this against full-row evaluation on the three small instances.

## Which runs support the response letter

- `outputs/letter_30min_summary.json` and `make_letter_figures.py` identify the exact log sources used for the response figures and tables.
- **C-4-3:** the archived runs lasted 2400 seconds. The response's 1800-second comparison uses only log observations at or before 1800 seconds; it is not a separate 1800-second run. The final qualifying observations occur at 1717 and 1369 seconds for reduced and corrected respectively. Both incumbents are 7.479902, rounding to the manuscript's 7.48.
- **R-4-3:** both original 1800-second runs yield 7.474753, rounding to the reported 7.47.
- **RC-4-3:** the original reduced run yields 7.914022; the original corrected run yields 7.957813. The separate `_30min_rerun` files start both models from the reduced run's 7.914022 solution and show that the corrected model accepts it. Thus the report's statement that both models reach 7.9140 includes this confirmation; it must not be read as both independent original runs finding it. The response comparison and figure use the original runs, not the confirmation runs. The reduced incumbent differs from the historical Gurobi value 7.895 by about 0.24%.
- These small-instance COPT runs retain nonzero optimality gaps. They are feasible incumbent comparisons, not proofs of global optimality. The two toy instances have zero-gap optima and include negative controls that deliberately remove necessary constraints and yield unexecutable plans. In TOY_1D, removing R1 (16), (23), or (37) causes failure; in TOY_2D, (23) supplies this counterexample, whereas removing (16) or (37) happens to leave an executable optimum on that instance. Removing (21)–(22) without unifying the point cases leaves a point unserved in both toys; the TOY_2D objective stays unchanged despite that infeasibility.
- Exploratory 300-second runs and the aborted 3600-second attempt remain in the archive for completeness; they are not substituted for the principal runs. The archived model logs retain the COPT version, hardware configuration, parameters, timestamps and results.

## Reproduction

Use Python 3.10 or later. Core audit dependencies are NumPy; plotting additionally needs Matplotlib. Rebuilding the report needs python-docx and latex2mathml. Historical solver logs report **COPT 8.0.7**. Re-solving requires `coptpy` and a user-supplied COPT installation/license appropriate to the model size. No license or solver binary is distributed.

Install the non-solver dependencies using `python3 -m pip install -r requirements.txt`. From the package root, run:

```sh
python3 verify_archived_results.py
cd constraint_audit
python3 selftest.py
```

The checks above do not optimize a model. To regenerate row statistics, work in a **copy of the package** because the historical script writes to `outputs/` and `copt_ready/`:

```sh
python3 run_svns_audit.py
python3 check_paper_routes.py
python3 make_letter_figures.py
python3 make_report_figures.py
python3 make_report_docx.py
```

The last command writes `reports/Constraint_Reduction_and_COPT_Verification_regenerated.docx`, preserving the archived report. Numerical audit inputs and evaluator dependencies are all included; no author's local project tree is required.

Optional re-solving commands, again in a working copy:

```sh
python3 -m pip install coptpy==8.0.7
python3 run_copt_experiments.py --cases TOY_1D TOY_2D --time-limit 600
python3 run_copt_small.py --cases C_3_4 --profiles reduced corrected --time-limit 2400 --threads 5 --log-dir copt_logs --tag _new
python3 run_copt_small.py --cases R_3_4 RC_3_4 --profiles reduced corrected --time-limit 1800 --threads 5 --log-dir copt_logs --tag _new
```

These sequential example commands rebuild the same models; runtimes and search trajectories need not equal the archived runs. The historical `run_r_rc_30min.sh` launches corrected/reduced jobs concurrently with five threads each. It now accepts the interpreter through `PYTHON` and leaves license configuration to the user. For the separate RC confirmation, use `--warm-name RC_3_4_from_reduced30` and a distinct tag. Time limits, software versions and thread contention affect incumbent histories.

## Publication preparation

The original evidence is retained. Public copies replace author-specific absolute paths in stdout and two plan-provenance fields with relative locations, and adapt the input/report paths and shell interpreter for portability. The report also normalizes the set-difference glyph from a standalone backslash to the mathematical symbol ∖ for reliable rendering; the mathematical meaning and structure are retained. Model equations, tolerances, data values and recorded solver results were not altered. Caches, temporary files, obsolete manuscript-editing utilities, license files and license correspondence are excluded. The original Chinese README is retained as historical context; this README gives the portable paths and distinguishes the main runs from confirmations.
